//
//  ViewController.swift
//  chartSample
//
//  Created by Carlos Pires on 07/02/2018.
//  Copyright © 2018 Carlos Pires. All rights reserved.
//

import UIKit
import Charts

class ViewController: UIViewController {

    @IBOutlet var chChart: LineChartView!
    @IBOutlet weak var barChartView: BarChartView!
    @IBOutlet weak var candleStickChartView: CandleStickChartView!
    
    var dataPoints = ["1","2","3","4","5","6","7","8","9","10"]
    var dataValues = ["76","81","140","155","161","180","185","110","135","150"]
    var barChartDataEntry: [BarChartDataEntry] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        updateGraphs()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func updateGraphs() {
        
        // LineChart
        var lineChartEntry = [ChartDataEntry]()
        
        // iterate through numbers
        for i in 0..<self.dataValues.count {
            // create point in graph for each number
            let value = ChartDataEntry(x: Double(i), y: Double(self.dataValues[i])!)
            // append to the lineChart
            lineChartEntry.append(value)
        }
        
        let line1 = LineChartDataSet(values: lineChartEntry, label: "Number")
        line1.colors = [NSUIColor.blue]
        
        let data = LineChartData()
        data.addDataSet(line1)
        
        chChart.data = data
        chChart.chartDescription?.text = "My awesome numbers"
        
        // BarChart
        self.setBarChart(dataPoints: dataPoints, values: dataValues)

        // CandleStickChart
        self.setDataCount(Int(10), range: UInt32(50))
    }
    
    func setBarChart(dataPoints: [String], values: [String]) {
        barChartView.noDataTextColor = UIColor.black
        barChartView.noDataText = "No data found"
        barChartView.backgroundColor = UIColor.white
        
        for i in 0..<dataPoints.count {
            let dataPoint = BarChartDataEntry(x: Double(i), y: Double(values[i])!)
            barChartDataEntry.append(dataPoint)
        }
        let barChartDataSet = BarChartDataSet(values: barChartDataEntry, label: "Test Bar")
        let barChartData = BarChartData()
        barChartData.addDataSet(barChartDataSet)
        barChartData.setDrawValues(false)
        barChartView.data = barChartData
    }
    
    func setDataCount(_ count: Int, range: UInt32) {
        let yVals1 = (0..<count).map { (i) -> CandleChartDataEntry in
            let mult = range + 1
            let val = Double(arc4random_uniform(40) + mult)
            let high = Double(arc4random_uniform(9) + 8)
            let low = Double(arc4random_uniform(9) + 8)
            var open = Double(arc4random_uniform(6) + 1)
            var close = Double(arc4random_uniform(6) + 1)
            let even = i % 2 == 0
            let shadowH = val + high
            let shadowL = val - low
            open = even ? val + open : val - open
            close = even ? val - close : val + close
            
            return CandleChartDataEntry(x: Double(i), shadowH: shadowH, shadowL: shadowL, open: open, close: close, icon: UIImage(named: "btcicon")!)
        }
        
        let set1 = CandleChartDataSet(values: yVals1, label: "Candle Stick")
        set1.axisDependency = .left
        set1.setColor(UIColor(white: 80/255, alpha: 1))
        set1.drawIconsEnabled = false
        set1.shadowColor = .darkGray
        set1.shadowWidth = 0.7
        set1.decreasingColor = .red
        set1.decreasingFilled = true
        set1.increasingColor = UIColor(red: 122/255, green: 242/255, blue: 84/255, alpha: 1)
        set1.increasingFilled = false
        set1.neutralColor = .blue
        
        let data = CandleChartData(dataSet: set1)
        candleStickChartView.data = data
    }
}

