for i in `ls`
do
	NAME=`echo "$i" | cut -d'.' -f1`
 	EXT=`echo "$i" | cut -d'.' -f2`
 	if [ $EXT == 'svg' ]
 		then
 		svgexport $NAME.$EXT $NAME@3x.png 168:168
 		svgexport $NAME.$EXT $NAME@2x.png 112:112
 		svgexport $NAME.$EXT $NAME.png 56:56
 	fi
done