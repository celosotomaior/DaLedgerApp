//
//  ViewController.swift
//  chartSample
//
//  Created by Carlos Pires on 07/02/2018.
//  Copyright © 2018 Carlos Pires. All rights reserved.
//

import UIKit
import Charts

class ViewController: UIViewController {

    @IBOutlet var chChart: LineChartView!
    
    @IBOutlet weak var detailChart: LineChartView!
    var dataPoints = ["1","2","3","4","5","6","7","8","9","10"]
    var dataValues = ["76","81","140","155","161","180","185","110","135","150"]
    var barChartDataEntry: [BarChartDataEntry] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        updateGraphs()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func updateGraphs() {
        
        // LineChartHome
        var lineChartEntry = [ChartDataEntry]()
        dataValues = ["76","81","140"]
        // iterate through numbers
        for i in 0..<self.dataValues.count {
            // create point in graph for each number
            let value = ChartDataEntry(x: Double(i), y: Double(self.dataValues[i])!)
            // append to the lineChart
            lineChartEntry.append(value)
        }
        
        
        let homeChart = LineChartDataSet(values: lineChartEntry, label: "Number")
        var defaultColor = UIColor(red:0.19, green:0.82, blue:0.75, alpha:1.0)
        homeChart.setColor(defaultColor)
        homeChart.setCircleColor(defaultColor)
        homeChart.circleRadius = 6.0
        homeChart.highlightColor = NSUIColor.black
        homeChart.drawFilledEnabled = false
        homeChart.drawCircleHoleEnabled = false
        homeChart.drawHorizontalHighlightIndicatorEnabled = false
        chChart.drawGridBackgroundEnabled = false
        chChart.xAxis.enabled = false
        
        chChart.legend.enabled = false
        chChart.leftAxis.drawGridLinesEnabled = false
        
        // remove right axis
        var yaxis = chChart.getAxis(YAxis.AxisDependency.right)
        yaxis.drawLabelsEnabled = false
        yaxis.enabled = false
        yaxis.drawAxisLineEnabled = false
        // remove left axis
        yaxis = chChart.getAxis(YAxis.AxisDependency.left)
        yaxis.drawLabelsEnabled = false
        yaxis.enabled = false
        yaxis.drawAxisLineEnabled = false
        
        var data = LineChartData()
        data.addDataSet(homeChart)
        
        
        chChart.data = data
        chChart.chartDescription?.text = ""
        
        // LineChartDetail
        lineChartEntry = [ChartDataEntry]()
        self.dataValues = ["76","81","40","120","150","155"]
        // iterate through numbers
        for i in 0..<self.dataValues.count {
            // create point in graph for each number
            let value = ChartDataEntry(x: Double(i), y: Double(self.dataValues[i])!)
            // append to the lineChart
            lineChartEntry.append(value)
        }
        
        
        let chartHomeDetail = LineChartDataSet(values: lineChartEntry, label: "Number")
        defaultColor = UIColor(red:0.19, green:0.82, blue:0.75, alpha:1.0)
        var circleColor = UIColor(red:0.61, green:0.61, blue:0.61, alpha:1.0)
        chartHomeDetail.setColor(defaultColor)
        chartHomeDetail.setCircleColor(circleColor)
        chartHomeDetail.circleRadius = 6.0
        chartHomeDetail.highlightColor = NSUIColor.black
        chartHomeDetail.drawFilledEnabled = false
        chartHomeDetail.drawCircleHoleEnabled = true
        chartHomeDetail.drawHorizontalHighlightIndicatorEnabled = false
        
        detailChart.leftAxis.drawGridLinesEnabled = false
        detailChart.drawGridBackgroundEnabled = false
        detailChart.xAxis.enabled = false
        detailChart.legend.enabled = false

        yaxis = detailChart.getAxis(YAxis.AxisDependency.right)
        yaxis.drawLabelsEnabled = false
        yaxis.enabled = false
        yaxis.drawAxisLineEnabled = false
        
        data = LineChartData()
        data.addDataSet(chartHomeDetail)
        
        
        detailChart.data = data
        detailChart.chartDescription?.text = ""
    }

}

