# -*- coding: utf-8 -*-

import os
import sys
import time
import json

# -----------------------------------------------------------------------------

root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(root + '/python')

# -----------------------------------------------------------------------------

import ccxt  # noqa: E402

# -----------------------------------------------------------------------------
# common constants

msec = 1000
minute = 60 * msec
hold = 30

# -----------------------------------------------------------------------------

exchange = ccxt.poloniex({
    'rateLimit': 10000,
    'enableRateLimit': True,
    # 'verbose': True,
})

# -----------------------------------------------------------------------------

from_datetime = '2013-01-01 00:00:00'
from_timestamp = exchange.parse8601(from_datetime)

# -----------------------------------------------------------------------------

now = exchange.milliseconds()

# -----------------------------------------------------------------------------

data = []

while from_timestamp < now:

    try:
        #symbols = ['BTC/USDT','LTC/USDT', 'ETH/USDT','XMR/USDT', 'DASH/USDT','XRP/USDT', 'BCH/USDT']
        symbols = ['BTC/USDT']
        
        
        
        for ohlcvs in symbols:
            #print(exchange.milliseconds(), 'Fetching candles starting from', exchange.iso8601(from_timestamp))
            ohlcvs = exchange.fetch_ohlcv(ohlcvs, '1d', from_timestamp)
            
            # print (ohlcvs)
            values = []
        
        
            poloniexID = "5a8bfc6f56d43b19547340ce"


            btcusd = "5a93da455bf31bde4e2d3dbe"
            ethusd = "5a93da455bf31bde4e2d3dbf"
            ltcusd = "5a93da455bf31bde4e2d3dc0"
            xmrusd = "5aa16a9bd03f6005765a6b9f"
            xrpusd = "5aa16b23d03f6005765a6ba0"
            bchusd = "5aa16b6fd03f6005765a6ba1"
            neousd = "5aa16bd6d03f6005765a6ba2"
            adausd = "5aa16bfed03f6005765a6ba3"
            xlmusd = "5aa16c6ad03f6005765a6ba4"
            miotausd = "5aa16c87d03f6005765a6ba5"
            dashusd = "5aa16c9ed03f6005765a6ba6"
                
       
        for i in ohlcvs:
            i = [{'exchangeId':poloniexID, 'cryptocurrencyId': btcusd, 'timestamp': ohlcvs[i][0], 'last': ohlcvs[i][4], 'open': ohlcvs[i][1], 'high': ohlcvs[i][2], 'low': ohlcvs[i][3]}]
            json.loads('[{"exchangeId":poloniexID, "cryptocurrencyId": btcusd, "timestamp": ohlcvs[i][0], "last": ohlcvs[i][4], "open": ohlcvs[i][1], "high": ohlcvs[i][2], "low": ohlcvs[i][3]}]') == i

            values.append(i)
                #values(ohlcvs({'exchangeId':poloniexID, 'cryptocurrencyId': btcusd, 'timestamp': ohlcvs[i][0], 'last': ohlcvs[i][4], 'open': ohlcvs[i][1], 'high': ohlcvs[i][2], 'low': ohlcvs[i][3]})
            #  values.append({'exchangeId':poloniexID, 'cryptocurrencyId': ltcusd, 'timestamp': ohlcvs[i][0], 'last': ohlcvs[i][4], 'open': ohlcvs[i][1], 'high': ohlcvs[i][2], 'low': ohlcvs[i][3]})
            # values.append({'exchangeId':poloniexID, 'cryptocurrencyId': ethusd, 'timestamp': ohlcvs[i][0], 'last': ohlcvs[i][4], 'open': ohlcvs[i][1], 'high': ohlcvs[i][2], 'low': ohlcvs[i][3]})
            # values.append({'exchangeId':poloniexID, 'cryptocurrencyId': xmrusd, 'timestamp': ohlcvs[i][0], 'last': ohlcvs[i][4], 'open': ohlcvs[i][1], 'high': ohlcvs[i][2], 'low': ohlcvs[i][3]})
            #  values.append({'exchangeId':poloniexID, 'cryptocurrencyId': dashusd, 'timestamp': ohlcvs[i][0], 'last': ohlcvs[i][4], 'open': ohlcvs[i][1], 'high': ohlcvs[i][2], 'low': ohlcvs[i][3]})
            #  values.append({'exchangeId':poloniexID, 'cryptocurrencyId': xrpusd, 'timestamp': ohlcvs[i][0], 'last': ohlcvs[i][4], 'open': ohlcvs[i][1], 'high': ohlcvs[i][2], 'low': ohlcvs[i][3]})
            #  values.append({'exchangeId':poloniexID, 'cryptocurrencyId': bchusd, 'timestamp': ohlcvs[i][0], 'last': ohlcvs[i][4], 'open': ohlcvs[i][1], 'high': ohlcvs[i][2], 'low': ohlcvs[i][3]})
               #print(values)
        
            print(exchange.milliseconds(), 'Fetched', len(ohlcvs), 'candles')
        #print(ohlcvs)
        first = ohlcvs[0][0]
        last = ohlcvs[-1][0]
        print('First candle epoch', first, exchange.iso8601(first))
        print('Last candle epoch', last, exchange.iso8601(last))
        from_timestamp += len(ohlcvs) * minute * 5
        data += ohlcvs

    except (ccxt.ExchangeError, ccxt.AuthenticationError, ccxt.ExchangeNotAvailable, ccxt.RequestTimeout) as error:

        print('Got an error', type(error).__name__, error.args, ', retrying in', hold, 'seconds...')
        time.sleep(hold)
