// Retrieve
var moment = require('moment');

const f = require('util').format;
fs = require('fs');
var MongoClient = require('mongodb').MongoClient;

const user = encodeURIComponent('cryptoshi77');
const password = encodeURIComponent('j5msi5kx92_');
const authMechanism = 'DEFAULT';
const host = "api.cryptoshiapp.com"
const dbname = "cryptoshi"
const authSrc = "admin"
const url = f('mongodb://%s:%s@%s:27017/%s?authMechanism=%s&authSource=%s', user, password, host, dbname, authMechanism, authSrc);

'use strict';
// poloniex.verbose = true
const ccxt = require ('ccxt');

async function insertData ( exchange, pair, ticker ) {

  // console.log(exchange);
  // return true;

  var returnInsertion = [];

  if (exchange == null) {
    console.log('Exchange não informada')
    process.exit();
  }
  if (pair == null) {
    console.log('pair não informada')
    process.exit();
  }
  if (ticker == null) {
    console.log('ticker não informada')
    process.exit();
  }
    
    MongoClient.connect(url, async function(err, db){
      // server: {
      // sslValidate:true
      // sslCA:ca
      // }
      if(err) { return console.dir(err); }
      var mydb = db.db(dbname);


      // mydb.collection("volumeExchange").createIndex( { "assetPairId": 1, "timestamp":1, "period":1}, { unique: true  });
      // mydb.collection("priceByExchange").createIndex( { "assetPairId": 1, "timestamp":1}, { unique: true  });
      // proccess.exit();
      // console.log (exchange +">>>>Exchange test"+pair +">>>>Pair")
      var exchangeId = await mydb.collection("exchange").findOne( { "name": exchange })
        
        // console.log(exchangeId+">>>"+pair)
        // console.log({ "pair": pair, "exchangeId":exchangeId });

      var pairId = await mydb.collection("assetPair").findOne( { "pair": pair, "exchangeId": exchangeId._id+"" })
           
          asset = {
            "assetPairId" : pairId._id + "", 
            "timestamp": ticker["timestamp"],
            "open": ticker["open"],
            "last": ticker["close"],
            "high": ticker["high"],
            "low": ticker["low"]
          }
          // volume = { "exchangeId": exchangeId, "cryptocurrencyId": cryptocurrencyId, "timestamp": ticker["timestamp"], "period": 24, "volume": ticker["baseVolume"] }
        //   console.log(ticker)
          mydb.collection("priceByExchangeTest").insert(asset, function(err, result) {
            if ( err ) {
              if (err.code == 11000) {
                console.log('duplicated' + moment.unix(ticker["timestamp"]/1000).utcOffset(0).format("YYYY-MM-DD HH:mm:ss"));

              } else {
                throw err  
              }
            }
              // console.log('Inserted>>>');
            // console.log(result)
          });
          volume = {
            "assetPairId" : pairId._id + "", 
            "timestamp": ticker["timestamp"],
            "period": ticker["period"],
            "volume": ticker["volume"],
            // "high": ticker["high"],
            // "low": ticker["low"]
          }
          mydb.collection("volumeByExchangeTest").insert(volume, function(err, result) {
            // if (code != null && err.code == 11000) {
            //   console.log('duplicated' + moment.unix(ticker["timestamp"]/1000).utcOffset(0).format("YYYY-MM-DD HH:mm:ss"));
            // } else {
            //   //throw err  
            // }
            // console.log(result)
          });
         db.close();
        // });
        
      // });
    
    });
    // return true
}

// [{'exchangeId':poloniexID, 'cryptocurrencyId': btcusd, 'timestamp': ohlcvs[i][0], 'last': ohlcvs[i][4], 'open': ohlcvs[i][1], 'high': ohlcvs[i][2], 'low': ohlcvs[i][3]}]

(async function () {
    var insertedRows = 0;
    // getKraken()
    
    var ex2 = new ccxt.bitfinex({
      
      'rateLimit': 10000,
      'enableRateLimit': true,
      // 'verbose': True,
    
    });
    // console.log(lastDay)
    // while (from_timestamp < to_timestamp){
  
  
      var exchanges = [
        //{'name':'poloniex', 'symbols': ['BTC/USDT','LTC/USDT', 'ETH/USDT','XMR/USDT', 'DASH/USDT','XRP/USDT', 'BCH/USDT'], 'limit':1000}
        {'name':'kraken', 'symbols': ['XLM/USD'], 'limit':1000}
      ];
      // Kraken 'XLM/USD', 'BTC/USD','LTC/USD', 'ETH/USD','XMR/USD', 'DASH/USD','XRP/USD', 'BCH/USD'
      // Bitfinex BTC/USD,'LTC/USD', 'ETH/USD','XMR/USD', 'DASH/USD','IOTA/USD','XRP/USD', 'BCH/USD', 'NEO/USD'
      //Poloniex 'BTC/USDT' ,'LTC/USDT', 'ETH/USDT','XMR/USDT', 'DASH/USDT','XRP/USDT', 'BCH/USDT'
      for (e in exchanges) {
      //  console.log(exchanges[e].name);
        
        ex = new ccxt[exchanges[e].name]({
          'rateLimit': 10000,
          'enableRateLimit': true,
          // 'verbose': true,
        
        });
  
        // symbols = ['BTC/USD','ETH/USD']
        symbols = exchanges[e].symbols
        console.log(symbols)
        // console.log(symbols)
  
        for (s in symbols) {  
          var limit = 50;
          var datetime = '2018-03-25T00:00:00' 
          var timestamp = ex2.parse8601(datetime)
          var currentMoment = moment.unix(timestamp/1000);
          currentMoment.subtract(limit,'d');

          datetime = currentMoment.utcOffset(0).format("YYYY-MM-DD HH:mm:ss");
        //   console.log(datetime)
        //   var datetime = moment().format("YYYY-MM-DD HH:mm:ss")
          
          var nullResultCount = 0
        //   console.log(nullResultCount)
      
           console.log(exchanges[e].name + ':' + symbols[s])
           while (nullResultCount < 1) {
               
              var timestamp = ex2.parse8601(datetime)
              console.log('API Consult:' + moment.unix(timestamp/1000).utcOffset(0).format("YYYY-MM-DD HH:mm:ss"));
              
              var data = await ex.fetch_ohlcv(symbols[s], '1d', timestamp, limit);
              // console.log(data);
              if(data.length == 0){
                  nullResultCount++
                  console.log("Result count:" + nullResultCount);
              }else{
                  for (d in data) {
                    //   console.log(data);
                      var ticker = []
                      ticker["timestamp"] =  data[d][0];
                      ticker["period"] = "1d";
                      ticker["open"] = data[d][1];
                      ticker["volume"] = data[d][5];
                      ticker["high"] = data[d][2];
                      ticker["low"] = data[d][3];
                      ticker["close"] = data[d][4];
                      exchangeName = exchanges[e].name.charAt(0).toUpperCase() + exchanges[e].name.slice(1);
                      // console.log(exchangeName+" | "+symbols[s]+" | "+ticker);
                      console.log('Insert into db '+ moment.unix(ticker["timestamp"]/1000).utcOffset(0).format("YYYY-MM-DD HH:mm:ss"));
                      var result = await insertData(exchangeName,symbols[s],ticker);
                      if (result) {
                          // console.log("inserted with succcess!!");
                          insertedRows++;
                        //   console.log(moment.unix(ticker["timestamp"]/1000).utcOffset(0).format("YYYY-MM-DD HH:mm:ss"));
                      } else {
                          console.log("Error inserting data");
                      }
                  }
  
                  nullResultCount = 0
              }
              
              var currentMoment = moment.unix(timestamp/1000);
              console.log("Current day: " + currentMoment.format("YYYY-MM-DD hh:mm:ss"));
              
              currentMoment.subtract(limit,'d');
              console.log("Previous day: " + currentMoment.format("YYYY-MM-DD hh:mm:ss"));
              
              datetime = currentMoment.utcOffset(0).format("YYYY-MM-DD HH:mm:ss");
          }
        }
      }
}) ();
 
