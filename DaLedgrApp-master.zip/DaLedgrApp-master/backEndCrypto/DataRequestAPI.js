'use strict';
const ccxt = require ('ccxt');
include('Config.js')

(async function () {
    let kraken    = new ccxt.kraken ()
    let bitfinex  = new ccxt.bitfinex ({ verbose: true })
    let poloniex     = new ccxt.poloniex ()
    let okcoinusd = new ccxt.okcoinusd ({
        apiKey: 'YOUR_PUBLIC_API_KEY',
        secret: 'YOUR_SECRET_PRIVATE_KEY',
    })

// Connect to the db
MongoClient.connect(url , function(err, db) {
  if(err) { return console.dir(err); }
  var mydb = db.db(dbname);


   var priceByExchange = [{ 'exchangeID':bitfinexID, 'timestamp': Date(), 'cryptocurrency': 'assetContent.symbol', 'last': 'last', 'bid': 'bid', 'ask': 'ask' }];

    mydb.collection("exchangeAsset").insertMany(priceByExchange, function(err, result) {
      if ( err ) throw err
      console.log(result)
    });

    var volume = [{ 'exchangeID': bitfinexID, 'timestamp': Date(),'period':'24h', 'high': 'high', 'low':'low', 'volume': 'volume'}];
    mydb.collection("volumeExchange").insertMany(volume, function(err, result) {
      if ( err ) throw err
      console.log(result)
      });
    var currencies = [{'currency':"US Dollar", 'timestamp': Date(), 'currencySymbol':"USD", 'exchangeRate':'3.2'}];
    mydb.collection("currency").insertMany(currencies, function(err, result) {
      if ( err ) throw err
      console.log(result)
      });
  });
