



var moment = require('moment');


const f = require('util').format;
fs = require('fs');
var MongoClient = require('mongodb').MongoClient;

const user = encodeURIComponent('cryptoshi77');
const password = encodeURIComponent('j5msi5kx92_');
const authMechanism = 'DEFAULT';
const host = "api.cryptoshiapp.com"
const dbname = "cryptoshi"
const authSrc = "admin"
const url = f('mongodb://%s:%s@%s:27017/%s?authMechanism=%s&authSource=%s', user, password, host, dbname, authMechanism, authSrc);
// const host = "45.33.117.44"
// const dbname = "cryptoshi"
// const host = "localhost"
// const url = f('mongodb://%s:27017/%s', host, dbname);
'use strict';
// poloniex.verbose = true
const ccxt = require ('ccxt');


function insertData ( exchange, pair, ticker ) {

  if (exchange == null) {
    console.log('Exchange não informada')
    process.exit();
  }
  if (pair == null) {
    console.log('pair não informada')
    process.exit();
  }
  if (ticker == null) {
    console.log('ticker não informada')
    process.exit();
  }


    
    MongoClient.connect(url, function(err, db){

      if(err) { return console.dir(err); }
      var mydb = db.db(dbname);


      mydb.collection("volumeByExchangeTest").createIndex( { "assetPairId": 1, "timestamp":1}, { unique: true  });
      // proccess.exit();
      console.log (exchange +">>>>Exchange test"+pair +">>>>Pair")
      mydb.collection("exchange").findOne( { "name": exchange }, function ( err, item ) {
        if ( err ) {
          console.log(err)
        }

        exchangeId = item._id + ""
        
      mydb.collection("assetPair").findOne( { "pair": pair, "exchangeId":exchangeId }, function ( err, item ) {
           if ( err ) {
             console.log(err);
  
           }

          
            console.log(item);
        pairId = item._id + ""
           
          asset = {
            "assetPairId" : pairId, 
            "exchangeId": exchangeId,
            "timestamp": ticker["timestamp"],
            "period": ticker["period"],
            "volume": ticker["volume"],
          }
          console.log(ticker)
          mydb.collection("volumeByExchangeTest").insert(asset, function(err, result) {
            if ( err ) {
                throw err  
              if (err.code != 11000) {
              }
            } else {
              return true
            }

          });

         db.close();
        });
        
      });
    
    });

}

(async function () {



  
  var ex2 = new ccxt.bitfinex({
    
    'rateLimit': 10000,
    'enableRateLimit': true,
    // 'verbose': True,
  
  });
  // console.log(lastDay)
  // while (from_timestamp < to_timestamp){


    var exchanges = [
      {'name':'poloniex', 'symbols': ['BTC/USDT'], 'limit':1000, 'exchange.verbose': true}
    ];
    
    
    for (e in exchanges) {
    //  console.log(exchanges[e].name);
      
      ex = new ccxt[exchanges[e].name]({
        'rateLimit': 10000,
        'enableRateLimit': true,
        'verbose': true,
      
      });

      // symbols = ['BTC/USD','ETH/USD']
      symbols = exchanges[e].symbols
      // console.log(symbols)

      for (s in symbols) {
        var from_datetime = '2013-03-05T00:00:00'
        var to_datetime = '2018-03-07T00:00:00'
        var to_date_moment = moment(to_datetime);
        // console.log(to_date_moment.format("YYYY-MM-DD HH:mm:ss"));
        var from_date_moment = moment(from_datetime);
        var from_timestamp = ex2.parse8601(from_datetime)
        var to_timestamp = ex2.parse8601(to_datetime)
        // from_timestamp = ex2.parse8601(from_datetime)
        // to_timestamp = ex2.parse8601(to_datetime)
        var lastDay;
        var limit=100;
        // console.log(from_timestamp +'>>>'+to_timestamp);
        // console.log(from_date_moment.valueOf() +'>>>'+from_timestamp);

        // process.exit();

         console.log(exchanges[e].name + ':' + symbols[s])
         while (from_timestamp <= to_timestamp) {
          console.log(moment.unix(from_timestamp/1000).utcOffset(0).format("YYYY-MM-DD HH:mm:ss") + ">>"+moment.unix(to_timestamp/1000).utcOffset(0).format("YYYY-MM-DD HH:mm:ss"));
          var data = await ex.fetch_ohlcv(symbols[s], '1d', from_timestamp, limit);
          // console.log(data);
          for (d in data) {
            console.log(data);
            var ticker = []
            ticker["timestamp"] =  data[d][0];
            ticker["period"] = "1d";
            ticker["volume"] = data[d][5];
            // ticker["low"] = data[d][3];
            // ticker["close"] = data[d][4];
            exchangeName = exchanges[e].name.charAt(0).toUpperCase() + exchanges[e].name.slice(1);
            // console.log(exchangeName+" | "+symbols[s]+" | "+ticker);
            if (ticker["timestamp"] <= to_timestamp) {
              console.log(exchangeName+">>Exchange"+symbols[s]+">>>");
              var result = insertData(exchangeName,symbols[s],ticker);
              if (result) {
                // console.log("inserted with succcess!!");
                insertedRows++;
                console.log(moment.unix(ticker["timestamp"]/1000).utcOffset(0).format("YYYY-MM-DD HH:mm:ss"));
              } else {
                console.log("Error inserting data");
              }
            }
          }

          // if (typeof data != undefined) {
          //   console.log('NAO TEM')
          //   lastDay = from_timestamp
          // } else {
          //   console.log('TEM')
          //   lastDay = data[data.length - 1][0];
          // }
          lastDay = data[data.length - 1][0];
          // lastDay = data[data.length - 1][0];
          //console.log(moment.unix(ticker["timestamp"]/1000).format("YYYY-MM-DD hh:mm:ss"));
          lastDay = moment.unix(lastDay/1000);
          from_timestamp = lastDay.utcOffset(0).format("YYYY-MM-DD HH:mm:ss");
          console.log('Last:'+from_timestamp);
          lastDay.add(1,'d');
          // console.log(lastDay);
          from_timestamp = lastDay.utcOffset(0).format("YYYY-MM-DD HH:mm:ss");
          console.log('Next: '+from_timestamp);

          from_timestamp = ex2.parse8601(from_timestamp);
          // console.log('Real Next: '+moment.unix(from_timestamp/1000).format("YYYY-MM-DD hh:mm:ss"));
          if (from_timestamp > to_timestamp) {
            break;
            process.exit()
          }


          
        }

      }
      // console.log(insertedRows);
    }
    
   }) ();
