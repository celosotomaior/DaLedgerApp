// Retrieve
const f = require('util').format;
var MongoClient = require('mongodb').MongoClient;

const user = encodeURIComponent('cryptoshi77');
const password = encodeURIComponent('j5msi5kx92_');
const authMechanism = 'DEFAULT';
const host = "45.33.117.44"
const dbname = "cryptoshi"
const authSrc = "admin"
const url = f('mongodb://%s:%s@%s:27017/%s?authMechanism=%s&authSource=%s',
   user, password, host, dbname, authMechanism, authSrc);
'use strict';
const ccxt = require ('ccxt');

(async function () {
  //let huobi     = new ccxt.huobi ()
  /*let okcoinusd = new ccxt.okcoinusd ({
    apiKey: 'YOUR_PUBLIC_API_KEY',
    secret: 'YOUR_SECRET_PRIVATE_KEY',
    })*/

  //console.log (kraken.id,    await kraken.loadMarkets ())
  //console.log (bitfinex.id,  await bitfinex.loadMarkets  ())
  //console.log (huobi.id,     await huobi.loadMarkets ())

  //console.log (kraken.id,    await kraken.fetchOrderBook (kraken.symbols[0]))
  //console.log (bitfinex.id,  await bitfinex.fetchTicker ('BTC/USD'))
  //console.log (huobi.id,     await huobi.fetchTrades ('ETH/CNY'))

  //console.log( await bitfinex.fetchTicker('BTC/USD') )

  /*console.log("===")
  console.log(kraken.has)
  console.log(kraken.symbols)
  console.log(kraken.currencies)*/
  getKraken()
  getBitfinex()
  
  //insertData( "bitfinex", "bitcoin", ticker )
  /*console.log ( "===" + ticker )
  console.log ( "===" + ticker.toString() )
  for ( var i in ticker ) {
    //if ( ticker[i].pair == "btcusd" ) {
    console.log(i + " " + ticker[i])
  }

  console.log ( "** " + ticker.length )
  console.log ( "** " + ticker["bid"] )*/

    //console.log (okcoinusd.id, await okcoinusd.fetchBalance ())

  // sell 1 BTC/USD for market price, sell a bitcoin for dollars immediately
  //console.log (okcoinusd.id, await okcoinusd.createMarketSellOrder ('BTC/USD', 1))

  // buy 1 BTC/USD for $2500, you pay $2500 and receive ฿1 when the order is closed
  //console.log (okcoinusd.id, await okcoinusd.createLimitBuyOrder ('BTC/USD', 1, 2500.00))

  // pass/redefine custom exchange-specific order params: type, amount, price or whatever
  // use a custom order type
  //bitfinex.createLimitSellOrder ('BTC/USD', 1, 10, { 'type': 'trailing-stop' })
}) ();

async function getKraken() {
  let kraken    = new ccxt.kraken ()
  await kraken.loadMarkets()
  var bticker = await kraken.fetchTicker('BTC/USD') 
  insertData( "Kraken", "Bitcoin", bticker )
  var lticker = await kraken.fetchTicker('LTC/USD') 
  insertData( "Kraken", "Litecoin", lticker )
  var eticker = await kraken.fetchTicker('ETH/USD') 
  insertData( "Kraken", "Ethereum", eticker )
}

async function getBitfinex() {
  let bitfinex  = new ccxt.bitfinex ({ verbose: true })
  var bticker = await bitfinex.fetchTicker('BTC/USD') 
  insertData( "BitFinex", "Bitcoin", bticker )
  var lticker = await bitfinex.fetchTicker('LTC/USD')
  insertData( "BitFinex", "Litecoin", lticker )
  var eticker = await bitfinex.fetchTicker('ETH/USD')
  insertData( "BitFinex", "Ethereum", eticker )
  var eticker = await bitfinex.fetchTicker('XMR/USD')
  insertData( "BitFinex", "Ethereum", eticker )

}

function insertData ( exchange, crypto, ticker ) {
  MongoClient.connect(url, function(err, db){
    if(err) { return console.dir(err); }
    var mydb = db.db(dbname);
    mydb.collection("cryptocurrency").findOne( { "name": crypto }, function ( err, item ) {
      cryptocurrencyId = item._id + ""
      mydb.collection("exchange").findOne( { "name": exchange }, function ( err, item ) {
        exchangeId = item._id + ""
        asset = { "exchangeId" : exchangeId, "cryptocurrencyId": cryptocurrencyId, "timestamp": ticker["timestamp"], "last": ticker["last"], "bid": ticker["bid"], "ask": ticker["last"] }
        volume = { "exchangeId": exchangeId, "cryptocurrencyId": cryptocurrencyId, "timestamp": ticker["timestamp"], "period": 24, "volume": ticker["baseVolume"] }
        mydb.collection("priceByExchange").insert(asset, function(err, result) {
          if ( err ) throw err
          console.log(result)
        });
        // mydb.collection("volumeExchange").insert(volume, function(err, result) {
        //   if ( err ) throw err
        //   console.log(result)
        // });
       db.close();
      });
      
    });
  
  });

}
