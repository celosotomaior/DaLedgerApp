const f = require('util').format;
var MongoClient = require('mongodb').MongoClient;

const user = encodeURIComponent('cryptoshi77');
const password = encodeURIComponent('j5msi5kx92_');
const authMechanism = 'DEFAULT';
const host = "cryptoshiapp.com"
const dbname = "cryptoshi"
const authSrc = "admin"
const url = f('mongodb://%s:%s@%s:27017/%s?authMechanism=%s&authSource=%s',
  user, password, host, dbname, authMechanism, authSrc);


// Connect to the db
MongoClient.connect(url , function(err, db) {
  if(err) { return console.dir(err); }
  var mydb = db.db(dbname);

  var exchanges = [
    {
      id:"5a93da455bf31bde4e2d3dc2",
      name:'bitfinex',
      symbols: ['BTC/USD','LTC/USD', 'ETH/USD','XMR/USD', 'DASH/USD','IOTA/USD','XRP/USD', 'BCH/USD', 'NEO/USD']
    },
    {
      id:"5a93da455bf31bde4e2d3dc1",
      name:'kraken',
      symbols: ['XLM/USD', 'BTC/USD','LTC/USD', 'ETH/USD','XMR/USD', 'DASH/USD','XRP/USD', 'BCH/USD']
    },
    {
      id:"5ab01d9a235bc35a63a5072e",
      name:'binance',
      symbols: ['BTC/USDT','LTC/USDT', 'ETH/USDT', 'BCH/USDT', 'NEO/USDT']
    },
    {
      id:"5aa1baa9d03f6005765a6c4d",
      name:'poloniex',
      symbols: ['BTC/USDT','LTC/USDT', 'ETH/USDT','XMR/USDT', 'DASH/USDT','XRP/USDT', 'BCH/USDT']
    },
    {
      id:"5aa1ba79d03f6005765a6c4c",
      name:'bitstamp',
      symbols: ['BTC/USD','LTC/USD', 'ETH/USD','XRP/USD', 'BCH/USD']
    },
    {
      id:"5aa1babed03f6005765a6c4e",
      name:'bittrex',
      symbols: ['ETH/USDT', 'BTC/USDT', 'DASH/USDT', 'ADA/USDT', 'XRP/USDT',  'XMR/USDT', 'NEO/USDT', 'LTC/USDT',  'BCH/USDT']
    },
    
  ];

  var currencies      = [];
  currencies['BTC']   ='5a93da455bf31bde4e2d3dbe',
  currencies['ETH']   ='5a93da455bf31bde4e2d3dbf',
  currencies['LTC']   ='5a93da455bf31bde4e2d3dc0',
  currencies['XMR']   ='5aa16a9bd03f6005765a6b9f',
  currencies['XRP']   ='5aa16b23d03f6005765a6ba0',
  currencies['BCH']   ='5aa16b6fd03f6005765a6ba1',
  currencies['NEO']   ='5aa16bd6d03f6005765a6ba2',
  currencies['ADA']   ='5aa16bfed03f6005765a6ba3',
  currencies['XLM']   ='5aa16c6ad03f6005765a6ba4',
  currencies['IOTA'] ='5aa16c87d03f6005765a6ba5',
  currencies['DASH']  ='5aa16c9ed03f6005765a6ba6',
  currencies['USD']   ='5a93e19e07ed2a5521392cd7',
  currencies['USDT']  ='5aaaa419235bc34361188ba7'

  var exchangeSymbols = []
  var obj = {}

  for ( var e in exchanges ) {
    console.log(exchanges[e].name);
    for ( var s in exchanges[e].symbols ) {
      console.log(exchanges[e].symbols[s]);
      pair = exchanges[e].symbols[s].split('/');
      if (typeof currencies[pair[0]] == "undefined") {
        console.log('Currency not found: '+pair[0]);
        process.exit();
      }
      if (typeof currencies[pair[1]] == "undefined") {
        console.log('Currency not found: '+pair[1]);
        process.exit();
      }
      row = {'exchangeId': exchanges[e].id, 'currencyId1': currencies[pair[0]], 'currencyId2': currencies[pair[1]], 'pair': exchanges[e].symbols[s] }
      exchangeSymbols.push(row)
      // console.log(row);
    }
  }

  // console.log("symbols: ")
  // console.log(exchangeSymbols);
  // process.exit();

  mydb.collection("assetPair").insertMany(exchangeSymbols, function(err, result) {
    if ( err ) throw err
    console.log(result)
  });

});