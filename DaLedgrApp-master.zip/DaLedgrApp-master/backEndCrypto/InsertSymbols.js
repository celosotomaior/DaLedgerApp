/***********************************************************************************************
************************************************************************************************
************************************************************************************************
************************************************************************************************
This is a first-time only script

This inserts all the pair symbols (cryptocurrency, dollar) for the exchanges

************************************************************************************************
************************************************************************************************
************************************************************************************************
***********************************************************************************************/
// Retrieve
const f = require('util').format;
var MongoClient = require('mongodb').MongoClient;

const user = encodeURIComponent('cryptoshi77');
const password = encodeURIComponent('j5msi5kx92_');
const authMechanism = 'DEFAULT';
const host = "45.33.117.44"
const dbname = "cryptoshi"
const authSrc = "admin"
const url = f('mongodb://%s:%s@%s:27017/%s?authMechanism=%s&authSource=%s',
  user, password, host, dbname, authMechanism, authSrc);

console.log(url)
// Connect to the db
MongoClient.connect(url , function(err, db) {
  if(err) { return console.dir(err); }
  console.log("Connected correctly to server");
  var mydb = db.db(dbname);

  //insert cryptocurrencies
  var cryptos = [ 
                  {"name":"bitcoin", "symbol":"BTC"},
                  {"name":"ethereum", "symbol":"ETH"},
                  {"name":"litecoin", "symbol":"LTC"},
  ]

  mydb.collection("cryptocurrency").insertMany(cryptos, function(err, result){
    if (err) throw err
    console.log(result)
  });

  // insert exchanges
  //var exchanges = [ {"name":"kraken"} , {"name":"bitfinex"}, {"name":"binance"},{"name":"poloniex"},{"name":"bitstamp"}]
  var exchanges = [ {"name":"kraken"} , {"name":"bitfinex"} ]
  mydb.collection("exchange").insertMany(exchanges, function(err, result){
    if (err) throw err
    console.log(result)
  });

  // insert mapping between symbols, exchanges in their references
  var bitfinexID = 0
  mydb.collection("exchange").findOne({name:"bitfinex"}, function(err, result){
    if (err) throw err
    console.log("==============" )
    console.log(result)
    bitfinexID = result._id+""
    console.log("********* found ID: " + bitfinexID)



    var priceByCrypto = [{'cryptocurrency':'assetContent.symbol', 'timestamp': Date()}];
    mydb.collection("currency").insertMany(priceByCrypto, function(err, result) {
        if ( err ) throw err
        console.log(result)
        });
    ///////////////////////////////////////////////////////////////
    var priceByExchange = [{ 'exchangeID':bitfinexID, 'timestamp': Date(), 'cryptocurrency': 'assetContent.symbol', 'last': 'last', 'bid': 'bid', 'ask': 'ask' }];

    mydb.collection("assetExchange").insertMany(priceByExchange, function(err, result) {
        if ( err ) throw err
        console.log(result)
        });

    var volume = [{ 'exchangeID': bitfinexID, 'timestamp': Date(),'period':'24h', 'high': 'high', 'low':'low', 'volume': 'volume'}];
    mydb.collection("volumeExchange").insertMany(volume, function(err, result) {
        if ( err ) throw err
        console.log(result)
        });
    var currencies = [{'currency':"US Dollar", 'timestamp': Date(), 'currencySymbol':"USD", 'exchangeRate':'3.2'}];
    mydb.collection("currency").insertMany(currencies, function(err, result) {
        if ( err ) throw err
        console.log(result)
        });
  });





});

