var currencyConverter = require('ecb-exchange-rates');

var settings = {};
settings.fromCurrency = "GBP";
settings.toCurrency = "BRL";
settings.amount = 200;
settings.accuracy = 0;


currencyConverter.convert(settings , function(data){
  console.log(JSON.stringify(data));
});

// Supported Currencies
// AUD - Australian Dollar
// BGN - Bulgarian Lev
// BRL - Brazilian Real
// CAD - Canadian Dollar
// CHF - Swiss Franc
// CNY - Chinese Yuan
// CZK - Czech Koruna
// DKK - Danish Krone
// EUR - Euro
// GBP - British Pound
// HKD - Hong Kong Dollar
// HRK - Croatian Kuna
// HUF - Hungarian Forint
// IDR - Indonesian Rupiah
// ILS - Israeli New Shekel
// INR - Indian Rupee
// JPY - Japanese Yen
// KRW - South Korean Won
// LTL - Lithuanian Litas
// LVL - Latvian Lats
// MXN - Mexian Peso
// MYR - Malaysian Ringgit
// NOK - Norwegian Krone
// NZD - New Zealand Dollar
// PHP - Phillippine Peso
// PLN - Polish Zloty
// RON - Romanian New Leu
// RUB - Russian Rouble
// SEK - Swedish Krona
// SGD - Singapore Dollar
// THB - Thai Baht
// TRY - Turkish Lira
// USD - US Dollar
// ZAR - South African Rand
