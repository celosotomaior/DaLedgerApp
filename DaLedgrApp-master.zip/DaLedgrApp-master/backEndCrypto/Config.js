const f = require('util').format;
var MongoClient = require('mongodb').MongoClient;

const user = encodeURIComponent('cryptoshi77');
const password = encodeURIComponent('j5msi5kx92_');
const authMechanism = 'DEFAULT';
const host = "45.33.117.44"
const dbname = "cryptoshi"
const authSrc = "admin"
const url = f('mongodb://%s:%s@%s:27017/%s?authMechanism=%s&authSource=%s',
  user, password, host, dbname, authMechanism, authSrc);
