//import { lakebtc } from 'ccxt';

// Retrieve
var moment = require('moment');
// var date_init = moment("2018-03-12 00:00:00");

// date_init.add(1,'d')
// console.log(date_init.format("DDMMYYYY h:mm:ss"))

// process.exit();

const f = require('util').format;
var MongoClient = require('mongodb').MongoClient;

const user = encodeURIComponent('cryptoshi77');
const password = encodeURIComponent('j5msi5kx92_');
const authMechanism = 'DEFAULT';
const host = "45.33.117.44"
const dbname = "cryptoshi"
const authSrc = "admin"
const url = f('mongodb://%s:%s@%s:27017/%s?authMechanism=%s&authSource=%s',
  user, password, host, dbname, authMechanism, authSrc);

'use strict';
const ccxt = require ('ccxt');

// var lastDay = moment.unix(1520726400000/1000);
//   console.log(lastDay);
//   lastDay.add(1,'d');
//   console.log(lastDay.format("YYYY-MM-DD hh:mm:ss"));

// process.exit();

// const exchangeKraken = new ccxt.bitfinex({
//   'rateLimit': 1,
//   'enableRateLimit': true,
//   // 'verbose': True,

// })



// var from_datetime = '2018-03-12 00:00:00'
// var from_timestamp = exchangeKraken.parse8601(from_datetime)
// var result = []

// async function testExchange(from_timestamp) {
//   result =  await exchangeKraken.fetch_ohlcv('BTC/USD', '1d', from_timestamp);
//   return result
// }

// await exchangeKraken.fetch_ohlcv('BTC/USD', '1d', from_timestamp);
// r = await testExchange()
// console.log(result )

// process.exit();
// exchangeBitfinex = new ccxt.bitfinex({
//     'rateLimit': 10000,
//     // 'enableRateLimit': True,
//     // 'verbose': True,
// })




//  -----------------------------------------------------------------------------







   
       
    

async function getKraken(from_timestamp) {
    ohlcvs = await exchangeKraken.fetch_ohlcv('BTC/USD', '1d', from_timestamp)
    console.log(ohlcvs)
    process.exit()
    insertData( "kraken", "bitcoin", ohlcvs )
    ohlcvs = exchangeKraken.fetch_ohlcv('LTC/USD', '1d', from_timestamp)

    insertData( "kraken", "litecoin", ohlcvs )
    ohlcvs = exchangeKraken.fetch_ohlcv('ETH/USD', '1d', from_timestamp)

    insertData( "kraken", "ethereum", ohlcvs )
}

function insertData ( exchange, crypto, ticker ) {
    MongoClient.connect(url, function(err, db){
      if(err) { return console.dir(err); }
      var mydb = db.db(dbname);

      // mydb.collection("priceByExchange2").createIndex( { "exchangeId": 1, "cryptocurrencyId": 1, "timestamp": 1 }, { unique: true  });
      // proccess.exit();
      mydb.collection("cryptocurrency").findOne( { "symbol": crypto }, function ( err, item ) {
        if ( err ) throw err
        cryptocurrencyId = item._id + ""
        mydb.collection("exchange").findOne( { "name": exchange }, function ( err, item ) {
          if ( err ) throw err
          exchangeId = item._id + ""
          asset = {
            "exchangeId" : exchangeId, 
            "cryptocurrencyId": cryptocurrencyId,
            "timestamp": ticker["timestamp"],
            "last": ticker["close"],
            "open": ticker["open"],
            "high": ticker["high"],
            "low": ticker["low"]
          }
          // volume = { "exchangeId": exchangeId, "cryptocurrencyId": cryptocurrencyId, "timestamp": ticker["timestamp"], "period": 24, "volume": ticker["baseVolume"] }
          mydb.collection("priceByExchange2").insert(asset, function(err, result) {
            if ( err ) {
              if (err.code != 11000) {
                throw err  
              }
            }
              // console.log('Inserted>>>');
            // console.log(result)
          });
          // mydb.collection("volumeTestExchange").insert(volume, function(err, result) {
          //   if ( err ) throw err
          //   console.log(result)
          // });
         db.close();
        });
        
      });
    
    });
}

// [{'exchangeId':poloniexID, 'cryptocurrencyId': btcusd, 'timestamp': ohlcvs[i][0], 'last': ohlcvs[i][4], 'open': ohlcvs[i][1], 'high': ohlcvs[i][2], 'low': ohlcvs[i][3]}]



(async function () {
  //let huobi     = new ccxt.huobi ()
  /*let okcoinusd = new ccxt.okcoinusd ({
    apiKey: 'YOUR_PUBLIC_API_KEY',
    secret: 'YOUR_SECRET_PRIVATE_KEY',
    })*/

  //console.log (kraken.id,    await kraken.loadMarkets ())
  //console.log (bitfinex.id,  await bitfinex.loadMarkets  ())
  //console.log (huobi.id,     await huobi.loadMarkets ())

  //console.log (kraken.id,    await kraken.fetchOrderBook (kraken.symbols[0]))
  //console.log (bitfinex.id,  await bitfinex.fetchTicker ('BTC/USD'))
  //console.log (huobi.id,     await huobi.fetchTrades ('ETH/CNY'))

  //console.log( await bitfinex.fetchTicker('BTC/USD') )

  /*console.log("===")
  console.log(kraken.has)
  console.log(kraken.symbols)
  console.log(kraken.currencies)*/


  // getKraken()
  var ex2 = new ccxt.poloniex({
    'rateLimit': 1,
    'enableRateLimit': true,
    // 'verbose': True,
  
  });
  // console.log(lastDay)
  // while (from_timestamp < to_timestamp){


    var exchanges = [
      {'name':'poloniex', 'symbols': ['BTC/USDT'], 'limit':2000}
    ];
    
    
    for (e in exchanges) {
    //  console.log(exchanges[e].name);
      ex = new ccxt[exchanges[e].name]({
        'rateLimit': 10000,
        'enableRateLimit': true,
        // 'verbose': True,
      
      });

      // symbols = ['BTC/USD','ETH/USD']
      symbols = exchanges[e].symbols
      // console.log(symbols)

      for (s in symbols) {
        var from_datetime = '2018-03-05T00:00:00'
        var to_datetime = '2018-03-11T00:00:00'
        var to_date_moment = moment(to_datetime);
        // console.log(to_date_moment.format("YYYY-MM-DD HH:mm:ss"));
        var from_date_moment = moment(from_datetime);
        var from_timestamp = ex2.parse8601(from_datetime)
        var to_timestamp = ex2.parse8601(to_datetime)
        // from_timestamp = ex2.parse8601(from_datetime)
        // to_timestamp = ex2.parse8601(to_datetime)
        var lastDay;
        var limit=3;
        // console.log(from_timestamp +'>>>'+to_timestamp);
        // console.log(from_date_moment.valueOf() +'>>>'+from_timestamp);

        // process.exit();

         console.log(exchanges[e].name + ':' + symbols[s])
         while (from_timestamp <= to_timestamp) {
          console.log(moment.unix(from_timestamp/1000).utcOffset(0).format("YYYY-MM-DD HH:mm:ss") + ">>"+moment.unix(to_timestamp/1000).utcOffset(0).format("YYYY-MM-DD HH:mm:ss"));
          var data = await ex.fetch_ohlcv(symbols[s], '1d', from_timestamp, limit);
          // console.log(data);
          for (d in data) {
            var ticker = []
            ticker["timestamp"] =  data[d][0];
            ticker["open"] = data[d][1];
            ticker["high"] = data[d][2];
            ticker["low"] = data[d][3];
            ticker["close"] = data[d][4];
            exchangeName = exchanges[e].name.charAt(0).toUpperCase() + exchanges[e].name.slice(1);
            // console.log(exchangeName+" | "+symbols[s]+" | "+ticker);
            if (ticker["timestamp"] <= to_timestamp) {
              console.log(moment.unix(ticker["timestamp"]/1000).utcOffset(0).format("YYYY-MM-DD HH:mm:ss"));
              insertData(exchangeName,symbols[s],ticker);
            }
          }

          // while (data != undefined && data.length == limit) {
          //   lastDay = data[data.length - 1][0];
          //   lastDay = moment.unix(lastDay/1000);
          //   // console.log(lastDay);
          //   lastDay.add(1,'d');
          //   // console.log(lastDay);
          //   from_timestamp = lastDay.format("YYYY-MM-DD hh:mm:ss");
          //   from_timestamp = ex2.parse8601(from_timestamp);
          //   if (from_timestamp > to_timestamp) {
          //     break;
          //   }
          //   console.log(moment.unix(from_timestamp/1000).format("YYYY-MM-DD hh:mm:ss") + ">>"+moment.unix(to_timestamp/1000).format("YYYY-MM-DD hh:mm:ss"));
          //   data = await ex.fetch_ohlcv(symbols[s], '1d', from_timestamp, limit);
          //   for (d in data) {
          //     var ticker = []
          //     ticker["timestamp"] =  data[d][0];
          //     ticker["open"] = data[d][1];
          //     ticker["high"] = data[d][2];
          //     ticker["low"] = data[d][3];
          //     ticker["close"] = data[d][4];
          //     exchangeName = exchanges[e].name.charAt(0).toUpperCase() + exchanges[e].name.slice(1);
          //     // console.log(exchangeName+" | "+symbols[s]+" | "+ticker);
          //     if (ticker["timestamp"] <= to_timestamp) {
          //       insertData(exchangeName,symbols[s],ticker);
          //     }
          //   }
          //   // console.log('insere 2...');
          //   // console.log(data);
          // }
          lastDay = data[data.length - 1][0];
          //console.log(moment.unix(ticker["timestamp"]/1000).format("YYYY-MM-DD hh:mm:ss"));
          lastDay = moment.unix(lastDay/1000);
          from_timestamp = lastDay.utcOffset(0).format("YYYY-MM-DD HH:mm:ss");
          console.log('Last:'+from_timestamp);
          lastDay.add(1,'d');
          // console.log(lastDay);
          from_timestamp = lastDay.utcOffset(0).format("YYYY-MM-DD HH:mm:ss");
          console.log('Next: '+from_timestamp);

          from_timestamp = ex2.parse8601(from_timestamp);
          // console.log('Real Next: '+moment.unix(from_timestamp/1000).format("YYYY-MM-DD hh:mm:ss"));
          if (from_timestamp > to_timestamp) {
            break;
          }
          // console.log(data);
          
          // if (data.length < limit) {
          //   // console.log('insere a ultima pagina');
          //   // console.log(data);
          //   console.log('ultima');
          //   for (d in data) {
          //     var ticker = []
          //     ticker["timestamp"] =  data[d][0];
          //     ticker["open"] = data[d][1];
          //     ticker["high"] = data[d][2];
          //     ticker["low"] = data[d][3];
          //     ticker["close"] = data[d][4];
          //     exchangeName = exchanges[e].name.charAt(0).toUpperCase() + exchanges[e].name.slice(1);
          //     // console.log(exchangeName+" | "+symbols[s]+" | "+ticker);
          //     if (ticker["timestamp"] <= to_timestamp) {
          //       insertData(exchangeName,symbols[s],ticker);
          //     }
          //   }
          //   break;
          // }
          
          // console.log(from_timestamp + ">>"+ to_timestamp);
        }
        
        // console.log(lastDay);
      }
    }
  // getKraken(from_timestamp)
  // var first = ohlcvs[0][0]
  // var last = ohlcvs[-1][0]
  // console.log('First candle epoch', first, exchange.iso8601(first))
  // console.log('Last candle epoch', last, exchange.iso8601(last))
  //from_timestamp += len(ohlcvs) * minute * 5
  // init_date_moment.add(1,'d');
  
  // lastDay = ex2.parse8601(init_date_moment.format("DDMMYYYY h:mm:ss"));
  // lastDay = ex2.parse8601(init_date_moment.format("DDMMYYYY h:mm:ss"))
  // lastDay = moment.unix(lastDay).format("DDMMYYYY h:mm:ss");
  // lastDay = moment.unix(lastDay/1000);
  // console.log(lastDay);
  // lastDay.add(1,'d');
  // console.log(lastDay);
  // console.log("LAST DAY: " + lastDay)
  // console.log(lastDay)
  // from_timestamp = lastDay.format("YYYY-MM-DD hh:mm:ss");
  // from_timestamp = ex2.parse8601(from_timestamp);
  // console.log(from_timestamp + ">>"+ to_timestamp);
  // from_timestamp = ex2.parse8601(init_date_moment.format("DDMMYYYY h:mm:ss"))
  // data += ohlcvs

  // }
//   getBitfinex()
  
  //insertData( "bitfinex", "bitcoin", ticker )
  /*console.log ( "===" + ticker )
  console.log ( "===" + ticker.toString() )
  for ( var i in ticker ) {
    //if ( ticker[i].pair == "btcusd" ) {
    console.log(i + " " + ticker[i])
  }

  console.log ( "** " + ticker.length )
  console.log ( "** " + ticker["bid"] )*/

    //console.log (okcoinusd.id, await okcoinusd.fetchBalance ())

  // sell 1 BTC/USD for market price, sell a bitcoin for dollars immediately
  //console.log (okcoinusd.id, await okcoinusd.createMarketSellOrder ('BTC/USD', 1))

  // buy 1 BTC/USD for $2500, you pay $2500 and receive ฿1 when the order is closed
  //console.log (okcoinusd.id, await okcoinusd.createLimitBuyOrder ('BTC/USD', 1, 2500.00))

  // pass/redefine custom exchange-specific order params: type, amount, price or whatever
  // use a custom order type
  //bitfinex.createLimitSellOrder ('BTC/USD', 1, 10, { 'type': 'trailing-stop' })
}) ();



// async function getBitfinex() {
//   let bitfinex  = exchangeBitfinex ()
//   var bticker = await bitfinex.fetchTicker('BTC/USD') 
//   insertData( "bitfinex", "bitcoin", bticker )
//   var lticker = await bitfinex.fetchTicker('LTC/USD')
//   insertData( "bitfinex", "litecoin", lticker )
//   var eticker = await bitfinex.fetchTicker('ETH/USD')
//   insertData( "bitfinex", "ethereum", eticker )

// }




//   var lticker = await bitfinex.fetchTicker('LTC/USD')

//   console.log( "-----" )
//   console.log(lticker["last"] + " " + lticker["timestamp"])

//   var eticker = await bitfinex.fetchTicker('ETH/USD')

//   console.log( "-----" )
//   console.log(eticker["last"] + " " + eticker["timestamp"])
  //console.log (okcoinusd.id, await okcoinusd.fetchBalance ())

  // sell 1 BTC/USD for market price, sell a bitcoin for dollars immediately
  //console.log (okcoinusd.id, await okcoinusd.createMarketSellOrder ('BTC/USD', 1))










//   //common constants

// var msec = 1000
// var minute = 60 * msec
// var hold = 30

// var from_datetime = '2018-03-12 00:00:00'
// var from_timestamp = exchangeKraken.parse8601(from_datetime)
// var init_date_moment = moment(from_datetime);

// //  -----------------------------------------------------------------------------

// var now = exchangeKraken.milliseconds()

// // -----------------------------------------------------------------------------



// // data = []
// while (from_timestamp < now){

// getKraken(from_timestamp)
// // var first = ohlcvs[0][0]
// // var last = ohlcvs[-1][0]
// // console.log('First candle epoch', first, exchange.iso8601(first))
// // console.log('Last candle epoch', last, exchange.iso8601(last))
// //from_timestamp += len(ohlcvs) * minute * 5
// init_date_moment.add(1,'d')

// from_timestamp = exchangeKraken.parse8601(init_date_moment.format("DDMMYYYY h:mm:ss"))
// // data += ohlcvs

// }
