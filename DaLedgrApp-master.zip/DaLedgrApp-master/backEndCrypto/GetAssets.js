'use strict';
// Retrieve
//var MongoClient = require('mongodb').MongoClient;
//var dbname = "cryptoshi"
//var url = "mongodb://45.33.117.44:27017/" + dbname
//var url = "mongodb://localhost:27017/" + dbname
const ccxt = require ('ccxt');
const f = require('util').format;
var MongoClient = require('mongodb').MongoClient;

const user = encodeURIComponent('cryptoshi77');
const password = encodeURIComponent('j5msi5kx92_');
const authMechanism = 'DEFAULT';
const host = "api.cryptoshiapp.com"
const dbname = "cryptoshi"
const authSrc = "admin"
const url = f('mongodb://%s:%s@%s:27017/%s?authMechanism=%s&authSource=%s',
  user, password, host, dbname, authMechanism, authSrc);


const krakenstr = "Kraken"
const bitfinexstr = "BitFinex"
const bitstampstr = "Bitstamp"
const poloniexstr = "Poloniex"
const bittrexstr = "Bittrex"
const btcstr = "Bitcoin"
const ethstr = "Ethereum"
const ltcstr = "Litecoin"
const usdstr = "dollar"
const eurstr = "euro";
(async function () {
  //let huobi     = new ccxt.huobi ()
  /*let okcoinusd = new ccxt.okcoinusd ({
    apiKey: 'YOUR_PUBLIC_API_KEY',
    secret: 'YOUR_SECRET_PRIVATE_KEY',
    })*/

  //console.log (kraken.id,    await kraken.loadMarkets ())
  //console.log (bitfinex.id,  await bitfinex.loadMarkets  ())
  //console.log (huobi.id,     await huobi.loadMarkets ())

  //console.log (kraken.id,    await kraken.fetchOrderBook (kraken.symbols[0]))
  //console.log (bitfinex.id,  await bitfinex.fetchTicker ('BTC/USD'))
  //console.log (huobi.id,     await huobi.fetchTrades ('ETH/CNY'))

  //console.log( await bitfinex.fetchTicker('BTC/USD') )

  /*console.log("===")
  console.log(kraken.has)
  console.log(kraken.symbols)
  console.log(kraken.currencies)*/
  getKraken()
  getBitfinex()
  getBitstamp()
  //getPoloniex() // how to handle different symbols
  //getBittrex() // no data
  //insertData( "bitfinex", "bitcoin", ticker )
  /*console.log ( "===" + ticker )
  console.log ( "===" + ticker.toString() )
  for ( var i in ticker ) {
    //if ( ticker[i].pair == "btcusd" ) {
    console.log(i + " " + ticker[i])
  }

  console.log ( "** " + ticker.length )
  console.log ( "** " + ticker["bid"] )*/

    //console.log (okcoinusd.id, await okcoinusd.fetchBalance ())

  // sell 1 BTC/USD for market price, sell a bitcoin for dollars immediately
  //console.log (okcoinusd.id, await okcoinusd.createMarketSellOrder ('BTC/USD', 1))

  // buy 1 BTC/USD for $2500, you pay $2500 and receive ฿1 when the order is closed
  //console.log (okcoinusd.id, await okcoinusd.createLimitBuyOrder ('BTC/USD', 1, 2500.00))

  // pass/redefine custom exchange-specific order params: type, amount, price or whatever
  // use a custom order type
  //bitfinex.createLimitSellOrder ('BTC/USD', 1, 10, { 'type': 'trailing-stop' })
}) ();

/*async function getBitstamp() {
  let bitstamp = bew ccxt.bitstamp()
  var bticker = await bitstamp.fetchTicker('BTC/USD')
  //nsertData( "bitstamp
}*/
async function getKraken() {

  let kraken = new ccxt.kraken()
  await kraken.loadMarkets()
  var bticker = await kraken.fetchTicker('BTC/USD') 
  var lticker = await kraken.fetchTicker('LTC/USD') 
  var eticker = await kraken.fetchTicker('ETH/USD') 

  //var beticker = await kraken.fetchTicker('BTC/EUR') 
  //var leticker = await kraken.fetchTicker('LTC/EUR') 
  //var eeticker = await kraken.fetchTicker('ETH/EUR') 

  var eid = await getExchangeId( krakenstr )
  const btcid = await getCurrencyId( btcstr )
  const ltcid = await getCurrencyId ( ltcstr )
  const ethid = await getCurrencyId ( ethstr )
  const usdid = await getCurrencyId( usdstr )
  const eurid = await getCurrencyId( eurstr )
  //console.log( eid + " " + c1id + " " + c2id + " " + bticker )
  insertData( eid, btcid, usdid, bticker )
  insertData( eid, ltcid, usdid, lticker )
  insertData( eid, ethid, usdid, eticker )

  //insertData( eid, btcid, eurid, beticker )
  //insertData( eid, ltcid, eurid, leticker )
  //insertData( eid, ethid, eurid, eeticker )
}

async function getBitfinex() {
  let bitfinex  = new ccxt.bitfinex ({ verbose: true })
  var bticker = await bitfinex.fetchTicker('BTC/USD') 
  var lticker = await bitfinex.fetchTicker('LTC/USD')
  var eticker = await bitfinex.fetchTicker('ETH/USD')
  
  //var beticker = await bitfinex.fetchTicker('BTC/EUR') 
  //var leticker = await bitfinex.fetchTicker('LTC/EUR')
  //var eeticker = await bitfinex.fetchTicker('ETH/EUR')

  var eid = await getExchangeId( bitfinexstr )
  const btcid = await getCurrencyId( btcstr )
  const ltcid = await getCurrencyId ( ltcstr )
  const ethid = await getCurrencyId ( ethstr )
  const usdid = await getCurrencyId( usdstr )
  const eurid = await getCurrencyId( eurstr )
  insertData( eid, btcid, usdid, bticker )
  insertData( eid, ltcid, usdid, lticker )
  insertData( eid, ethid, usdid, eticker )

  //insertData( eid, btcid, eurid, beticker )
  //insertData( eid, ltcid, eurid, leticker )
  //insertData( eid, ethid, eurid, eeticker )
}

async function getBitstamp(){
  var bitstamp = new ccxt.bitstamp()

  var bticker = await bitstamp.fetchTicker('BTC/USD') 
  var lticker = await bitstamp.fetchTicker('LTC/USD')
  var eticker = await bitstamp.fetchTicker('ETH/USD')

  var eid = await getExchangeId( bitstampstr )
  const btcid = await getCurrencyId( btcstr )
  const ltcid = await getCurrencyId ( ltcstr )
  const ethid = await getCurrencyId ( ethstr )
  const usdid = await getCurrencyId( usdstr )
  const eurid = await getCurrencyId( eurstr )
  insertData( eid, btcid, usdid, bticker )
  insertData( eid, ltcid, usdid, lticker )
  insertData( eid, ethid, usdid, eticker )
}

async function getPoloniex() {
  var poloniex = new ccxt.poloniex()
  await poloniex.loadMarkets()
  //console.log(poloniex.symbols)

  var bticker = await poloniex.fetchTicker('BTC/USDT') 
  var lticker = await poloniex.fetchTicker('LTC/USDT')
  var eticker = await poloniex.fetchTicker('ETH/USDT')

  var eid = await getExchangeId( poloniexstr )
  const btcid = await getCurrencyId( btcstr )
  const ltcid = await getCurrencyId ( ltcstr )
  const ethid = await getCurrencyId ( ethstr )
  const usdid = await getCurrencyId( usdstr )
  const eurid = await getCurrencyId( eurstr )
  insertData( eid, btcid, usdid, bticker )
  insertData( eid, ltcid, usdid, lticker )
  insertData( eid, ethid, usdid, eticker )

}

async function getBittrex(){
  var bittrex = new ccxt.bittrex()
  //await bittrex.loadMarkets()
  //console.log(poloniex.symbols)

  var bticker = await bittrex.fetchTicker('BTC/USDT') 
  var lticker = await bittrex.fetchTicker('LTC/USDT')
  var eticker = await bittrex.fetchTicker('ETH/USDT')

  var eid = await getExchangeId( bittrexstr )
  const btcid = await getCurrencyId( btcstr )
  const ltcid = await getCurrencyId ( ltcstr )
  const ethid = await getCurrencyId ( ethstr )
  const usdid = await getCurrencyId( usdstr )
  const eurid = await getCurrencyId( eurstr )
  insertData( eid, btcid, usdid, bticker )
  insertData( eid, ltcid, usdid, lticker )
  insertData( eid, ethid, usdid, eticker )


}
async function insertData ( exchange, currency1, currency2, ticker ) {
  MongoClient.connect(url, function(err, db){
    if(err) { return console.dir(err); }
    const mydb = db.db(dbname);
    console.log("=> exchange:" + exchange + " curr1:" + currency1 + " curr2:" + currency2 );

    mydb.collection("assetPair").findOne( { "exchangeId": exchange+"", "currencyId1": currency1+"", "currencyId2": currency2+"" }, function ( err, item ) {
      if (err) throw err;
      console.log(item)
      if ( item == null ) {
        console.log("pair not found for the given exchange")
        //return -1
      } else {
        var asset = { "assetPairId": item._id+"", "timestamp": ticker["timestamp"], "last": ticker["last"], "bid": ticker["bid"], "ask": ticker["last"] };
        var volume = { "assetPairId": item._id+"", "timestamp": ticker["timestamp"], "period": 24, "volume": ticker["baseVolume"] };
        mydb.collection("priceByExchange").insert(asset, function(err, result) {
          if ( err ) throw err;
          console.log(result);
        });
        mydb.collection("volumeExchange").insert(volume, function(err, result) {
          if ( err ) throw err
          console.log(result)
        });
      }
      db.close();
    });
    
  });
  
}

async function getCurrencyId ( currency ) {
  const db = await MongoClient.connect(url);
  const mydb = db.db(dbname);
  //const r = await mydb.collection('currency').find({"name":currency}).toArray();
  const r = await mydb.collection('currency').findOne({"name":currency});
  await db.close()
  return r._id
}
/*async function getCurrencyId ( currency ) {
  MongoClient.connect(url, function(err, db){
    if(err) { return console.dir(err); }
    const mydb = db.db(dbname);
    mydb.collection('currency').findOne( {"name": currency}, function(err, item){
      if (err) throw err;
      db.close();
      console.log(item)
      return item._id
    });
  });
}*/

async function getExchangeId ( exchange ) {
  const db = await MongoClient.connect(url);
  const mydb = db.db(dbname);
  //const r = await mydb.collection('exchange').find({"name":exchange}).toArray();
  const r = await mydb.collection('exchange').findOne({"name":exchange});
  await db.close()
  return r._id
}
/*async function getExchangeId ( exchange ) {
  await MongoClient.connect(url, function(err, db){
    if(err) { return console.dir(err); }
    const mydb = db.db(dbname);
    await mydb.collection('exchange').findOne( {"name": exchange}, function(err, item){
      if (err) throw err;
      db.close();
      console.log(item)
      return item._id
    });
  });
}*/

/*
  var lticker = await bitfinex.fetchTicker('LTC/USD')

  console.log( "-----" )
  console.log(lticker["last"] + " " + lticker["timestamp"])

  var eticker = await bitfinex.fetchTicker('ETH/USD')

  console.log( "-----" )
  console.log(eticker["last"] + " " + eticker["timestamp"])*/
  //console.log (okcoinusd.id, await okcoinusd.fetchBalance ())

  // sell 1 BTC/USD for market price, sell a bitcoin for dollars immediately
  //console.log (okcoinusd.id, await okcoinusd.createMarketSellOrder ('BTC/USD', 1))

