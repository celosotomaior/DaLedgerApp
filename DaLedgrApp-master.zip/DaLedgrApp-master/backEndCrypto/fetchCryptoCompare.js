"use strict";

const ccxt       = require ('../../ccxt.js')
const asciichart = require ('asciichart')
const asTable    = require ('as-table')
const log        = require ('ololog').configure ({ locate: false })

require ('ansicolor').nice



//-----------------------------------------------------------------------------

  ;(async function main () {

    // experimental, not yet implemented for all exchanges
    // your contributions are welcome ;)

    const index = 4 // [ timestamp, open, high, low, close, volume ]
    const ohlcv = await new ccxt.cex ().fetchOHLCV ('BTC/USD', '1m')
    console.log(ohlcv)
    // const lastPrice = ohlcv[ohlcv.length - 1][index] // closing price
    // const series = ohlcv.slice (-80).map (x => x[index]) // closing price
    // const bitcoinRate = ('₿ = $' + lastPrice).green
    // const chart = asciichart.plot (series, { height: 15, padding: '            ' })
    // log.yellow ("\n" + chart, bitcoinRate, "\n")
    // process.exit ()


}) ()
  // Connect to the db
MongoClient.connect(url , function(err, db) {
  if(err) { return console.dir(err); }
  var mydb = db.db(dbname);


// // Retrieve
// var MongoClient = require('mongodb').MongoClient;
// var dbname = "cryptoshi"
// //var url = "mongodb://45.33.117.44:27017/" + dbname
// var url = "mongodb://localhost:27017/" + dbname


var moment = require('moment');
moment().format("dddd, MMMM Do YYYY, h:mm:ss a");

var date_init = moment("2016-12-25");
var date_end = moment("2016-12-28");
var tmp = date_init
while ( true ) {
	tmp = tmp.add(1, 'd')
	console.log(tmp)
	if ( tmp > date_end )
		break

	var asset = new ccxt.poloniex ().fetchOHLCV ('BTC/USD', '1m')

   var priceHistorical = [{ 'exchangeID':bitfinexID, 'timestamp': Date(), 'open': 'asset.open', 'high': 'asset.high', 'low': 'asset.low', 'close': 'asset.close','volume': 'asset.volume' }];

    mydb.collection("testAsset").insertMany(priceHistorical, function(err, result) {
      if ( err ) throw err
      console.log(result)
    });
};
 });