"use strict";

const ccxt      = require ('../../ccxt.js')
const asTable   = require ('as-table')
const log       = require ('ololog').configure ({ locate: false })

require ('ansicolor').nice

//-----------------------------------------------------------------------------

process.on ('uncaughtException',  e => { log.bright.red.error (e); process.exit (1) })
process.on ('unhandledRejection', e => { log.bright.red.error (e); process.exit (1) })

//-----------------------------------------------------------------------------

let human_value = function (price) {
    return typeof price === 'undefined' ? 'N/A' : price
}

//-----------------------------------------------------------------------------

let test = async function (exchange, symbol) {

    try {

        await exchange.loadMarkets ()

        if (symbol in exchange.markets) {

            let ticker = await exchange.fetchTicker (symbol)

            log (exchange.id.green, symbol.green, 'ticker',
                ticker['datetime'],
                'high: '    + human_value (ticker['high']),
                'low: '     + human_value (ticker['low']),
                'bid: '     + human_value (ticker['bid']),
                'ask: '     + human_value (ticker['ask']),
                'volume: '  + human_value (ticker['quoteVolume']))
        } else {

            // do nothing or throw an error
            log.bright.yellow (exchange.id + ' does not have ' + symbol)
        }

    } catch (e) {

        if (e instanceof ccxt.DDoSProtection) {
            log.bright.yellow (exchange.id, '[DDoS Protection]')
        } else if (e instanceof ccxt.RequestTimeout) {
            log.bright.yellow (exchange.id, '[Request Timeout]')
        } else if (e instanceof ccxt.AuthenticationError) {
            log.bright.yellow (exchange.id, '[Authentication Error]')
        } else if (e instanceof ccxt.ExchangeNotAvailable) {
            log.bright.yellow (exchange.id, '[Exchange Not Available]')
        } else if (e instanceof ccxt.ExchangeError) {
            log.bright.yellow (exchange.id, '[Exchange Error]')
        } else if (e instanceof ccxt.NetworkError) {
            log.bright.yellow (exchange.id, '[Network Error]')
        } else {
            throw e
        }
    }


// Retrieve
var MongoClient = require('mongodb').MongoClient;
var dbname = "exampleDb"
var url = "mongodb://45.33.117.44/" + dbname
// Connect to the db
MongoClient.connect(url , function(err, db) {
  if(err) { return console.dir(err); }
  var mydb = db.db(dbname);
  var priceByCrypto = [{'cryptocurrency':'assetContent.symbol', 'timestamp': Date()}];
  mydb.collection("currency").insertMany(priceByCrypto, function(err, result) {
    if ( err ) throw err
    console.log(result)
    });
  ///////////////////////////////////////////////////////////////
  var priceByExchange = [{ 'exchangeID':exchange.id.green, 'timestamp': Date(), 'cryptocurrency': 'assetContent.symbol', 'last': 'last', 'bid': 'bid', 'ask': 'ask' }];

    mydb.collection("assetExchange").insertMany(priceByExchange, function(err, result) {
      if ( err ) throw err
      console.log(result)
    });

    var volume = [{ 'exchangeID': exchange.id.green, 'timestamp': Date(),'period':'24h', 'high': 'high', 'low':'low', 'volume': 'volume'}];
    mydb.collection("volumeExchange").insertMany(volume, function(err, result) {
      if ( err ) throw err
      console.log(result)
      });
    var currencies = [{'currency':"US Dollar", 'timestamp': Date(), 'currencySymbol':"USD", 'exchangeRate':'3.2'}];
    mydb.collection("currency").insertMany(currencies, function(err, result) {
      if ( err ) throw err
      console.log(result)
      });

    });

}
//-----------------------------------------------------------------------------

const symbol = 'BTC/USD'

//-----------------------------------------------------------------------------

async function main () {

    let exchanges = []

    // instantiate all exchanges
    await Promise.all (ccxt.exchanges.map (async id => {
        let exchange = new (ccxt)[id] ()
        exchanges.push (exchange)
        await test (exchange, symbol)
    }))

    let succeeded = exchanges.filter (exchange => exchange.markets ? true : false).length.toString ().bright.green
    let failed = exchanges.filter (exchange => exchange.markets ? false : true).length
    let total = ccxt.exchanges.length.toString ().bright.white
    console.log (succeeded, 'of', total, 'exchanges loaded', ('(' + failed + ' errors)').red)
}

main ()
