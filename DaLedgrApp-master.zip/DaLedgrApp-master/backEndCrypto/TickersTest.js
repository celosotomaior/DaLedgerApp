"use strict";
const ccxt = require ('ccxt')
let symbol = 'BTC/USDT'

// Retrieve
var MongoClient = require('mongodb').MongoClient;
var dbname = "cryptoshi"
var url = "mongodb://45.33.117.44:27017/" + dbname
;(async () => {

  const exchanges = [
    'bittrex',
    'poloniex',
    'kraken',
    'bitstamp'

  ]
  
  // recuperar symbol da requisicao
  if (symbol == 'yyyBTC/USDT') {
    const tickers = {}

    await Promise.all (exchanges.map (exchangeId =>

      new Promise (async (resolve, reject) => {

        const exchange = new ccxt[exchangeId] ({ enableRateLimit: true })

              // while (true) {

        const ticker = await exchange.fetchTicker (symbol)
        tickers[exchangeId] = ticker

        Object.keys (tickers).map (exchangeId => {
            const ticker = tickers[exchangeId]
            console.log ("====")
            console.log (ticker['datetime'], exchangeId, ticker['bid'], ticker['ask'])
          })
        // Connect to the db
        /*MongoClient.connect(url , function(err, db) {
          if(err) { return console.dir(err); }
          var mydb = db.db(dbname);
          var priceByCrypto = [{'cryptocurrency':'assetContent.symbol', 'timestamp': Date()}];
          mydb.collection('assetExchange').find().toArray(function(err, items) {
              console.log(items)
              });
          });*/
     })))
  }
    // var bitfinexID = 0
    // mydb.collection("exchange").findOne({name:"bitfinex"}, function(err, result){

}) ()

