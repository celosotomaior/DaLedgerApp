//
//  TechnicalAnalysisCollectionViewCell.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/21/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit

class TechnicalAnalysisCollectionViewCell: UICollectionViewCell {
    
    let suggestionsString = [ "Strong Buy", "Buy", "Hold", "Sell", "Strong Sell" ]
    
    var suggestion = 0
    var currentAngle = 0.0
    var meterArrow : UIImageView!
    
//    var exchangeId = "5a8c197fbde6ba32a1884711"     //bitfinex
//    var cryptocurrencyId = "5a8c197fbde6ba32a18846c2"   //BTC
//    var currency = "1"
    
    var suggestionLabel : UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        print("normal init")
        fillTechAnalysis()
//        rotateArrow()
        
//        let timer = Timing.shared.setInterval(5) {
//            self.rotateArrow()
//            print(self.currentAngle)
//            var stats = BackEndConnection.shared.getStats(eid: self.exchangeId, ccid: self.cryptocurrencyId, cid: self.currency, processStats: self.updatePrices)
//        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        print("coder init")
        fillTechAnalysis()
//        Timing.shared.setInterval(5) {
//            self.rotateArrow()
////            print(self.currentAngle)
//            var stats = BackEndConnection.shared.getStats(eid: self.exchangeId, ccid: self.cryptocurrencyId, cid: self.currency, processStats: self.updatePrices)
//
//        }
        //        fatalError("init(coder:) has not been implemented")
    }
    
//    func updatePrices(stats: BasicStats) {
//        DispatchQueue.main.async {
////            self.suggestion = Int(stats.suggestion)
//            self.suggestion = Int(arc4random())%2
//            self.suggestionLabel.text = self.suggestionsString[self.suggestion]
////            UIView.animate(withDuration: 2, animations: {
////                self.meterArrow.transform = CGAffineTransform(rotationAngle: CGFloat(Double.pi/2))
////
////            })
//        }
//    }
    
    
    func fillTechAnalysis() {
        suggestionLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 186, height: 50))
        suggestionLabel.font = UIFont(name: "AvenirNext-Regular", size: 36)
        suggestionLabel.textColor = UIColor(hex: "32C4B8")
        suggestionLabel.text = suggestionsString[self.suggestion]
        
        let meterImage = UIImageView(image: #imageLiteral(resourceName: "imeter"))
//        meterImage.center = CGPoint(x: meterImage.bounds.width/2 + 40, y: bounds.height/2 + 20)
        meterImage.frame = CGRect(x: 25, y: 0, width: meterImage.bounds.width, height: meterImage.bounds.height)
        
        suggestionLabel.center = CGPoint(x: bounds.width - 100, y: bounds.height/2)
        
        meterArrow = UIImageView(image: #imageLiteral(resourceName: "meter_arrow"))
        meterArrow.bounds = CGRect(x: 0, y:0, width: meterArrow.bounds.width, height: meterArrow.bounds.height*2 - 8)
        meterArrow.contentMode = .top
        meterArrow.center = meterImage.center.applying(CGAffineTransform(translationX: 0, y: meterImage.bounds.height/2 - 4) )
        
        self.addSubview(suggestionLabel)
        self.addSubview(meterImage)
        self.addSubview(meterArrow)
    }
    
    func rotateArrow(){
        var angle = 0.0
        switch suggestion {
        case 0:
            angle = -Double.pi/2
        case 1:
            angle = -Double.pi/4
        case 2:
            angle = 0.0
        case 3:
            angle = Double.pi/4
        case 4:
            angle = Double.pi/2
        default:
            angle = 0
        }
        
        var tmp = angle
        angle = angle - currentAngle
        self.meterArrow.layer.removeAllAnimations()
        UIView.animate(withDuration: 2, animations: {
            self.meterArrow.transform = CGAffineTransform(rotationAngle: CGFloat(angle))
            
        })
        currentAngle = tmp
//        self.meterArrow.transform.
    }
}
