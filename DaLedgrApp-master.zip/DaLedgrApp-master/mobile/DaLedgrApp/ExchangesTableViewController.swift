//
//  ExchangesTableViewController.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/26/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit

class ExchangesTableViewController: UITableViewController {

//    var exchanges = [Exchange]()
    
//    var exchanges = [ "bitfinex", "kraken" ]
    var exchanges = [String]()
    var lastChoice = 0
    
    public var dimissMe = false
    public var selectedExchange = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        BackEndConnection.shared.getAllExchanges(processExchanges: { (exchanges) in
            for e in exchanges {
                self.exchanges.append(e.name)
            }
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        })
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return exchanges.count
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.dequeueReusableCell(withIdentifier: "exchangeCell", for: indexPath) as! ExchangeSettingsTableViewCell
       
        
        
        lastChoice = indexPath.row
        
        tableView.reloadData()
        //        self.viewDidLoad()
        
        if ( dimissMe ){
            // This is true if this was called from the HomeViewController to set the default for an existing crypto
            selectedExchange = self.exchanges[indexPath.row]
            print("selectedExchange \(selectedExchange)")
            self.dismiss(animated: true, completion: nil)
        } else {
            // This is true when this was called from settings
            UserInterfaceCoreData.shared.setDefaultExchange(defaultExchange: self.exchanges[indexPath.row])
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "exchangeCell", for: indexPath) as! ExchangeSettingsTableViewCell

        // Configure the cell...
//        if ( indexPath.row)
//        cell.currencyLabel.text = exchanges[indexPath.row].name
        cell.exchangeLabel.text = self.exchanges[indexPath.row]
        let reference = UIApplication.shared.delegate as! AppDelegate
        if ( reference.defaultExchange == exchanges[indexPath.row] ) {
            cell.checkBoxImage.image = #imageLiteral(resourceName: "checked")
        }
        else {
            cell.checkBoxImage.image = nil
        }
        
        return cell
    }
    
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
//    @IBAction func unwindToExchangesTableView(segue:UIStoryboardSegue) { }

    
}
