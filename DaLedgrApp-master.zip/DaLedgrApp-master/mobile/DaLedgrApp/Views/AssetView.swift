//
//  AssetView.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/20/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit

class AssetView: UICollectionViewCell {

    @IBOutlet weak var cryptoLabel: UILabel!
    @IBOutlet weak var symbolLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var symbolUIImage: UIImageView!
    @IBOutlet weak var exchangeButton: UIButton!
    
    public var cryptoName : String = ""
    public var cryptoSymbol : String = ""
    public var cryptoPrice : String = ""
    
//    init () {
//        cryptoLabel.text = cryptoName
//        symbolLabel.text = cryptoSymbol
//        priceLabel.text = cryptoPrice
//    }
//    
//    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
