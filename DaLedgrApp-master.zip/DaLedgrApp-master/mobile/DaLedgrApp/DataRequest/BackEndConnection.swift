//
//  BackEndConnection.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/7/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import Foundation
import UIKit

/**
 Access to our data through a REST API
 */
class BackEndConnection{
    // Use me like: DRSingleton.shared
    public static let shared = BackEndConnection()

    private let url : String = ""
//    private let host : String = "http://45.33.117.44:3000/"
    private let host : String = "https://api.cryptoshiapp.com/"
    private var request : URLRequest
    private enum method {
        case GET
        case POST
        case PUT
        case DELETE
    }
    // Initialize the singleton
    init() {
        request = URLRequest(url: URL(string: host)!)
//        request.httpMethod = "POST"
//        let postString = "email=\(email)"
//        request.httpBody = postString.data(using: .utf8)
    }
    
    // This is the only function that should be called from here
    private func sendRequest(route: String, method: BackEndConnection.method, processData: @escaping ( _ json: [String:Any] ) -> Any  ){
        //Set the params for the request
//        var postString = ""
//        for (k,v) in params {
//            postString += "\(k)=\(v)"
//        }
        request.url = URL(string: "\(host)\(route)")
        switch method {
        case .GET:
            request.httpMethod = "GET"
            break
        case .POST:
            request.httpMethod = "POST"
            break
        case .PUT:
            request.httpMethod = "PUT"
            break
        case .DELETE:
            request.httpMethod = "DELETE"
            break
        default:
            return
        }
        //request.httpBody = postString.data(using: .utf8)
        
        // Make the request
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            // check for fundamental networking error
            guard let data = data, error == nil else {
                print("error = \(String(describing: error))")
                return
            }
            
            // check for http errors
            if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {
                print("statusCode should be 200, but is \(httpStatus.statusCode)")
                print("response = \(String(describing: response))")
            }
    
            let responseString = String(data: data, encoding: .utf8)
//            print("responseString = \(responseString!)")
            
            do {
                guard let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String:Any] else {
                    print("error parsing JSON from server response")
                    return
                }
                if ( json["status"] as! Int == 0 ) {
//                    print("responseString = \(responseString!)")
                    processData(json)
                } else {
                    print("url: \(self.request.httpMethod!) \(self.request.url!.absoluteString)")
                    print("responseString: \(responseString!)")
                }
//                print(json["status"] )
                
                
            } catch {
                print("error parsing JSON from server response")
                return
            }
            
        }
        task.resume()
    }
    
//    public func getUserExchanges() -> [Exchange] {
//        var params = [ "exchange" : "user" ]
//        getPostData(params: params, processData: parseExchanges)
//        
//        getPostData(params: <#T##[String : String]#>, processData: <#T##(Any) -> Any#>)
//    }
    
    public func getAllExchanges() {
        
    }
    
    public func getUserCryptocoins() {
//        let params = [ "cryptocoin" : "user", "id" : (UIApplication.shared.delegate as! AppDelegate).uuid ]
        
    }
    
    public func getAllTips() {
        
    }
    
    
    
//    // Inserts the uuid of a user in the DB
//    public func insertUser() -> User {
//        let uuid = (UIApplication.shared.delegate as! AppDelegate).uuid
//        let type = (UIApplication.shared.delegate as! AppDelegate).type
//        var user = User()
//        sendRequest(route: "user/\(uuid)/\(type)", method: .POST, processData: { (json) -> Any in
//            print("insertUser")
//            return User(type: type, uuid: uuid)
//        })
//        return user
//    }
//    
//    // Gets the info about a user from the BackEnd in an User object
//    public func getUserInfo() -> User {
//        var user = User()
//        let uuid = (UIApplication.shared.delegate as! AppDelegate).uuid
//        sendRequest(route: "user/\(uuid)", method: .GET, processData: { ( json: [String:Any] ) -> Any in
////            print(out as! User)
//            
////            let user = User(out.)
//            print("getuserinfo")
//            let status = json["status"]
////            json["exchange"]
////            json[""]
//            return user
//        })
//        return user
//    }
    
//    public func getStats(eid: String, ccid: String, cid: String, processStats: @escaping (_ s: BasicStats) ) {
//        sendRequest(route: "stats/\(eid)/\(ccid)/\(cid)", method: .GET, processData: { (json: [String:Any]) -> Any in
//            var stats = BasicStats()
//            stats.price         = json["price"] as! Int
//            stats.suggestion    = json["suggestion"] as! Int
//            stats.hour          = json["hour"] as! Int
//            stats.day           = json["day"] as! Int
//            stats.week          = json["week"] as! Int
//            stats.month         = json["month"] as! Int
//            processStats(stats)
//        })
        
//    }
    
    public func getStats(eid: String, ccid: String, cid: String, processStats: @escaping (_: BasicStats) -> Void ) {
        sendRequest(route: "stats/\(eid)/\(ccid)/\(cid)", method: .GET, processData: { (json: [String:Any]) -> Any in
            var stats = BasicStats()
            stats.price         = json["price"] as! NSNumber
            stats.suggestion    = json["suggestion"] as! NSNumber
            stats.hour          = json["hour"] as! NSNumber
            stats.day           = json["day"] as! NSNumber
            stats.week          = json["week"] as! NSNumber
            stats.month         = json["month"] as! NSNumber
            print(stats)
            processStats(stats)
            return stats
//            return
        })
    }
    
    public func getAllCryptocurrencies( processCryptocurrencies: @escaping (_: [Cryptocurrency] ) -> Void ){
        sendRequest(route: "getAllCC", method: .GET, processData: { (json: [String:Any]) -> Any in
            var ccoins = [Cryptocurrency]()
            let ccs = json["cryptos"] as! [NSDictionary]
            for c in ccs {
                // FIXME
//                ccoins.append( Cryptocurrency(name: c.value(forKey: "name") as! String , symbol: c.value(forKey: "symbol") as! String, id: c.value(forKey: "id") as! String) )
                ccoins.append( Cryptocurrency(c.value(forKey: "name") as! String , c.value(forKey: "symbol") as! String, c.value(forKey: "id") as! String) )
            }
            processCryptocurrencies(ccoins)
            return ccoins
            })
    }
    
    public func getAllExchanges( processExchanges: @escaping (_: [Exchange] ) -> Void ){
        sendRequest(route: "getAllEx", method: .GET, processData: { (json: [String:Any]) -> Any in
            var exchanges = [Exchange]()
            let ex = json["exchanges"] as! [NSDictionary]
            
            for e in ex {
                exchanges.append( Exchange(name: e.value(forKey: "name") as! String, id: e.value(forKey: "id") as! String) )
            }
            processExchanges(exchanges)
            
            return exchanges
        })
    }
    
    public func getAllCurrencies( processCurrencies: @escaping (_: [Currency] ) -> Void ){
        sendRequest(route: "getAllCurrencies", method: .GET, processData: { (json: [String:Any]) -> Any in
            var currencies = [Currency]()
            let cus = json["currencies"] as! [NSDictionary]
            
            for c in cus {
                currencies.append( Currency(name: c.value(forKey: "name") as! String, symbol: c.value(forKey: "symbol") as! String, id: c.value(forKey: "id") as! String) )
            }
            processCurrencies(currencies)
            return currencies
        })
    }
    
//    "/exchangeId/cyrptocurrencyId/period last one could be: hour, day, week, month"
    public func getChartData( eid: String, ccid: String, period: String, processData: @escaping (_: [(Double,Double)] ) -> Void ){
        sendRequest(route: "getChartData/\(eid)/\(ccid)/\(period)", method: .GET, processData: { (json: [String:Any])-> Any in
            var data = [(Double,Double)]()
            let points = json["data"] as! [NSDictionary]
            
            for p in points {
                let timestamp = p.value(forKey: "timestamp") as! Double
                let price = p.value(forKey: "price") as! Double
//                data.append( timestamp:price )
                data.append((timestamp, price))
            }
            
            processData(data)
            return data
        })
    }
    
    public func addAlert() -> User {
        let uuid = (UIApplication.shared.delegate as! AppDelegate).uuid
        var user = User()
        sendRequest(route: "user/\(uuid)", method: .POST, processData: { (json) -> Any in
            print("insertUser")
            //            return User(type: type, uuid: uuid)
        })
        return user
    }
    
//    public func getAllAlerts( processAlerts: @escaping (_: [Alert] ) -> Void ){
//        let uuid = (UIApplication.shared.delegate as! AppDelegate).uuid
//        print("request uuid: \(uuid)")
//        sendRequest(route: "alerts/getAllAlerts/\(uuid)", method: .GET, processData: { (json: [String:Any]) -> Any in
//            var alerts = [Alert]()
//            let alertDictionary = json["alerts"] as! [NSDictionary]
//
//            for a in alertDictionary {
//                var valueNumber:NSNumber = 0
//                let valueString = a.value(forKey: "value") as! String
//                if let valueInt = Int(valueString) {
//                    valueNumber = NSNumber(value:valueInt)
//                }
//                alerts.append( Alert(pair: a.value(forKey: "pair") as! String, type: a.value(forKey: "type") as! NSNumber, value: valueNumber) )
//            }
//            processAlerts(alerts)
//            return alerts
//        })
//    }
//    public func getAllAlerts() {
//        
//        let url = NSURL(string: "http://localhost:3000/alerts/getAllAlerts/52FCDB93-CF9A-4AF9-B353-EEC910390701")
//        URLSession.shared.dataTask(with: url! as URL) { (data, response, error) in
//            
//            if error != nil {
//                print(error)
//                return
//            }
//            
//            do {
//                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers)
//                
//                let appDelegate = UIApplication.shared.delegate as! AppDelegate
//                appDelegate.alerts = [Alert]()
//                
//                for dictionary in json as! [[String: AnyObject]] {
//                    
//                    let alert = Alert()
//                    video.title = dictionary["title"] as? String
//                    video.thumbnailImageName = dictionary["thumbnail_image_name"] as? String
//                    
//                    let channelDictionary = dictionary["channel"] as! [String: AnyObject]
//                    
//                    let channel = Channel()
//                    channel.name = channelDictionary["name"] as? String
//                    channel.profileImageName = channelDictionary["profile_image_name"] as? String
//                    
//                    video.channel = channel
//                    
//                    self.videos?.append(video)
//                }
//                
//                self.collectionView?.reloadData()
//                
//            } catch let jsonError {
//                print(jsonError)
//            }
//            
//            
//            
//            }.resume()
//    }
    
    public func getInitParams( processInitParams: @escaping ( _ cryptocurrencies : [Cryptocurrency], _ currencies: [Currency], _ exchanges: [Exchange], _ pairs: [AssetPair] ) -> Void ){
        sendRequest(route: "getInitParams/", method: .GET, processData: { (json: [String:Any]) -> Any in
            let currenciesD = json["currencies"] as! [NSDictionary]
            let exchangesD = json["exchanges"] as! [NSDictionary]
            let pairsD = json["pairs"] as! [NSDictionary]
            
            var currencies = [Currency]()
            var cryptocurrencies = [Cryptocurrency]()
            var exchanges = [Exchange]()
            var pairs = [AssetPair]()
            
            for c in currenciesD {
                if ( c.value(forKey: "crypto") as! Bool ){
                    cryptocurrencies.append(Cryptocurrency( c.value(forKey: "name") as! String, c.value(forKey: "symbol") as! String, c.value(forKey: "_id") as! String ))
                } else {
                    currencies.append(Currency(name: c.value(forKey: "name") as! String, symbol: c.value(forKey: "symbol") as! String, id: c.value(forKey: "_id") as! String ))
                }
            }
            
            for e in exchangesD {
                exchanges.append(Exchange(name: e.value(forKey: "name") as! String, id: e.value(forKey: "_id") as! String ))
            }
            
            for p in pairsD {
                pairs.append(AssetPair(assetPairId: p.value(forKey: "_id") as! String, exchangeId: p.value(forKey: "exchangeId") as! String, currencyId1: p.value(forKey: "currencyId1") as! String, currencyId2: p.value(forKey: "currencyId2") as! String ))
            }
            processInitParams(cryptocurrencies, currencies, exchanges, pairs)
            return ""
        })
    }
    
    public func getAllInfo( assetPairId: String, period: String, processParams: @escaping (_ : Double, _ : Double, _ : Double, _ : Double, _ : Double, _ : Double, _ : [(Double,Double)] ) -> Void ) {
        sendRequest(route: "getAllInfo/\(assetPairId)/\(period)", method: .GET) { (json: [String: Any]) -> Any in
            let last = json["last"] as! Double
            let techAnalysis = json["analysis"] as! Double
            let hourVar = json["hourvar"] as! Double
            let dayVar = json["dayvar"] as! Double
            let weekVar = json["weekvar"] as! Double
            let monthVar = json["monthvar"] as! Double
            
            let prices = json["graph"] as! [NSDictionary]
            var data = [(Double,Double)]()
            for p in prices {
                let timestamp = p.value(forKey: "timestamp") as! Double
                let price = p.value(forKey: "price") as! Double
                data.append((timestamp, price))
            }
            
            processParams(last, techAnalysis, hourVar, dayVar, weekVar, monthVar, data)
            return ""
        }
    }
}
