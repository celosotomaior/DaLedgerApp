//
//  UserInterfaceCoreData.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/23/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import Foundation
import CoreData
import UIKit

// Class for updating the CoreDate file and inMemory settings
class UserInterfaceCoreData {
    
    // Use me like: DRSingleton.shared
    public static let shared = UserInterfaceCoreData()
    
    public func setDefaultExchange( defaultExchange:  String ) {
        // Set CoreData
        generalCDConnection(key: "defaultExchange", value: defaultExchange )
        
        // Update inMemory
//        (UIApplication.shared.delegate as! AppDelegate).defaultExchange = defaultExchange
    }
    
    public func setDefaultCurrency ( defaultCurrency : String ){
        // Set CoreData
        generalCDConnection(key: "defaultCurrency", value: defaultCurrency )
        
        // Update inMemory
//        (UIApplication.shared.delegate as! AppDelegate).defaultCurrency = defaultCurrency
    }
    
    // General function for saving info into CoreData
    private func generalCDConnection ( key : String, value : String ){
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        
        let user = UserUUID(context: context)
        do {
            let userUUIDs = try context.fetch(UserUUID.fetchRequest())
//            UserUUID.fe
            for u in userUUIDs {
                let uuid = (u as! UserUUID).value(forKey: "uuid") as? String
//                (u as! UserUUID).setVa

                if ( uuid != nil ){
                    (u as! UserUUID).setValue(value, forKey: key)

//                    if ( key ==  "defaultExchange" ) {
//                        (u as! UserUUID).defaultExchange = value
//                    } else if ( key == "defaultCurrency" ) {
//                        (u as! UserUUID).defaultCurrency = value
//                    }
                    print( " ** " + uuid!  + " : " + key + " , " + value )
                    break;

                }



            }
        
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
        } catch {
            print("Fetching Failed")
        }
    }
    
}
