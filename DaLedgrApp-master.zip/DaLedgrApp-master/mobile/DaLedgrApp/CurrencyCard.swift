//
//  CurrencyCard.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/22/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import Foundation
import UIKit

public protocol CurrencyCardNavigationDelegate {
    func navigate( sender: UIButton, from : Int, activeCell : CryptocurrencyInfoCollectionViewCell )
}

class CurrencyCard : UIView {
    
//    private let reuseIdentifier = "cryptocurrencyinfocell"
//
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return 3
//    }
//
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! CryptocurrencyInfoCollectionViewCell
//
//
//        cell.cryptocurrencyInfo.setElements()
//        return cell
//    }
    
    
    var priceLabel : UILabel!
    var exchangeButton : UIButton!
    var cryptoLabel : UILabel!
    var symbolPairLabel : UILabel!
    var addCryptoButton : UIButton!
    
    var cryptoLogoImage: UIImageView!
    var navigationDelegate: CurrencyCardNavigationDelegate?
    var cellSuperView : CryptocurrencyInfoCollectionViewCell!
    
    var bgImage = #imageLiteral(resourceName: "curcard")
//    var currency = "1"
    override init(frame: CGRect) {
        super.init(frame: frame)
        setElements()
        print("CurrencyCard init frame")
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setElements()
        print("CurrencyCard init coder")
    }
    
    func updatePrice(stats : BasicStats) {
        DispatchQueue.main.async {
            self.priceLabel.text = "US$ \(NSString(format:"%.2f", Double(stats.price)))"
            self.setNeedsDisplay()
        }
    }
    
    func setElements () {
        var appDelegate = UIApplication.shared.delegate as! AppDelegate
        var activeCell = appDelegate.activeCellIndex
//        let staticViewImage = UIImageView(image: bgImage)
        self.bounds = CGRect(x: 0, y: 0, width: 320, height: 114)
        self.layer.cornerRadius = 15
        self.layer.shadowRadius = 5
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOpacity = 0.5
//        self.center = CGPoint( x: (self.superview?.bounds.width)!/2, y: self.center.y )
//        self.center = CGPoint( x: self.center.x, y: 240)
        
        priceLabel = UILabel(frame: CGRect(x: 150, y: 0, width: 220, height: 30))
        priceLabel.textAlignment = .right
        priceLabel.font = UIFont(name: "AvenirNext-Regular", size: 32)
        priceLabel.textColor = UIColor(hex: "4A4A4A")
        priceLabel.text = "US$ 10691.08"
        priceLabel.center = CGPoint(x: bounds.width - 200, y: bounds.height - 30)
        
        exchangeButton = UIButton(frame: CGRect(x: 180, y: 10, width: 120, height: 30))
        exchangeButton.setTitle(appDelegate.defaultExchange, for: .normal)
        exchangeButton.setTitleColor(UIColor(hex: "9B9B9B"), for: .normal)
        exchangeButton.backgroundColor = UIColor.white
        exchangeButton.layer.cornerRadius = 15
        exchangeButton.layer.borderColor = UIColor(hex: "9B9B9B").cgColor
        exchangeButton.layer.borderWidth = 1
        exchangeButton.titleLabel?.textAlignment = .center
        exchangeButton.titleLabel?.font = UIFont(name: "AvenirNext-Regular", size: 20)
        exchangeButton.titleLabel?.text = appDelegate.defaultExchange
        exchangeButton.addTarget(self, action: #selector(changeExchange), for: .touchUpInside)
        
        cryptoLabel = UILabel(frame: CGRect(x:70, y:10,  width: 200, height: 30))
        cryptoLabel.textAlignment = .left
        cryptoLabel.font = UIFont(name: "AvenirNext-Regular", size: 20)
        cryptoLabel.textColor = UIColor(hex: "4A4A4A")
        cryptoLabel.text = appDelegate.cryptocurrenciesOfUser[activeCell].name
        
        symbolPairLabel = UILabel(frame: CGRect(x:70, y:35, width: 250, height: 30))
        symbolPairLabel.textAlignment = .left
        symbolPairLabel.font = UIFont(name: "AvenirNext-Regular", size: 24)
        symbolPairLabel.textColor = UIColor(hex: "4A4A4A")
        symbolPairLabel.text = "\(appDelegate.cryptocurrenciesOfUser[activeCell].symbol)/\(appDelegate.defaultCurrency)"
        
        addCryptoButton = UIButton(frame: CGRect(x: 0, y:0, width: 60, height: 60))
        addCryptoButton.setImage(#imageLiteral(resourceName: "button_add"), for: .normal)
        addCryptoButton.center = CGPoint(x: bounds.width - 30, y: bounds.height - 30)
        addCryptoButton.addTarget(self, action: #selector(addCrypto), for: .touchUpInside)
        
        cryptoLogoImage = UIImageView(frame: CGRect(x: 10, y: 10, width: 55, height: 55))
        cryptoLogoImage.image = #imageLiteral(resourceName: "BTC-alt")
        
        
        self.addSubview(exchangeButton)
        self.addSubview(cryptoLabel)
        self.addSubview(symbolPairLabel)
        self.addSubview(addCryptoButton)
        self.addSubview(cryptoLogoImage)
//        self.addSubview(staticViewImage)
        self.addSubview(priceLabel)
    }
    
    public func setInfo ( index: Int, cell : CryptocurrencyInfoCollectionViewCell ){
        self.cellSuperView = cell
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        cryptoLabel.text = appDelegate.cryptocurrenciesOfUser[index].name
        cryptoLogoImage.image = appDelegate.cryptocurrenciesOfUser[index].img
        symbolPairLabel.text = "\(appDelegate.cryptocurrenciesOfUser[index].symbol)/\(appDelegate.defaultCurrency)"
        
        DispatchQueue.main.async {
//            self.priceLabel.text = "US$ \(NSString(format:"%.2f", Double(stats.price)))"
            self.setNeedsDisplay()
        }
    }
    
    @objc func changeExchange(_ sender: UIButton) {
        print("select other exchange")
//        self.superview?.view
//        self.superview.view
//
//        testViewControllerId
//
//        UIStoryboard(
//       self.superview?.inputViewController. self.superview?.inputViewController?.performSegue(withIdentifier: "testViewControllerId", sender: nil)
//        self.inputViewController.prepare
//        self.navigationDelegate?.
        self.navigationDelegate?.navigate(sender: sender, from: 0, activeCell: cellSuperView)
//        setInfo(index: 0)
        
    }
    
    @objc func addCrypto(_ sender: UIButton ){
        print("add another crypto")
        self.navigationDelegate?.navigate(sender: sender, from: 1, activeCell: cellSuperView)
        
    }
}
