//
//  DateValueFormatter.swift
//  ChartsDemo-iOS
//
//  Modified by Edson Ticona on 2018-08-03
//  Created by Jacob Christie on 2017-07-09.
//  Copyright © 2017 jc. All rights reserved.
//

import Foundation
import Charts

public class DateValueFormatter: NSObject, IAxisValueFormatter {
    private let dateFormatter = DateFormatter()
    
    public enum Option: String {
//        public typealias RawValue = <#type#>
        case HOUR = "hour"
        case DAY = "day"
        case WEEK = "week"
        case MONTH = "month"
        case YEAR = "year"
        case ALL = "all"
    }
    
    init(_ opt: Option) {
        super.init()
        setFormat(opt)
    }

    override init() {
        super.init()
        dateFormatter.dateFormat = "dd MMM HH:mm"
    }

    // check this: http://nsdateformatter.com
    public func setFormat(_ opt: Option ){
        switch opt {
        case Option.HOUR:
            dateFormatter.dateFormat = "HH:mm"
        case Option.DAY:
            dateFormatter.dateFormat = "HH:mm"
        case Option.WEEK:
            dateFormatter.dateFormat = "E"
        case Option.MONTH:
            dateFormatter.dateFormat = "dd/MM"
        case Option.YEAR:
            dateFormatter.dateFormat = "MMM"
        case Option.ALL:
            dateFormatter.dateFormat = "YY"
        }
    }
    
    public func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return dateFormatter.string(from: Date(timeIntervalSince1970: value))
    }
}
