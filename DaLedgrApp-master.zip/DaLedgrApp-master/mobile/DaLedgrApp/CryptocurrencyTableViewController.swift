//
//  CryptocurrencyTableViewController.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/26/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit

class CryptocurrencyTableViewController: UITableViewController {

    var cryptoNames = [ String ]()
    var cryptoSymbols = [ String ]()
    var cryptoIds = [ String ] ()
    var cryptoImages = [#imageLiteral(resourceName: "BTC-alt"), #imageLiteral(resourceName: "ETH-alt"), #imageLiteral(resourceName: "LTC-alt") ,  #imageLiteral(resourceName: "XMR"), #imageLiteral(resourceName: "XRP-alt"), #imageLiteral(resourceName: "BCH-alt"), #imageLiteral(resourceName: "NEO"), #imageLiteral(resourceName: "ADA"), #imageLiteral(resourceName: "XRP-alt"), #imageLiteral(resourceName: "IOTA"), #imageLiteral(resourceName: "DASH-alt")]
    var lastChoice = 0
    
    public var dimissMe = false
    public var homeViewControllerRef : HomeViewController!
    override func viewDidLoad() {
        super.viewDidLoad()

        BackEndConnection.shared.getAllCryptocurrencies { (cryptocurrencies) in
            for e in cryptocurrencies {
                self.cryptoNames.append(e.name)
                self.cryptoSymbols.append(e.symbol)
                self.cryptoIds.append(e.id)
//                if ( e.name ==)
            }
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return cryptoNames.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cryptoCell", for: indexPath) as! CryptocurrencyTableViewCell
        
        cell.cryptoNameLabel.text = cryptoNames[indexPath.row]
        cell.cryptoSymbolLabel.text = cryptoSymbols[indexPath.row]
        
        
        if indexPath.row > cryptoImages.count {
            cell.cryptoLogoImage.image = cryptoImages[cryptoImages.count-1]
        }
        else{
            cell.cryptoLogoImage.image = cryptoImages[indexPath.row]
        }
        // Configure the cell...

        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cryptoCell", for: indexPath) as! CryptocurrencyTableViewCell
        
        
//        print(cell.cryptoNameLabel.text!)
//        print(indexPath.row)
//        print(cell.cryptoSymbolLabel.text!)
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        
        appDelegate.cryptocurrenciesOfUser.append(Cryptocurrency(cryptoNames[indexPath.row], cryptoSymbols[indexPath.row], cryptoIds[indexPath.row]))
        print(appDelegate.cryptocurrenciesOfUser)
        homeViewControllerRef?.cryptocurrenciesCollectionView?.viewDidLoad()
        self.dismiss(animated: true, completion: nil)
        
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
