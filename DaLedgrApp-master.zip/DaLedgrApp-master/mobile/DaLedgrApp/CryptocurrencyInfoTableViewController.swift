//
//  CryptocurrencyInfoTableViewController.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 3/12/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import Foundation

class CryptocurrencyInfoTableViewController {
    
}
