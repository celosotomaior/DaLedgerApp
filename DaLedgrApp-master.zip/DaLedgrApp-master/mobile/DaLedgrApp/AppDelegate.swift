//
//  AppDelegate.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/7/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit
import CoreData

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    var uuid : String = ""
//    var type : Int = 1
    
//    var cryptocurrencies = [ Cryptocurrency("Bitcoin", "BTC", "1", #imageLiteral(resourceName: "BTC-alt") ),
//                             Cryptocurrency("Ethereum", "ETH", "2", #imageLiteral(resourceName: "ETH-alt")),
//                             Cryptocurrency("Litecoin", "LTC", "3", #imageLiteral(resourceName: "LTC-alt")) ]
    
    // This is the info for the cryptocurrencies that are to be showed to the user
    var cryptocurrenciesOfUser = [ Cryptocurrency ]() //{
//        didSet {
//
//        }
//    }
    
    // These 4 variables are for saving all the basic data
    var cryptocurrenciesFromBE = [ Cryptocurrency ]()
    var currencies = [ Currency ]()
    var pairs = [ AssetPair ]()
    var exchanges = [ Exchange ]()
    
    //
    var defaultExchange = "Bitfinex"
    var defaultExchangeID = ""
    var defaultCurrency = "USD"
    var defaultCurrencyID = "1"
    var activeCellIndex = 0
    
    
    // This is a mapping between the name of the exchange and its ID in the DB
    private var exchangeMap = [String:String]()
    private var currencyMap = [String:String]()
    // This is a mapping between the ID of the exchange and a pair currencies ID
    private var pairMap : Dictionary<String, [(String, String)]>!
    
    var alerts = [Alert]()
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        // MARK: Check whether a UUID exists so it gets the preferences from the server, otherwise create a new one and saves it on the DB
        // https://medium.com/xcblog/core-data-with-swift-4-for-beginners-1fc067cca707
        // https://medium.com/kkempin/coredata-basics-xcode-9-swift-4-56a0fc1d40cb
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
//        self.userInfo = UserUUID(context: context)
//        self.cryptos = CryptocurrencyCD(context: context)
        
        let usersFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "UserUUID")
        let users = try! context.fetch(usersFetch)
        print("count: \(users.count)")
        
        // First I have to get the exchanges!
//        let group = DispatchGroup()
//        group.enter()
//        DispatchQueue.main.async {
//            BackEndConnection.shared.getAllExchanges(processExchanges: self.getDefaultExchangeID )
//            group.leave()
//        }
//        group.wait()
        
        
        
        
        if ( users.count == 0 ) {
            //Create default data
            let userEntity = NSEntityDescription.entity(forEntityName: "UserUUID", in: context)!
            let user = NSManagedObject(entity: userEntity, insertInto: context)
            user.setValue("USD", forKey: "defaultCurrency")
            user.setValue("Bitfinex", forKey: "defaultExchange")
            user.setValue(UUID().uuidString, forKey: "uuid")
            
            let cryptoEntity = NSEntityDescription.entity(forEntityName: "CryptocurrencyCD", in: context)!
            let crypto = NSManagedObject(entity: cryptoEntity, insertInto: context)
            crypto.setValue("Bitcoin", forKey: "name")
            crypto.setValue("BTC", forKey: "symbol")
            crypto.setValue("Bitfinex", forKey: "exchangename")
//            let dbid = self.searchIdInCrypto(cryptosFromBE: cryptocurrenciesFromBE, symbol: "BTC")
//            crypto.setValue(dbid, forKey: "dbid")
//            crypto.setValue(self.exchangeMap["Bitfinex"]!, forKey: "exchangeid")
            cryptocurrenciesOfUser.append(Cryptocurrency("Bitcoin","BTC","", getImage("BTC"), "Bitfinex", ""))
            do {
                try context.save()
                print("Saved user \(user)")
            } catch {
                print("Failed saving")
            }
            
//            BackEndConnection.shared.getAllCryptocurrencies(processCryptocurrencies: self.getDefaultCryptoID )
        } else {
            //Load data from CoreData
            let u = users.first as! UserUUID
            self.defaultExchange = u.defaultExchange!
            self.defaultCurrency = u.defaultCurrency!
            self.uuid = u.uuid!
            
            let cryptoFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "CryptocurrencyCD")
            let cryptos = try! context.fetch(cryptoFetch)

            

            for c in cryptos as! [CryptocurrencyCD] {
                cryptocurrenciesOfUser.append(Cryptocurrency(c.name!, c.symbol!, "", getImage(c.symbol!) , c.exchangename!, ""))
//                exchangeMap[c.exchangename!] = c.exchangeid!
            }
            print(cryptocurrenciesOfUser)
            print("===============")
//            BackEndConnection.shared.getAllCryptocurrencies(processCryptocurrencies: self.updateCryptoIDs )
        }
        
        // To this point, all the variables have the basic data loaded from CoreData: defaultCurrency, defaultExchange, and the list of cryptocurrenciesOfUser WITHOUT the IDs that are gonna be pulled from the server in the following call.
        BackEndConnection.shared.getInitParams(processInitParams: self.getInitParams)
        
//        BackEndConnection.shared.getAllAlerts(processAlerts: self.loadUserAlerts )
        
//        do {
//            let userUUIDs = try context.fetch(UserUUID.fetchRequest())
//            print("userUUIDs.count: \(userUUIDs.count)" )
//            // if this is the first execution
//            if ( userUUIDs.count == 1 ) {
//                user.uuid = UUID().uuidString
//                user.defaultCurrency = self.defaultCurrency
//                user.defaultExchange = self.defaultExchange
//
//                saveContext()
//                (UIApplication.shared.delegate as! AppDelegate).uuid = user.uuid!
//                (UIApplication.shared.delegate as! AppDelegate).type = 1
////                BackEndConnection.shared.insertUser()
//            } else {    // Retrieve data from CoreData and load in AppDelegateSingleton
//                for u in userUUIDs {
//                    let uuid = (u as! UserUUID).value(forKey: "uuid") as? String
//                    let defaultCurrency = (u as! UserUUID).value(forKey: "defaultCurrency") as? String
//                    let defaultExchange = (u as! UserUUID).value(forKey: "defaultExchange") as? String
//                    if uuid != nil {
//                        (UIApplication.shared.delegate as! AppDelegate).uuid = uuid!
//                        (UIApplication.shared.delegate as! AppDelegate).defaultCurrency = "USD"
//                        (UIApplication.shared.delegate as! AppDelegate).defaultExchange = "Bitfinex"
//
//                        break
//                    }
////                    (UIApplication.shared.delegate as! AppDelegate).uuid = uuid ?? ""
//                }
////                let userUUID = userUUIDs[0] as! UserUUID
////                (UIApplication.shared.delegate as! AppDelegate).uuid = (userUUIDs[0] as! UserUUID).uuid!
//            }
////            getConfIds()
//
//        } catch {
//            print("Fetching Failed")
//        }
////            (UIApplication.shared.delegate as! AppDelegate).saveContext()
        return true
    }

    func getDefaultCryptoID(_ cryptosFromBE: [Cryptocurrency] ) {
        let dg = DispatchGroup();
        dg.enter()
        DispatchQueue.main.async {
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            let cryptoEntity = NSEntityDescription.entity(forEntityName: "CryptocurrencyCD", in: context)!
            let crypto = NSManagedObject(entity: cryptoEntity, insertInto: context)
            crypto.setValue("Bitcoin", forKey: "name")
            crypto.setValue("BTC", forKey: "symbol")
            crypto.setValue("Bitfinex", forKey: "exchangename")
            
            let dbid = self.searchIdInCrypto(cryptosFromBE: cryptosFromBE, symbol: "BTC")
//            let dbid = self.exchangeMap[
            crypto.setValue(dbid, forKey: "dbid")
            crypto.setValue(self.exchangeMap["Bitfinex"]!, forKey: "exchangeid")
            self.cryptocurrenciesOfUser.append(Cryptocurrency("Bitcoin", "BTC", dbid, self.getImage("BTC"), "Bitfinex", self.exchangeMap["Bitfinex"]!))
            print("getDefaultCryptoID \(self.cryptocurrenciesOfUser[0].symbol) \(self.cryptocurrenciesOfUser[0].id) dbid:\(dbid)")
            
            do {
                try context.save()
            } catch {
                print("Failed saving")
            }
            dg.leave()
        }
        dg.wait()
    }
    
    // This functions sets self.exchangeMap and self.default
    private func setExchangeMapAndDefaultExchangeID( ) {
      for e in self.exchanges {
            if e.name.elementsEqual(self.defaultExchange) {
                self.defaultExchangeID = e.id
                print("setExchangeMapAndDefaultExchangeID \(self.defaultExchangeID)" )
//                    break
            }
            self.exchangeMap[e.name] = e.id
        }
    }
    
//    func loadCDIntoArray(){
//        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
//        let currenciesFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "CryptocurrencyCD")
//        let cryptos = try! context.fetch(currenciesFetch) as! [CryptocurrencyCD]
//        cryptocurrencies.removeAll()
//        for c in cryptos {
//            cryptocurrencies.append(Cryptocurrency(c.name!, c.symbol!, c.dbid!, getImage(c.symbol!)))
//        }
//    }
    
    func getInitParams(_ cryptocurrenciesFromBE : [Cryptocurrency], _ currenciesFromBE: [Currency], _ exchangesFromBE: [Exchange], _ pairsFromBE: [AssetPair] ){
        
        self.cryptocurrenciesFromBE.removeAll()
        self.currencies.removeAll()
        self.exchanges.removeAll()
        self.pairs.removeAll()
        
        self.cryptocurrenciesFromBE.append(contentsOf: cryptocurrenciesFromBE)
        self.currencies.append(contentsOf: currenciesFromBE)
        self.exchanges.append(contentsOf: exchangesFromBE)
        self.pairs.append(contentsOf: pairsFromBE)
        
        for e in exchanges {
            self.exchangeMap[e.name] = e.id
        }
        
        for c in cryptocurrenciesFromBE {
            self.currencyMap[c.name] = c.id
        }
        for c in currenciesFromBE {
            self.currencyMap[c.symbol] = c.id
        }
        
        pairMap = Dictionary<String, [(c1: String, c2: String)]>()
        
        for p in pairsFromBE {
            let exchangeId = p.exchangeId
            if var _ = self.pairMap[exchangeId] {
                let currencyPair = ( c1: p.currencyId1, c2: p.currencyId2)
                self.pairMap[exchangeId]!.append(currencyPair)
//                print("Appended \(p.currencyId1)")
//                print("\(exchangeId) has \(self.pairMap[exchangeId]!.count) currencies")
            } else {
                self.pairMap[exchangeId] = []
//                print("Initialized \(exchangeId) array")
                let currencyPair = (c1: p.currencyId1, c2: p.currencyId2)
                self.pairMap[exchangeId]?.append(currencyPair)
            }
        }
        
        print("All exchange currencies: \(pairMap)")
        
        // Set all the IDs for the user
        self.defaultExchangeID = exchangeMap[self.defaultExchange]!
        self.defaultCurrencyID = currencyMap[self.defaultCurrency]!
        
        for c in cryptocurrenciesOfUser {
            c.exchangeId = exchangeMap[c.exchangeName]!
            c.id = currencyMap[c.name]!
        }
//        let dg = DispatchGroup();
//        dg.enter()
//        DispatchQueue.main.async {
//            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
//            let currenciesFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "CryptocurrencyCD")
//            let cryptos = try! context.fetch(currenciesFetch) as! [CryptocurrencyCD]
//
//            for c in cryptos {
//                let dbid = self.searchIdInCrypto(cryptosFromBE: self.cryptocurrenciesFromBE, symbol: c.symbol!)
//                if ( dbid.elementsEqual("") ) {
//                    NSLog("Not found symbol \(c.symbol!)")
//                }
//                print("$$$$$$$")
//                print("\(c.name!)")
//                print("\(c.symbol!)")
//                print("\(dbid)")
//                print("\(c.exchangename!)")
//                print("exchangeMap.count: \(self.exchangeMap.count)")
//                print("element: \(self.exchangeMap[c.exchangename!]!)")
//                print("$$$$$$$")
////                The server doesn't have the images, so we set them
////                In addition, the server doesn't have the user preferences, so we set the prefered exchange for the user crypto
//                self.cryptocurrenciesOfUser.append(Cryptocurrency(c.name!, c.symbol!, dbid, self.getImage(c.symbol!), c.exchangename!, self.exchangeMap[c.exchangename!]!))
//                print("updateCryptoIDs \(self.cryptocurrenciesOfUser[0].symbol) \(self.cryptocurrenciesOfUser[0].id) dbid:\(dbid)")
//                //                print("^^^")
//                //                print(self.cryptocurrencies[self.cryptocurrencies.count-1])
//            }
//
//            do {
//                try context.save()
//            } catch {
//                print("Failed saving")
//            }
//
//            dg.leave()
//        }
//        dg.wait()
    }
    
    func updateCryptoIDs(_ cryptosFromBE: [Cryptocurrency] ){
        let dg = DispatchGroup();
        dg.enter()
        DispatchQueue.main.async {
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            let currenciesFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "CryptocurrencyCD")
            let cryptos = try! context.fetch(currenciesFetch) as! [CryptocurrencyCD]
        
//            print("^^^")
//            print(cryptos.count)
//            print("^^^")
//            
            self.cryptocurrenciesOfUser.removeAll()
            for c in cryptos {
                let dbid = self.searchIdInCrypto(cryptosFromBE: cryptosFromBE, symbol: c.symbol!)
                if ( dbid.elementsEqual("") ) {
                    NSLog("Not found symbol \(c.symbol!)")
                }
                // FIXME: sometimes the self.exchangeMap dictionary isn't filled the way it should be. Don't know why
                print("$$$$$$$")
                print("\(c.name!)")
                print("\(c.symbol!)")
                print("\(dbid)")
                print("\(c.exchangename!)")
                print("mapSize: \(self.exchangeMap.count)")
                print("element: \(self.exchangeMap[c.exchangename!]!)")
                print("$$$$$$$")
                self.cryptocurrenciesOfUser.append(Cryptocurrency(c.name!, c.symbol!, dbid, self.getImage(c.symbol!), c.exchangename!, self.exchangeMap[c.exchangename!]!))
                print("updateCryptoIDs \(self.cryptocurrenciesOfUser[0].symbol) \(self.cryptocurrenciesOfUser[0].id) dbid:\(dbid)")
//                print("^^^")
//                print(self.cryptocurrencies[self.cryptocurrencies.count-1])
            }
            
            do {
                try context.save()
            } catch {
                print("Failed saving")
            }
            dg.leave();
        }
        dg.wait();
    }
    
    func loadUserAlerts (_ alertsFromBE: [Alert] ) {
        print(alertsFromBE)
        let dg = DispatchGroup();
        dg.enter()
        DispatchQueue.main.async {
            self.alerts.append(contentsOf: alertsFromBE)
            dg.leave()
        }
        dg.wait()
    }
    
    func searchIdInCrypto( cryptosFromBE: [Cryptocurrency] , symbol: String) -> String{
        for c in cryptosFromBE {
//            print(c)
            if c.symbol == symbol {
                return c.id
            }
        }
        return  ""
    }
    
    //FIXME: hardcoded!
    func getImage(_ symbol: String) -> UIImage{
        if ( symbol == "BTC" ){
            return #imageLiteral(resourceName: "BTC-alt")
        } else if ( symbol == "ETH" ){
            return #imageLiteral(resourceName: "ETH-alt")
        } else if ( symbol == "LTC" ){
            return #imageLiteral(resourceName: "LTC-alt")
        } else if ( symbol == "XMR" ){
            return #imageLiteral(resourceName: "XMR")
        } else if ( symbol == "XRP" ){
            return #imageLiteral(resourceName: "XRP-alt")
        } else if ( symbol == "BCH" ){
            return #imageLiteral(resourceName: "BCH-alt")
        } else if ( symbol == "NEO" ){
            return #imageLiteral(resourceName: "NEO")
        } else if ( symbol == "ADA" ){
            return #imageLiteral(resourceName: "ADA")
        } else if ( symbol == "XLM" ){
            return #imageLiteral(resourceName: "def-coin")
        } else if ( symbol == "MIOTA" ){
            return #imageLiteral(resourceName: "IOTA")
        } else if ( symbol == "DASH" ){
            return #imageLiteral(resourceName: "DASH-alt")
        } else {
            return #imageLiteral(resourceName: "def-coin")
        }
    }
    // FIXME: This should be done with Dictionaries and not with Arrays
//    func getConfIds() {
//        BackEndConnection.shared.getAllCryptocurrencies(processCryptocurrencies: { (ccs) in
//            for c in ccs {
//                if c.name == self.defaultCrypto {
//                    self.defaultCryptoID = c.id
//                    self.defaultCryptoSymbol = c.symbol
//                    break
//                }
//            }
//            print(self.defaultCryptoID + ": " + self.defaultCrypto)
//        })
//
//        BackEndConnection.shared.getAllExchanges(processExchanges: { (exchanges) in
//            for e in exchanges {
//                if e.name == self.defaultExchange {
//                    self.defaultExchangeID = e.id
//                    break
//                }
//            }
//            print(self.defaultExchangeID + ": " + self.defaultExchange)
//        })
//
//        BackEndConnection.shared.getAllCurrencies { (currencies) in
//            for c in currencies {
//                if c.name == self.defaultCurrency {
//                    self.defaultCurrencyID = c.id
//                    break
//                }
//            }
//            print(self.defaultCurrencyID + ": " + self.defaultCurrency)
//        }
//    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }

    // MARK: - Core Data stack
    
    lazy var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
         */
        let container = NSPersistentContainer(name: "DaLedgrApp")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    // MARK: - Core Data Saving support
    
    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
}

