//
//  User.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/7/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import Foundation

// User Settings
class User {
    private var defaultExchange : Exchange
    private var defaultCurrency : Currency
    private var cryptocoins : [Cryptocurrency]
    private var type : Int // 1: beginner, 2: advanced
    private var uuid : String
    
    // FIXME: The default currency should be the one where the user lives in
    init( defaultExchange : Exchange = Exchange(), cryptocoins : [Cryptocurrency] = [], defaultCurrency : Currency = Currency(), type : Int = 1, uuid : String = "" ){
        self.defaultExchange = defaultExchange
        self.cryptocoins = cryptocoins
        self.defaultCurrency = defaultCurrency
        self.type = type
        self.uuid = uuid
    }
}
