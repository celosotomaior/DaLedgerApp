//
//  Cryptocurrency.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/7/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import Foundation
import UIKit

class Cryptocurrency : Hashable, CustomStringConvertible{
    var hashValue: Int {
        return name.hashValue ^ symbol.hashValue &* 16777619
    }
    
    var description: String{ return "Exchange: { name:\(name), symbol:\(symbol), id:\(id) }" }
    
    static func ==(lhs: Cryptocurrency, rhs: Cryptocurrency) -> Bool {
        return lhs.symbol == rhs.symbol
    }
    
    public var name : String
    public var symbol : String
    public var id : String
    public var img : UIImage
    public var exchangeId : String
    public var exchangeName : String
    
    init(_ name: String = "Bitcoin",_ symbol: String = "BTC",_ id : String = "1",_ img : UIImage  = #imageLiteral(resourceName: "BTC-alt"),_ exchangeName : String = "", _ exchangeId : String = ""){
        self.name = name
        self.symbol = symbol
        self.id = id
        self.img = img
        self.exchangeName = exchangeName
        self.exchangeId = exchangeId
    }
    
    // { name : "bitcoin", symbol: "BTC" }
    public func parseCryptocoin( json : [String : Any] ) {
        for (k,v) in json {
            if k == "name" {
                self.name = v as! String
            } else if k == "symbol" {
                self.symbol = v as! String
            }
        }
    }
}
