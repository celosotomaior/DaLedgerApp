//
//  Currency.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/7/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import Foundation

class Currency {
    var name : String
    var symbol : String
    var id : String
    
    init ( name : String = "dollar", symbol : String = "USD", id : String = "1") {
        self.name = name
        self.symbol = symbol
        self.id = id
    }
    
}
