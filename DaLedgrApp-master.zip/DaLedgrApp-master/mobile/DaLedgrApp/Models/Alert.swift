//
//  Alert.swift
//  DaLedgrApp
//
//  Created by Carlos Pires on 20/03/2018.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import Foundation

class AlertsFromBE: Decodable {
    let status: Int
    let alerts: [Alert]
    init(status: Int, alerts: [Alert]) {
        self.status = status
        self.alerts = alerts
    }
}

class Alert: Decodable {
    private var type : Int
    private var currency1 : String
    private var currency2 : String
    private var value : Double
    
    public var description: String  {
        return "Alert: {type:\(type), currency2:\(currency2), currency1:\(currency1), value:\(value)"
    }
    init(type: Int, currency1: String, currency2: String, value: Double) {
        self.type = type
        self.currency1 = currency1
        self.currency2 = currency2
        self.value = value
    }
    func getPair() -> String {
        return self.currency1 + "/" + self.currency2
    }
    func getType() -> Int {
        return self.type
    }
    func getValue() -> Double {
        return self.value
    }
}

