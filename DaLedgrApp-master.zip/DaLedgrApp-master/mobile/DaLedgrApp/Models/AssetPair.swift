//
//  AssetPair.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 3/16/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import Foundation

class AssetPair {
    var assetPairId : String;
    var exchangeId : String;
    var currencyId1 : String;
    var currencyId2 : String;
    
    init( assetPairId: String = "", exchangeId : String = "", currencyId1 : String = "", currencyId2 : String = "" ) {
        self.assetPairId = assetPairId
        self.exchangeId = exchangeId
        self.currencyId1 = currencyId1
        self.currencyId2 = currencyId2
    }
}
