//
//  Tip.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/7/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import Foundation

class Tip {
    private var title : String
    private var text : String
    
    init(title:String = "", text:String = ""){
        self.title = title
        self.text = text
    }
}
