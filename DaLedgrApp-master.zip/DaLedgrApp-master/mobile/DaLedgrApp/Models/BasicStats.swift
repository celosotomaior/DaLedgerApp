//
//  BasicStats.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/22/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import Foundation

class BasicStats: CustomStringConvertible {
    
    var price = NSNumber(value: 0)
    var suggestion = NSNumber(value: 2)
    var hour = NSNumber(value: 0)
    var day = NSNumber(value: 0)
    var week = NSNumber(value: 0)
    var month = NSNumber(value: 0)
    
    public var description: String  { return "BasicStats: {price:\(price), suggestion:\(suggestion), hour:\(hour), day:\(day), week:\(week), month:\(month) }" }
}
