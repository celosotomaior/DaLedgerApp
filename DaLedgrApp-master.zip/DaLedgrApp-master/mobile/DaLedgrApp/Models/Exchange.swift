//
//  Exchange.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/7/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import Foundation

//class Exchange : CustomStringConvertible {
class Exchange : CustomStringConvertible {
    var description: String{ return "Exchange: { name:\(name), id:\(id) }" }
    
    public var name : String
    public var id : String
    private var _assets : [Cryptocurrency:Double]
    public var assets : [Cryptocurrency:Double] {
        get{
            return _assets
        }
        set {
            _assets = newValue
        }
    }
    
    var _timestamp : Int
    var timestamp : Int {
        get {
            return self._timestamp
        }
        
        set {
            self._timestamp = newValue
        }
    }
    
    private var currency : Currency
    
    init(name: String = "", id: String = "", assets: [Cryptocurrency:Double] = [:], timestamp : Int = 0, currency : Currency = Currency()){
        self.name = name
        self.id = id
        self._assets = assets
        self.currency = currency
        self._timestamp = timestamp
    }
    
    public func parseExchange(json : [String : Any]) {
        for (k,v) in json {
            if ( k == "name" ) {
                self.name = v as! String
            } else if ( k == "timestamp" ){
                self.timestamp = v as! Int
            } else if ( k == "currency" ){
                self.currency = v as! Currency
            } else if ( k == "asset" ) {
                let assetString = v as! String
                var curr = assetString.components(separatedBy: ",")
                let crypto = Cryptocurrency("", curr[0])
                let price = Double(curr[1])
                self.assets[crypto] = price
            }
        }
        
        
//        [Double:Double] //syntax sugar
//        Dictionary<Double, Double>
    }
}
