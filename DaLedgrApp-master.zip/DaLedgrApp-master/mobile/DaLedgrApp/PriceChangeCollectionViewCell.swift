//
//  PriceChangeCollectionViewCell.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/21/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit

class PriceChangeCollectionViewCell: UICollectionViewCell {
    
    let upPrice = #imageLiteral(resourceName: "arrow up")
    let downPrice = #imageLiteral(resourceName: "arrow down")
    let pricesVar = [ +1, -1, -5, +2.3]
    
    var hourChangeLabel : UILabel!
    var todayChangeLabel : UILabel!
    var weekChangeLabel : UILabel!
    var monthChangeLabel : UILabel!
    
    var hourVarImage : UIImageView!
    var todayVarImage : UIImageView!
    var weekVarImage : UIImageView!
    var monthVarImage : UIImageView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        print("normal init")
        fillPrices()
//        Timing.shared.setInterval(5) {
//            var stats = BackEndConnection.shared.getStats(eid: self.exchangeId, ccid: self.cryptocurrencyId, cid: self.currency, processStats: self.updatePrices)
//
//        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        print("coder init")
        fillPrices()
        
//        fatalError("init(coder:) has not been implemented")
    }
    
//    func updatePrices ( stats : BasicStats) {
//        DispatchQueue.main.async {
//            self.hourChangeLabel.text = "US$ \(NSString(format:"%.2f", Double(stats.hour)))"
//            self.todayChangeLabel.text = "US$ \(NSString(format:"%.2f", Double(stats.day)))"
//            self.weekChangeLabel.text = "US$ \(NSString(format:"%.2f", Double(stats.week)))"
//            self.monthChangeLabel.text = "US$ \(NSString(format:"%.2f", Double(stats.month)))"
//        
//            self.hourVarImage.image = Float(stats.hour) < 0 ? self.downPrice : self.upPrice
//            self.todayVarImage.image = Float(stats.hour) < 0 ? self.downPrice : self.upPrice
//            self.weekVarImage.image = Float(stats.hour) < 0 ? self.downPrice : self.upPrice
//            self.monthVarImage.image = Float(stats.hour) < 0 ? self.downPrice : self.upPrice
//            self.setNeedsDisplay()
//        }
//    }
    
    func fillPrices(){
        // Set price changes
        hourChangeLabel = UILabel(frame: CGRect(x: 150, y: 0, width: 140, height: 21))
        hourChangeLabel.textAlignment = .right
        hourChangeLabel.font = UIFont(name: "AvenirNext-Regular", size: 20)
        hourChangeLabel.textColor = UIColor(hex: "9B9B9B")
        hourChangeLabel.text = "US$ 23.12"
        
        hourVarImage = pricesVar[0] < 0 ? UIImageView(image: downPrice) : UIImageView(image: upPrice)
        hourVarImage.center = hourChangeLabel.center.applying(CGAffineTransform(translationX: 90, y: 0))
    
        todayChangeLabel = UILabel(frame: CGRect(x: 150, y: 25, width: 140, height: 21))
        todayChangeLabel.textAlignment = .right
        todayChangeLabel.font = UIFont(name: "AvenirNext-Regular", size: 20)
        todayChangeLabel.textColor = UIColor(hex: "9B9B9B")
        todayChangeLabel.text = "US$ 423.12"
        
        todayVarImage = pricesVar[1] < 0 ? UIImageView(image: downPrice) : UIImageView(image: upPrice)
        todayVarImage.center = todayChangeLabel.center.applying(CGAffineTransform(translationX: 90, y: 0))
        
        weekChangeLabel = UILabel(frame: CGRect(x: 150, y: 50, width: 140, height: 21))
        weekChangeLabel.textAlignment = .right
        weekChangeLabel.font = UIFont(name: "AvenirNext-Regular", size: 20)
        weekChangeLabel.textColor = UIColor(hex: "9B9B9B")
        weekChangeLabel.text = "US$ 1520.84"
        
        weekVarImage = pricesVar[2] < 0 ? UIImageView(image: downPrice) : UIImageView(image: upPrice)
        weekVarImage.center = weekChangeLabel.center.applying(CGAffineTransform(translationX: 90, y: 0))
        
        monthChangeLabel = UILabel(frame: CGRect(x: 150, y: 75, width: 140, height: 21))
        monthChangeLabel.textAlignment = .right
        monthChangeLabel.font = UIFont(name: "AvenirNext-Regular", size: 20)
        monthChangeLabel.textColor = UIColor(hex: "9B9B9B")
        monthChangeLabel.text = "US$ 2422.75"
        
        monthVarImage = pricesVar[3] < 0 ? UIImageView(image: downPrice) : UIImageView(image: upPrice)
        monthVarImage.center = monthChangeLabel.center.applying(CGAffineTransform(translationX: 90, y: 0))
        
        self.addSubview(hourChangeLabel)
        self.addSubview(todayChangeLabel)
        self.addSubview(weekChangeLabel)
        self.addSubview(monthChangeLabel)
        self.addSubview(hourVarImage)
        self.addSubview(todayVarImage)
        self.addSubview(weekVarImage)
        self.addSubview(monthVarImage)
        
    }
}
