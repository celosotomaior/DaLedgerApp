//
//  AlertsViewController.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/7/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit

class AlertsViewController: UIViewController{
    
    var appDelegate = UIApplication.shared.delegate as! AppDelegate


    @IBOutlet weak var titleView: UIView!
    
    @IBOutlet weak var contentView: UIView!
    
    @IBOutlet weak var addAlertButton: UIButton!
    
    @IBOutlet weak var alertTableView: UITableView!
    func setGradientBackground() {
        let colorBottom =  UIColor(red: 48.0/255.0, green: 210.0/255.0, blue: 190.0/255.0, alpha: 1).cgColor
        let colorTop = UIColor(red: 52.0/255.0, green: 147.0/255.0, blue: 196.0/255.0, alpha: 1).cgColor
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [ colorTop, colorBottom]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 1.0)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.0)
        gradientLayer.locations = [ 0.4, 0.65]
        gradientLayer.frame = self.view.bounds
        
        self.titleView.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if ( appDelegate.alerts.count == 0 ) {
            alertTableView.isHidden = true
            contentView.isHidden = false
        } else {
            alertTableView.reloadData()
            alertTableView.isHidden = false
            contentView.isHidden = true
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let nib = UINib(nibName: "AlertCell", bundle: nil)
        alertTableView.register(nib, forCellReuseIdentifier: "alertCell")
        alertTableView.isHidden = true
        
        self.setGradientBackground()
        
        // Set background image of top UIView
//        let bgGraph = UIImageView(frame: titleView.frame)
//        bgGraph.image = #imageLiteral(resourceName: "mainbg")
//        bgGraph.contentMode = .scaleToFill //scaleAspectFit scaleAspectFill
//        titleView.addSubview(bgGraph)
        
        // Do any additional setup after loading the view.
//        let label = UILabel(frame: titleView.frame)
//        label.center = titleView.center
//        label.textAlignment = .center
//        label.textColor = UIColor.white
//        label.text = "Alerts"
//        titleView.addSubview(label)
        
        
        addAlertButton.setImage(#imageLiteral(resourceName: "button_add"), for: .normal)
        titleView.addSubview(addAlertButton)
        //print("AlertsViewController")
//        BackEndConnection.shared.getAllAlerts( processAlerts: { (alerts) in
//            for a in alerts {
//                self.appDelegate.alerts.append(a)
//                //                if ( e.name ==)
//            }
//            DispatchQueue.main.async {
//                self.alertTableView.reloadData()
//            }
//        })
        //        let jsonUrlString = "https://api.cryptoshiapp.com/alerts/getAllAlerts/52FCDB93-CF9A-4AF9-B353-EEC910390701"
        let jsonUrlString = "http://localhost:3000/alerts/getAllAlerts/52FCDB93-CF9A-4AF9-B353-EEC910390701"
        guard let url = URL(string: jsonUrlString) else {
            return
        }
        
        URLSession.shared.dataTask(with: url) { (data, res, err) in
            guard let data = data else  { return }
            do {
                let decoder = JSONDecoder()
                let alertData = try decoder.decode(AlertsFromBE.self, from: data)
                print (alertData.alerts[0].getPair())
                DispatchQueue.main.sync {
                    self.appDelegate.alerts = alertData.alerts
                    self.alertTableView.reloadData()
                }
            } catch let err {
                print("Error", err)
            }
            
            }.resume()
        // Do I have alerts?
        
        if ( appDelegate.alerts.count == 0 ) {
            let noAlertImage = UIImageView(frame: CGRect(x: 0, y: 0, width: 140, height: 140))
            noAlertImage.image = #imageLiteral(resourceName: "emptyalert")
            noAlertImage.contentMode = UIViewContentMode.scaleAspectFill
            noAlertImage.center = noAlertImage.center.applying(CGAffineTransform(translationX: contentView.frame.width/2 - 70, y: contentView.frame.height/2 - 70))
            
            let noAlertLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 90))
            noAlertLabel.text = "Oh oh, no alerts here. Let’s add some?"
            noAlertLabel.center = noAlertImage.center.applying(CGAffineTransform(translationX: 0, y: 110))
            
            noAlertLabel.numberOfLines = 0
            noAlertLabel.lineBreakMode = .byWordWrapping
            noAlertLabel.textAlignment = .center
            noAlertLabel.textColor = UIColor(red:0.55, green:0.55, blue:0.55, alpha:1.0)
            noAlertLabel.font = UIFont(name: "AvenirNext-Regular", size: 20)!
            
//            let addAlertButton = UIButton(frame: CGRect(x: 0, y: 0, width: 60, height: 60))
//            addAlertButton.center = noAlertLabel.center.applying(CGAffineTransform(translationX: 0, y: 90))
//            addAlertButton.setTitle("Add", for: .normal)
//            addAlertButton.backgroundColor = UIColor.green
//            addAlertButton.addTarget(self, action: #selector(addAlert), for: .touchUpInside)


            
            
            contentView.addSubview(noAlertImage)
            contentView.addSubview(noAlertLabel)
//            contentView.addSubview(addAlertButton)
        } else {
            alertTableView.isHidden = false
//            let tableContent = UITableView(frame: contentView.frame)
//            alertsTableView.isHidden = false
            
//           contentView.addSubview(tableContent)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension AlertsViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return appDelegate.alerts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "alertCell") as! AlertCell
        let type = appDelegate.alerts[indexPath.row].getType()
        var typeLabel = ""
        
//        let typeSymbol = UIImageView(frame: CGRect(x: 10, y: 10, width: 30, height: 30))
        if type == 0 {
            typeLabel = "$"
        } else {
            typeLabel = "%"
        }
        let pair = appDelegate.alerts[indexPath.row].getPair()
        
        cell.customInit(textLabel: pair, textType: typeLabel)
        return cell
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            appDelegate.alerts.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            if (appDelegate.alerts.count == 0) {
                alertTableView.isHidden = true
                contentView.isHidden = false
            }
        }
    }
}
