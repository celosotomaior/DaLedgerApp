//
//  AlertCell.swift
//  DaLedgrApp
//
//  Created by Carlos Pires on 16/03/2018.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit

class AlertCell: UITableViewCell {

    @IBOutlet weak var alertType: UILabel!
    @IBOutlet weak var titleLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func customInit(textLabel: String, textType: String) {
        self.alertType.text = textType
        self.titleLabel.text = textLabel
    }
}
