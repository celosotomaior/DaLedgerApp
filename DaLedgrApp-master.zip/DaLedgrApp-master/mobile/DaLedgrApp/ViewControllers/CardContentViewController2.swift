//
//  CardContentViewController2.swift
//  DaLedgrApp
//
//  Created by TonySellitto on 23/02/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit

class CardContentViewController2: UICollectionView {

    var tempString = String()
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        contentLabel.text = tempString
        
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var contentLabel: UILabel!
    
    @IBOutlet weak var titleLabel: UILabel!
}
