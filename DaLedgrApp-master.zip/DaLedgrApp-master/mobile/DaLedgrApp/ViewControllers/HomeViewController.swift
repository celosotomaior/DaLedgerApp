//
//  HomeViewController.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/7/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit
import Charts

class HomeViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, CurrencyCardNavigationDelegate {
    
    // Method to the currency card navigation protocol
    func navigate( sender: UIButton, from : Int , activeCell : CryptocurrencyInfoCollectionViewCell) {
//        self.activeCell = activeCell
        if ( from == 0 ){
            // This one comes from the exchange button
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewController(withIdentifier: "exchangesTableView")
            let exchanges = controller as! ExchangesTableViewController
            exchanges.modalPresentationStyle = .overCurrentContext
            exchanges.dimissMe = true
            
//            sender.
            DispatchQueue.main.async {
                sender.titleLabel?.text = exchanges.selectedExchange
                sender.setNeedsDisplay()
            }
            
            self.present(exchanges, animated: true, completion: nil)
            
        } else if ( from == 1 ){
            // This one comes from the currenyc button
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let cryptoViewController = storyboard.instantiateViewController(withIdentifier: "cryptoViewController") as! CryptocurrencyTableViewController
            cryptoViewController.modalPresentationStyle = .overCurrentContext
            cryptoViewController.homeViewControllerRef = self
            self.present(cryptoViewController, animated: true, completion: nil)
        }
    }
    
    var appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    @IBOutlet weak var graphView: UIView!
//    @IBOutlet weak var currencyCard: CurrencyCard!
    @IBOutlet weak var contentCollecionView: UICollectionView!
    @IBOutlet weak var cryptocurrenciesInfo: UICollectionView!
    var cryptocurrenciesCollectionView : CryptocurrencyInfoCollectionViewController!
//    var activeCell : CryptocurrencyInfoCollectionViewCell!  //This is the cell currently being displayed
    
    var hourButton : UIButton!
    var dayButton : UIButton!
    var weekButton : UIButton!
    var monthButton : UIButton!
    var yearButton : UIButton!
//    var analysisPeriod = "hour"
    var period = DateValueFormatter.Option.HOUR
//    @IBOutlet weak var techAnalysisViewCell: TechnicalAnalysisCollectionViewCell!
//    @IBOutlet weak var priceChangeViewCell: PriceChangeCollectionViewCell!
    ////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////// For the charts ////////////////////////////////////
    var detailChart: LineChartView!
    var yValues = ["76","81","140","155","161","180","185","110","135","150"]
    var xValues = [1520481238, 1520477643, 1520474041, 1520470500, 1520466959, 1520463362]
    var barChartDataEntry: [BarChartDataEntry] = []
    ////////////////////////////////////////////////////////////////////////////////////////
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return cryptocoins.count
//        collectionView.
        return 4
    }
    
    func loadDataFromServer() {
        if self.appDelegate.cryptocurrenciesOfUser.count == 0 {
            return
        }
        
        // FIXME: load data from
//        BackEndConnection.shared.getStats(eid: self.appDelegate.cryptocurrenciesOfUser[0].exchangeId, ccid: self.appDelegate.cryptocurrenciesOfUser[0].id, cid: self.appDelegate.defaultCurrencyID, processStats: self.updateViewComponentsData)
        
//        BackEndConnection.shared.getChartData(eid: self.appDelegate.cryptocurrenciesOfUser[0].exchangeId, ccid: self.appDelegate.cryptocurrenciesOfUser[0].id, period: period.rawValue, processData: self.updateGraph)
        print("Getting data for \(period.rawValue)")
        let asset = "5ab12ff9981ec843daf57b23"
        BackEndConnection.shared.getAllInfo(assetPairId: asset, period: period.rawValue, processParams: self.updateStatsScreen)
    }
    
    func updateStatsScreen( price:Double, techAnalysis:Double, hVar:Double, dVar:Double, wVar:Double, mVar:Double, data: [(Double,Double)] ){
        DispatchQueue.main.async {
            //This updates the price
            self.cryptocurrenciesCollectionView.activeCell?.cryptocurrencyInfo.priceLabel.text = "US$ \(NSString(format:"%.2f", price))"
//            self.activeCell?.cryptocurrencyInfo.priceLabel.text = "US$ \(NSString(format:"%.2f", price))"
            
            // This updates the Technical Analysis and the Price Change
            let idx = self.contentCollecionView.indexPathsForVisibleItems
            var techAnalysisViewCell = self.contentCollecionView.cellForItem(at: idx[1]) as! TechnicalAnalysisCollectionViewCell
            var priceChangeViewCell = self.contentCollecionView.cellForItem(at: idx[3]) as! PriceChangeCollectionViewCell
            
            //FIXME
            techAnalysisViewCell.suggestion = Int(techAnalysis)%2
            techAnalysisViewCell.suggestionLabel.text = techAnalysisViewCell.suggestionsString[techAnalysisViewCell.suggestion]
            
            priceChangeViewCell.hourChangeLabel.text = "US$ \(NSString(format:"%.2f", hVar))"
            priceChangeViewCell.todayChangeLabel.text = "US$ \(NSString(format:"%.2f", dVar))"
            priceChangeViewCell.weekChangeLabel.text = "US$ \(NSString(format:"%.2f", wVar))"
            priceChangeViewCell.monthChangeLabel.text = "US$ \(NSString(format:"%.2f", mVar))"
            
            priceChangeViewCell.hourVarImage.image = Float(hVar) < 0 ? priceChangeViewCell.downPrice : priceChangeViewCell.upPrice
            priceChangeViewCell.todayVarImage.image = Float(dVar) < 0 ? priceChangeViewCell.downPrice : priceChangeViewCell.upPrice
            priceChangeViewCell.weekVarImage.image = Float(wVar) < 0 ? priceChangeViewCell.downPrice : priceChangeViewCell.upPrice
            priceChangeViewCell.monthVarImage.image = Float(mVar) < 0 ? priceChangeViewCell.downPrice : priceChangeViewCell.upPrice
        }
        
        // This updates the graph
        updateGraph(data:data)
    }
    
    func updateGraph ( data: [(Double,Double)] ){
        // LineChartDetail
        var lineChartDataEntry = [ChartDataEntry]()
        
        for d in data.reversed() {
            let value = ChartDataEntry(x: d.0/1000, y: d.1)
//            print(value.x)
            lineChartDataEntry.append(value)
        }
        
        let statsLineChartDataSet = LineChartDataSet(values: lineChartDataEntry, label: "Number")
        statsLineChartDataSet.setColor(UIColor(hex: "4CEDE5"))         // This is for setting the lines color!
        statsLineChartDataSet.axisDependency = .right
        statsLineChartDataSet.setCircleColor(UIColor(red:0.61, green:0.61, blue:0.61, alpha:1.0))
        statsLineChartDataSet.circleRadius = 6.0
        statsLineChartDataSet.highlightColor = NSUIColor.black
        statsLineChartDataSet.drawFilledEnabled = false
        statsLineChartDataSet.drawCircleHoleEnabled = true
        //        statsLineChartDataSet.drawHorizontalHighlightIndicatorEnabled = false
        statsLineChartDataSet.valueTextColor = UIColor.white
        statsLineChartDataSet.valueFont = UIFont(name: "AvenirNext-Regular", size: 13)!
        statsLineChartDataSet.highlightLineDashLengths = [5, 2.5]
        
        DispatchQueue.main.async {
            self.detailChart.data = LineChartData(dataSet: statsLineChartDataSet)
        }
    }
    
//    func updateViewComponentsData (stats: BasicStats) {
//        DispatchQueue.main.async {
//            let idx = self.contentCollecionView.indexPathsForVisibleItems
//            var techAnalysisViewCell = self.contentCollecionView.cellForItem(at: idx[1]) as! TechnicalAnalysisCollectionViewCell
//            var priceChangeViewCell = self.contentCollecionView.cellForItem(at: idx[3]) as! PriceChangeCollectionViewCell
//            
//            // Update CurrencyCard content
////            self.currencyCard.priceLabel.text = "US$ \(NSString(format:"%.2f", Double(stats.price)))"
////            currencyCard.setNeedsDisplay()
//            
//            // Update TechnicalAnalysis content
//            //FIXME
//            techAnalysisViewCell.suggestion = Int(arc4random())%2
//            techAnalysisViewCell.suggestionLabel.text = techAnalysisViewCell.suggestionsString[techAnalysisViewCell.suggestion]
//            
//            // Update PriceChange content
//            priceChangeViewCell.hourChangeLabel.text = "US$ \(NSString(format:"%.2f", Double(stats.hour)))"
//            priceChangeViewCell.todayChangeLabel.text = "US$ \(NSString(format:"%.2f", Double(stats.day)))"
//            priceChangeViewCell.weekChangeLabel.text = "US$ \(NSString(format:"%.2f", Double(stats.week)))"
//            priceChangeViewCell.monthChangeLabel.text = "US$ \(NSString(format:"%.2f", Double(stats.month)))"
//            
//            priceChangeViewCell.hourVarImage.image = Float(stats.hour) < 0 ? priceChangeViewCell.downPrice : priceChangeViewCell.upPrice
//            priceChangeViewCell.todayVarImage.image = Float(stats.day) < 0 ? priceChangeViewCell.downPrice : priceChangeViewCell.upPrice
//            priceChangeViewCell.weekVarImage.image = Float(stats.week) < 0 ? priceChangeViewCell.downPrice : priceChangeViewCell.upPrice
//            priceChangeViewCell.monthVarImage.image = Float(stats.month) < 0 ? priceChangeViewCell.downPrice : priceChangeViewCell.upPrice
////            priceChangeViewCell.setNeedsDisplay()
//        }
//    }
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        UICollectionViewCell
//    }

    
//
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //        return cryptocoins.count
//        return 6
//    }
//    // definisco la dimensione delle celle della collection
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: IndexPath) -> CGSize {
//        //imposto 3 celle per riga
//        var width = collectionView.bounds.width
//        var height = collectionView.bounds.width / 5
//        if indexPath.item % 2 == 0 {
//            height = 25
////            width = width/2 - 50
//            print("==== \(width)")
//        } else {
//            height = 80
//        }
////        let collectionViewWidth = collectionView.bounds.size.width * (100/3.018)/1000
//        
////        CGSize(width: width, height: he)
//        
//        print(" item \(indexPath.item) size: \(width) x \(height)")
//        return CGSize(width: width, height: CGFloat(height))
//        
//    }
    
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAtIndex section: Int) -> UIEdgeInsets {
        let cellWidthPadding = collectionView.frame.size.width / 30
        let cellHeightPadding = collectionView.frame.size.height / 4
        return UIEdgeInsets(top: cellHeightPadding,left: cellWidthPadding, bottom: cellHeightPadding,right: cellWidthPadding)
    }
//
//    // riempio le righe con una cella ed i valori dell'animale
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        var celda = ""
        
        if ( indexPath.item == 0 ) {
            celda = "cell1"
        } else if ( indexPath.item == 1 ) {
            celda = "cell2"
        } else if ( indexPath.item == 2 ) {
            celda = "cell3"
        } else if ( indexPath.item == 3 ) {
            celda = "cell4"
//        } else if ( indexPath.item == 4) {
//            celda = "cell5"
        } else {
            celda = "cell4"
        }
//        } else if ( indexPath.item == 5 ) {
//            celda = "cell6"
//        }
        
        print(indexPath.item)
        var cell = collectionView.dequeueReusableCell(withReuseIdentifier: celda,
                                                      for: indexPath) as! UICollectionViewCell
        if ( indexPath.item == 0 ) {
//            cell = cell as! PriceChangeCollectionViewCell
            cell.bounds = CGRect(x: 0, y: 0, width: cell.bounds.width, height: 25)
        } else  if ( indexPath.item == 1 ) {
            cell = cell as! TechnicalAnalysisCollectionViewCell
            cell.bounds = CGRect(x: 0, y: 0, width: cell.bounds.width, height: 100)
            cell.frame = CGRect(x: cell.frame.minX, y: cell.frame.minY, width: cell.frame.maxX, height: 100)
        } else  if ( indexPath.item == 2 ) {
//            cell = cell as! PriceChangeCollectionViewCell
            cell.bounds = CGRect(x: 0, y: 0, width: cell.bounds.width, height: 25)
            cell.frame = CGRect(x: cell.frame.minX, y: cell.frame.minY, width: cell.frame.maxX, height: 25)
        } else if ( indexPath.item == 3 ) {
            cell = cell as! PriceChangeCollectionViewCell
            cell.bounds = CGRect(x: 0, y: 0, width: cell.bounds.width, height: 100)
        }
//        cell.nameCoin.text = cryptocoins[indexPath.row].name
//        cell.symbolCoin.text = cryptocoins[indexPath.row].symbol

        return cell
    }
//
    
    override func viewDidLoad() {

        super.viewDidLoad()
        
        // Set background image of top UIView
        let bgGraph = UIImageView(frame: graphView.frame)
        bgGraph.image = #imageLiteral(resourceName: "mainbg")
        bgGraph.contentMode = .scaleAspectFill
        graphView.addSubview(bgGraph)
        
        
        let yButtons = 150
        var bHeight = 20, bWidth = 30
        hourButton = UIButton(frame: CGRect(x: 200, y: yButtons, width: bWidth, height: bHeight))
        hourButton.setTitle("1H", for: .normal)
        hourButton.setTitleColor(UIColor.white, for: .normal)
        hourButton.titleLabel?.textAlignment = .center
        hourButton.titleLabel?.font = UIFont(name: "AvenirNext-Regular", size: 14)
        hourButton.addTarget(self, action: #selector(setPeriodToHour), for: .touchUpInside)
        
        
        let colorBottom =  UIColor(hex: "3EA8BD").cgColor
        let colorTop = UIColor(hex: "3E5D8F").cgColor
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [ colorTop, colorBottom ]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
//        gradientLayer.locations = [ 0.4, 0.65]
        gradientLayer.frame = hourButton.bounds
        hourButton.layer.insertSublayer(gradientLayer, at: 0)
        
        
        dayButton = UIButton(frame: CGRect(x: Int(hourButton.frame.maxX), y: yButtons, width: bWidth, height: bHeight))
        dayButton.setTitle("1D", for: .normal)
        dayButton.setTitleColor(UIColor.white, for: .normal)
        dayButton.titleLabel?.textAlignment = .center
        dayButton.titleLabel?.font = UIFont(name: "AvenirNext-Regular", size: 14)
        dayButton.addTarget(self, action: #selector(setPeriodToDay), for: .touchUpInside)
        
        weekButton = UIButton(frame: CGRect(x: Int(dayButton.frame.maxX), y: yButtons, width: bWidth, height: bHeight))
        weekButton.setTitle("1W", for: .normal)
        weekButton.setTitleColor(UIColor.white, for: .normal)
        weekButton.titleLabel?.textAlignment = .center
        weekButton.titleLabel?.font = UIFont(name: "AvenirNext-Regular", size: 14)
        weekButton.addTarget(self, action: #selector(setPeriodToWeek), for: .touchUpInside)
        
        monthButton = UIButton(frame: CGRect(x: Int(weekButton.frame.maxX), y:yButtons, width: bWidth, height: bHeight))
        monthButton.setTitle("1M", for: .normal)
        monthButton.setTitleColor(UIColor.white, for: .normal)
        monthButton.titleLabel?.textAlignment = .center
        monthButton.titleLabel?.font = UIFont(name: "AvenirNext-Regular", size: 14)
        monthButton.addTarget(self, action: #selector(setPeriodToMonth), for: .touchUpInside)
        
        yearButton = UIButton(frame: CGRect(x: Int(monthButton.frame.maxX), y:yButtons, width: bWidth, height: bHeight))
        yearButton.setTitle("1Y", for: .normal)
        yearButton.setTitleColor(UIColor.white, for: .normal)
        yearButton.titleLabel?.textAlignment = .center
        yearButton.titleLabel?.font = UIFont(name: "AvenirNext-Regular", size: 14)
        yearButton.addTarget(self, action: #selector(setPeriodToYear), for: .touchUpInside)
        
        
//            chChart = LineChartView(frame: CGRect(x:0, y:0, width:graphView.bounds.width, height: graphView.bounds.height))
        detailChart = LineChartView(frame: CGRect(x:0, y:20, width:graphView.bounds.width, height: graphView.bounds.height - 80))
        loadGraph()
//            graphView.addSubview(chChart!)
        
        
//        detailChart.leftAxis.drawGridLinesEnabled = false
//        detailChart.drawGridBackgroundEnabled = false
        
        detailChart.legend.enabled = false
        detailChart.leftAxis.enabled = false
        
        detailChart.maxVisibleCount = 6
        
        detailChart.xAxis.enabled = true
//        detailChart.xAxis.labelPosition = .topInside
//        detailChart.xAxis.drawAxisLineEnabled = false
//        detailChart.xAxis.drawGridLinesEnabled = true
//        detailChart.xAxis.centerAxisLabelsEnabled = true
//        detailChart.xAxis.granularity = 3600
//        detailChart.xAxis.valueFormatter = DateValueFormatter(.DAY)
        detailChart.xAxis.valueFormatter = DateValueFormatter(period)
//        detailChart.xAxis.getFormattedLabel()
        
        
        //FIXME: marker not working when you
        let marker = XYMarkerView(color: UIColor(white: 180/250, alpha: 1),
                                  font: .systemFont(ofSize: 12),
                                  textColor: .white,
                                  insets: UIEdgeInsets(top: 8, left: 8, bottom: 20, right: 8),
                                  xAxisValueFormatter: detailChart.xAxis.valueFormatter!)
        marker.chartView = detailChart
        marker.minimumSize = CGSize(width: 80, height: 40)
        detailChart.marker = marker
        
        loadDataFromServer()
        
        
        
        Timing.shared.setInterval(30) {
            self.loadDataFromServer()
        }
        
        
        
//        print("*********")
//        self.currencyCard.navigationDelegate = self
//        self.cryptocurrenciesInfo.
//        print(cryptocurrenciesInfo)
        cryptocurrenciesCollectionView = CryptocurrencyInfoCollectionViewController()
        cryptocurrenciesCollectionView.nav = self
        cryptocurrenciesInfo.delegate = cryptocurrenciesCollectionView
        cryptocurrenciesInfo.dataSource = cryptocurrenciesCollectionView
//        cryptocurrenciesCollectionView.
        
//        cryptocurrenciesCollectionView.items
//        var size = cryptocurrenciesCollectionView.collectionView(cryptocurrenciesCollectionView, numberOfItemsInSection: 0)
//        for cell in cryptocurrenciesInfo.visibleCells {
//            (cell as! CryptocurrencyInfoCollectionViewCell).cryptocurrencyInfo.navigationDelegate = self
//        }
//
//        let cell = cryptocurrenciesCollectionView.dequeueReusableCell(withReuseIdentifier: "cryptocurrencyinfocell", for: 0) as! CryptocurrencyInfoCollectionViewCell
//        let cell = (cryptocurrenciesCollectionView.cellForItem(at: .init(item: 0, section: 0)) as! CryptocurrencyInfoCollectionViewCell).cryptocurrencyInfo.navigationDelegate = self
//        cell
//        print("*********")
        
        
        graphView.addSubview(detailChart!)
        graphView.addSubview(hourButton!)
        graphView.addSubview(dayButton!)
        graphView.addSubview(weekButton!)
        graphView.addSubview(monthButton!)
        graphView.addSubview(yearButton!)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    func loadGraph() {
        var data = LineChartData()
        
        // LineChartDetail
        var lineChartDataEntry = [ChartDataEntry]()
        self.yValues = ["7621.22",  "8132.12",  "9074.79",  "11028.30", "10352.23", "10121.34"]
        self.xValues = [1520463362,
                        1520466959,
                        1520470500,
                        1520474041,
                        1520477643,
                        1520481238]
        
        // iterate through numbers
        for i in 0..<self.yValues.count {
            // create point in graph for each number
            let value = ChartDataEntry(x: Double(self.xValues[i]), y: Double(self.yValues[i])!)
//            let value = ChartDataEntry(x: Double(i), y: Double(self.yValues[i])!)
            // append to the lineChart
//            print(Date(timeIntervalSince1970: Double(self.xValues[i])))
            lineChartDataEntry.append(value)
        }
        
        
        let statsLineChartDataSet = LineChartDataSet(values: lineChartDataEntry, label: "Number")
        statsLineChartDataSet.setColor(UIColor(hex: "4CEDE5"))         // This is for setting the lines color!
        statsLineChartDataSet.axisDependency = .right
        statsLineChartDataSet.setCircleColor(UIColor(red:0.61, green:0.61, blue:0.61, alpha:1.0))
        statsLineChartDataSet.circleRadius = 6.0
        statsLineChartDataSet.highlightColor = NSUIColor.black
        statsLineChartDataSet.drawFilledEnabled = false
        statsLineChartDataSet.drawCircleHoleEnabled = true
//        statsLineChartDataSet.drawHorizontalHighlightIndicatorEnabled = false
        statsLineChartDataSet.valueTextColor = UIColor.white
        statsLineChartDataSet.valueFont = UIFont(name: "AvenirNext-Regular", size: 13)!
        statsLineChartDataSet.highlightLineDashLengths = [5, 2.5]
//        chartHomeDetail.drawCirclesEnabled = false
//        chartHomeDetail.drawValuesEnabled = false
//        statsLineChartDataSet.lineDashLengths = [5, 2.5]
        
        
        
//        yaxis = detailChart.getAxis(YAxis.AxisDependency.right)
//        yaxis.drawLabelsEnabled = false
//        yaxis.enabled = false
//        yaxis.drawAxisLineEnabled = false
        
        data = LineChartData()
        data.addDataSet(statsLineChartDataSet)
        
        
        detailChart.data = data
        detailChart.chartDescription?.text = ""
        
    }
    
    @objc func setPeriodToHour(_ sender: UIButton ){
//        self.analysisPeriod = "hour"
        period = DateValueFormatter.Option.HOUR
        loadDataFromServer()
//        sender.layer.ba
        
        setButtonBackground(sender)
    }

    @objc func setPeriodToDay(_ sender: UIButton ){
//        self.analysisPeriod = "day"
        period = DateValueFormatter.Option.DAY
        loadDataFromServer()
        setButtonBackground(sender)
    }
    
    @objc func setPeriodToWeek(_ sender: UIButton ){
//        self.analysisPeriod = "week"
        period = DateValueFormatter.Option.WEEK
        loadDataFromServer()
        setButtonBackground(sender)
    }
    
    @objc func setPeriodToMonth(_ sender: UIButton ){
//        self.analysisPeriod = "month"
        period = DateValueFormatter.Option.MONTH
        loadDataFromServer()
        setButtonBackground(sender)
    }
    
    @objc func setPeriodToYear(_ sender: UIButton ){
//        self.analysisPeriod = "year"
        period = DateValueFormatter.Option.YEAR
        loadDataFromServer()
        setButtonBackground(sender)
    }
    
    func setButtonBackground (_ sender: UIButton ){
        
        detailChart.xAxis.valueFormatter = DateValueFormatter(period)
        
        for b in [ hourButton, dayButton, weekButton, monthButton, yearButton ] {
//            print ( b?.layer.sublayers?.count ?? 0 )
            if ( b?.layer.sublayers?.count ?? 0 > 1 ) {
                b?.layer.sublayers?.remove(at: 0)
            }
        }
//        sender.layer.sublayers?.count
//        dayButton.layer.sublayers?.remove(at: 0)
//        weekButton.layer.sublayers?.remove(at: 0)
//        monthButton.layer.sublayers?.remove(at: 0)
//        yearButton.layer.sublayers?.remove(at: 0)
        
        let colorBottom =  UIColor(hex: "3EA8BD").cgColor
        let colorTop = UIColor(hex: "3E5D8F").cgColor
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [ colorTop, colorBottom ]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
        //        gradientLayer.locations = [ 0.4, 0.65]
        gradientLayer.frame = sender.bounds
        
        sender.layer.insertSublayer(gradientLayer, at: 0)
        
        
    }
}
