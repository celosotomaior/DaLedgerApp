//
//  NewAlertViewController.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/21/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit

class NewAlertViewController: UIViewController {
    
    var appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var currencyPairField: UITextField!
    
    @IBOutlet weak var createBtn: UIButton!
    @IBOutlet weak var contentView: UIView!
    
    let amount: UITextField = UITextField(frame: CGRect(x: 0, y:0, width: 335, height: 50))
    let porcentageLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 40))
    var percentageLabelColor: UIColor!
    var porcentageString = "0%"
    let step:Float=10
    var alertDirection = 0
    var pickerData: [[String]] = [[String]]()
    private var alertOptions: [String:Any] = [:]
    
    private var cryptoPickerView: UIPickerView!
    
    @IBAction func createAlert(_ sender: UIButton) {
//        guard let alertType = Int(alertOptions["type"] as! String) else { return }
        if (alertOptions["type"] as! Int == 0) {
            alertOptions["value"] = amount.text
        }
        print(alertOptions)
        guard let valueDouble = Double(alertOptions["value"] as! String) else { return }
        
        let newAlert = Alert(type: alertOptions["type"] as! Int, currency1: alertOptions["currency1"] as! String, currency2: alertOptions["currency2"] as! String, value: valueDouble)
        appDelegate.alerts.append(newAlert)

        dismiss(animated: true) {
            print("dismiss")
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let bgGraph = UIImageView(frame: headerView.frame)
        bgGraph.image = #imageLiteral(resourceName: "mainbg")
        bgGraph.contentMode = .scaleToFill //scaleAspectFit scaleAspectFill
        headerView.addSubview(bgGraph)
        
        let label = UILabel(frame: headerView.frame)
        label.center = headerView.center
        label.textAlignment = .center
        label.textColor = UIColor.white
        label.text = "New Alert"
        headerView.addSubview(label)
        currencyPairField.textAlignment = .center
        currencyPairField.layer.cornerRadius = 5
        currencyPairField.layer.borderColor = UIColor(hex: "2E92A7").cgColor
        currencyPairField.layer.borderWidth = CGFloat(1)
        currencyPairField.placeholder = "Choose your pair..."
        
        pickerData = [
            ["BTC","LTC","ETH"],
            ["USD","EUR","BRL"]
        ]
        
        addPriceElements()
    }
    
    @IBAction func dismissAlert(_ sender: UIButton) {
        dismiss(animated: true) {
            print("dismiss")
        }
    }
    
    @IBAction func changePricePercentage(_ sender: UISegmentedControl) {
        print("changed to \(sender.selectedSegmentIndex)")
        contentView.subviews.forEach { $0.removeFromSuperview() }
        if ( sender.selectedSegmentIndex == 0 ){
            addPriceElements()
        } else {
            addPercentageElements()
        }
    }
    
    func addPercentageElements(){
        alertOptions["type"] = 1
        porcentageLabel.text = porcentageString
        porcentageLabel.textAlignment = .center
        porcentageLabel.center = CGPoint(x: contentView.bounds.width/2, y: contentView.bounds.height/2 - 70)
        porcentageLabel.textColor = UIColor(red:0.80, green:0.80, blue:0.80, alpha:1.0)
        
        let slider = UISlider(frame: CGRect(x: 0, y: 0, width: 335, height: 44))
        slider.tintColor = UIColor(hex: "2E92A7")
        slider.center = CGPoint(x: contentView.bounds.width/2, y: contentView.bounds.height/2 - 40)
        slider.addTarget(self, action: #selector(NewAlertViewController.sliderPriceValueDidChange(_:)), for: .valueChanged)
        slider.isContinuous = true
        slider.maximumValue = 100
        slider.minimumValue = -100
        slider.value = 0
        let frequency = UISegmentedControl(frame: CGRect(x: 0, y: 0, width: 335, height: 27))
        frequency.insertSegment(withTitle: "Hour", at: 0, animated: true)
        frequency.insertSegment(withTitle: "Day", at: 1, animated: true)
        frequency.insertSegment(withTitle: "Week", at: 2, animated: true)
        frequency.tintColor = UIColor(hex: "2E92A7")
        frequency.center = slider.center.applying(CGAffineTransform(translationX: 0, y: 70))
        
        contentView.addSubview(porcentageLabel)
        contentView.addSubview(slider)
        contentView.addSubview(frequency)
        
    }
    
    func addPriceElements(){
        alertOptions["type"] = 0
        let belowAbove = UISegmentedControl(frame: CGRect(x: 0, y: 0, width: 335, height: 27))
        belowAbove.insertSegment(withTitle: "Below", at: 0, animated: true)
        belowAbove.insertSegment(withTitle: "Above", at: 1, animated: true)
        belowAbove.tintColor = UIColor(hex: "2E92A7")
        belowAbove.center = CGPoint(x: contentView.bounds.width/2, y: contentView.bounds.height/2 - 45)
        belowAbove.addTarget(self, action: #selector(NewAlertViewController.belowAboveChanged(_:)), for: .valueChanged)
        
        amount.tintColor = UIColor(hex: "2E92A7")
        amount.layer.cornerRadius = 5
        amount.textAlignment = .right
        amount.setLeftPaddingPoints(10)
        amount.setRightPaddingPoints(10)
        amount.keyboardType = UIKeyboardType.numberPad
        amount.layer.borderColor = UIColor(hex: "2E92A7").cgColor
        amount.center = CGPoint(x: contentView.bounds.width/2, y: contentView.bounds.height/2 + 30)
        amount.layer.borderColor = UIColor(hex: "2E92A7").cgColor
        amount.layer.borderWidth = CGFloat(1)
        amount.placeholder = "Input here the amount"
        
        contentView.addSubview(belowAbove)
        contentView.addSubview(amount)
    }
    
    @objc func belowAboveChanged(_ sender:UISegmentedControl){
        if sender.selectedSegmentIndex == 0 {
            print(0)
            alertOptions["priceDirection"]=0
        } else {
            print(1)
            alertOptions["priceDirection"]=1
        }
        print(alertOptions)
    }
    
    @objc func sliderPriceValueDidChange(_ sender:UISlider!) {
        let currentValue = round(sender.value)
        
        if (currentValue == 0) {
            percentageLabelColor = UIColor(red:0.80, green:0.80, blue:0.80, alpha:1.0)
        } else {
            if (currentValue > 0) {
                percentageLabelColor = UIColor(red:0.00, green:0.80, blue:0.00, alpha:1.0)
            } else {
                percentageLabelColor = UIColor(red:0.80, green:0.00, blue:0.00, alpha:1.0)
            }
        }
        porcentageLabel.textColor = percentageLabelColor
        porcentageLabel.text = String(format: "%.0f%%", currentValue)
        
        let roundedStepValue = round(sender.value / step) * step
        sender.value = roundedStepValue
        alertOptions["value"] = String(roundedStepValue)
    }
    @objc func doneClick(_ sender: Any) {
        currencyPairField.resignFirstResponder()
    }
    @objc func cancelClick(_ sender: Any) {
        currencyPairField.resignFirstResponder()
    }
    
    func setupPairPicker() {
        cryptoPickerView = UIPickerView()
        cryptoPickerView.frame = CGRect(x:0,y:0,width:self.view.bounds.width,height: 200)
        cryptoPickerView.delegate = self
        cryptoPickerView.dataSource = self
        cryptoPickerView.showsSelectionIndicator = true
        cryptoPickerView.selectRow(1, inComponent: 0, animated: true)
        cryptoPickerView.selectRow(1, inComponent: 1, animated: true)
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor(hex: "2E92A7")
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(doneClick(_:)))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelClick(_:)))
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        
        toolBar.isUserInteractionEnabled = true
        currencyPairField.inputView = cryptoPickerView
        currencyPairField.inputAccessoryView = toolBar
    }
    
}
extension UITextField {
    func setLeftPaddingPoints(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    func setRightPaddingPoints(_ amount:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.rightView = paddingView
        self.rightViewMode = .always
    }
}

extension NewAlertViewController : UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData[component].count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[component][row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if (component==0) {
            alertOptions["currency1"] = pickerData[0][row]
        } else {
            alertOptions["currency2"] = pickerData[1][row]
        }
        if (alertOptions["currency1"] != nil && alertOptions["currency2"] != nil) {
        currencyPairField.text = "\(alertOptions["currency1"]!) / \(alertOptions["currency2"]!)"
        }
        
        print(alertOptions)
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
//        print(textField)
        setupPairPicker()
    }
    
}
