//
//  ColViewCell.swift
//  DaLedgrApp
//
//  Created by TonySellitto on 20/02/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit
import Cards

class ColViewCell: UICollectionViewCell {
        
    
   // @IBOutlet weak var card: CardHighlight!
    
   
    
    @IBOutlet weak var card: CardHighlight!
//    override func awakeFromNib() {
//        super.awakeFromNib()
//    }
    
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//        // Configure the view for the selected state
//    }
//
    
//    override var frame: CGRect {
//        get {
//            return super.frame
//        }
//        set (newFrame) {
//            var frame = newFrame
//            let newWidth = frame.width * 0.95 // get 80% width here
//
//            let newHeigth = frame.height * 0.95
//            let space = (frame.width - newWidth) / 2
//            let space2 = (frame.height - newHeigth) / 2
//            frame.size.width = newWidth
//            frame.size.height = newHeigth
//            frame.origin.x += space
//            frame.origin.y += space2
//            super.frame = frame
//
//        }
//    }
    
    
    
}


