//
//  ItemViewController.swift
//  DaLedgrApp
//
//  Created by TonySellitto on 08/02/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit
import Spring

class ItemViewController: UIViewController {
    
    var appDelegate = UIApplication.shared.delegate as! AppDelegate

    var itemIndex : Int = 0
    var imageName : String = ""{
        didSet{
            if let imageView = contentImageView{
                imageView.image = UIImage(named: imageName)
            }
            
        }
    }
     @IBOutlet weak var text: UILabel!
    
    var label : String = ""
   
    
  
   
    @IBOutlet weak var expertRadioButton: RadioButton!
    
    
    @IBOutlet weak var beginnerRadioButton: RadioButton!
    
    //var startButtonVisible : Bool = false
  
    //var beginnerButtonVisible : Bool = false
    //var expertButtonVisible : Bool = false
    
     var messageStartButton = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        startButton.setTitle(messageStartButton, for: .normal)
        //beginnerRadioButton?.alternateButton = [expertRadioButton!]
        //expertRadioButton?.alternateButton = [beginnerRadioButton!]
        //beginnerRadioButton.isSelected = true
        //expertRadioButton.isSelected = false
        //contentImageView.image = UIImage(named: imageName)
//        if(startButtonVisible == true){
//            startButton.isHidden = false
//        }
//        if(beginnerButtonVisible == false){
//            beginnerRadioButton.isHidden = true
//        }
//        if(expertButtonVisible == false){
//            expertRadioButton.isHidden = true
//        }
       
        //text = UILabel(frame: CGRect(x: 10, y: 10, width:  self.view.frame.size.width - 20, height: 80))
        
        //text.font = UIFont(name: FuturaMedium, size: 25)
        
       
        text.text! = label
        text.sizeToFit()
        text.numberOfLines = 0
//        text.textAlignment = .left
        text.lineBreakMode = .byWordWrapping //Avenir
//        text.font = UIFont.systemFont(ofSize: 30, weight: .regular)
        text.textColor = UIColor.white
        
        self.view.addSubview(text)
        text.adjustsFontSizeToFitWidth = true
      
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var contentImageView: UIImageView!
    
    
    @IBOutlet weak var startButton: SpringButton!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func tapBeginnerButton(_ sender: RadioButton) {
        beginnerRadioButton.animation = "pop"
        beginnerRadioButton.duration = 0.8
        beginnerRadioButton.animate()
//        appDelegate.type = 1//"beginner"
        
    }
    
    @IBAction func tapExpertButton(_ sender: RadioButton) {
        expertRadioButton.animation = "pop"
        expertRadioButton.duration = 0.8
        expertRadioButton.animate()
//        appDelegate.type = 2//"expert"
    }
    
    public func animationStartButton(){
        startButton.animation = "squeezeLeft"
        beginnerRadioButton.duration = 0.8
        beginnerRadioButton.animate()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
