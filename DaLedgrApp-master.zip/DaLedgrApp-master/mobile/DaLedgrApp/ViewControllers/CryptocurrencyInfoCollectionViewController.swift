//
//  CryptocurrencyInfoCollectionViewController.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 3/12/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit

private let reuseIdentifier = "cryptocurrencyinfocell"

class CryptocurrencyInfoCollectionViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
//class CryptocurrencyInfoCollectionViewController: UICollectionView, UICollectionViewDelegate, UICollectionViewDataSource {
    var nav : CurrencyCardNavigationDelegate!
    var activeCell : CryptocurrencyInfoCollectionViewCell!
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.cryptocurrenciesOfUser.count
//        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! CryptocurrencyInfoCollectionViewCell
        cell.cryptocurrencyInfo.setInfo(index: indexPath.row, cell: cell)
        cell.cryptocurrencyInfo.navigationDelegate = self.nav
        self.activeCell = cell
//        let appDelegate = UIApplication.shared.delegate as! AppDelegate
//        appDelegate
//        cell.cryptocurrencyInfo.navigationDelegate = self
        //        cell.cryptocurrencyInfo.navigationDelegate = collectionView
        return cell
    }
    
//    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! CryptocurrencyInfoCollectionViewCell
//
//        let appDelegate = UIApplication.shared.delegate as! AppDelegate
//        appDelegate.activeCellIndex = indexPath.row
//        print("active cell \(appDelegate.activeCellIndex)" )
////        return cell
//    }
    

}
