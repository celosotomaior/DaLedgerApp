//
//  PageViewController.swift
//  DaLedgrApp
//
//  Created by TonySellitto on 08/02/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit

class PageViewController: UIViewController, UIPageViewControllerDataSource {
    
    var pageViewController : UIPageViewController?
    let contentImages = ["gauge","first","second","gauge"]
    let contentText = [NSLocalizedString("content1", comment: "content 1"),NSLocalizedString("content2", comment: "content 2"),NSLocalizedString("content3", comment: "content 3")]
    
    var backgroundImage : [UIImage?] = [ #imageLiteral(resourceName: "simbols"),#imageLiteral(resourceName: "simbols3"), #imageLiteral(resourceName: "simbols2") , nil ]
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        let itemController = viewController as!ItemViewController
        if itemController.itemIndex > 0{
            return getItemController(itemController.itemIndex - 1)
        }
        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        let itemController = viewController as! ItemViewController
        if itemController.itemIndex + 1 < contentText.count{
            return getItemController(itemController.itemIndex + 1)
        }
        return nil
    }
    
    func presentationCount(for pageViewController: UIPageViewController) -> Int {
        return contentText.count
    }
    
    func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        return 0
    }
    
    func currentControllerIndex() -> Int{
        let pageItemController = self.currentControllerIndex()
        if let controller = pageItemController as? ItemViewController{
            return controller.itemIndex
        }
        return -1
    }
    
    func currentController() -> UIViewController?{
        if(self.pageViewController?.viewControllers?.count)! > 0 {
            return self.pageViewController?.viewControllers![0]
        }
        return nil
    }
    
    func getItemController(_ itemIndex : Int) -> ItemViewController?{
        /*if itemIndex < contentImages.count - 1{
         let pageItemController = self.storyboard?.instantiateViewController(withIdentifier: "ItemController") as! ItemViewController
         pageItemController.startButtonVisible = false
         pageItemController.itemIndex = itemIndex
         pageItemController.imageName = contentImages[itemIndex]
         pageItemController.label = contentText[itemIndex]
         return pageItemController
         }
         if itemIndex == contentImages.count - 1{
         let pageItemController = self.storyboard?.instantiateViewController(withIdentifier: "ItemController") as! ItemViewController
         
         pageItemController.startButtonVisible = true
         pageItemController.itemIndex = itemIndex
         pageItemController.imageName = contentImages[itemIndex]
         pageItemController.label = contentText[itemIndex]
         return pageItemController
         }
         return nil
         */
        
        let colorTop =  UIColor(red: 48.0/255.0, green: 210.0/255.0, blue: 190.0/255.0, alpha: 1).cgColor
        let colorBottom = UIColor(red: 52.0/255.0, green: 147.0/255.0, blue: 196.0/255.0, alpha: 1).cgColor
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [ colorTop, colorBottom]
        //gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
        //gradientLayer.endPoint = CGPoint(x: 0.0, y: 0.5)
        gradientLayer.locations = [ 0.0, 0.83]
        
        //gradientLayer.frame = (self.pageViewController?.view.bounds)!
        
        
        if itemIndex < contentText.count - 1{
            let pageItemController = self.storyboard?.instantiateViewController(withIdentifier: "ItemController") as! ItemViewController
            pageItemController.messageStartButton = "Skip Intro"
            //pageItemController.startButtonVisible = false
            //pageItemController.beginnerButtonVisible = false
            //pageItemController.expertButtonVisible = false
            pageItemController.itemIndex = itemIndex
            pageItemController.imageName = contentImages[itemIndex]
            pageItemController.label = contentText[itemIndex]
            //pageItemController.text.font =  UIFont.systemFont(ofSize: 19, weight: .regular)
            
            let bgImageView = UIImageView(frame: self.view.frame)
            bgImageView.image = backgroundImage[itemIndex]
            bgImageView.contentMode = .scaleAspectFill
            bgImageView.alpha = 0.6
            //bgImageView.sizeToFit()
            
            gradientLayer.frame = pageItemController.view.bounds
            
            pageItemController.view.layer.insertSublayer(gradientLayer, at: 0)
            
            pageItemController.view.insertSubview(bgImageView, at: 1)
            
            return pageItemController
        }
        if itemIndex == contentText.count - 1{
            let pageItemController = self.storyboard?.instantiateViewController(withIdentifier: "ItemController") as! ItemViewController
            
            
            pageItemController.messageStartButton = "Start"
            //pageItemController.startButtonVisible = true
            //pageItemController.beginnerButtonVisible = true
            //pageItemController.expertButtonVisible = true
            pageItemController.itemIndex = itemIndex
            pageItemController.imageName = contentImages[itemIndex]
            pageItemController.label = contentText[itemIndex]
            //pageItemController.text.font =  UIFont.systemFont(ofSize: 19, weight: .regular)
            
            let bgImageView = UIImageView(frame: self.view.frame)
            bgImageView.image = backgroundImage[itemIndex]
            bgImageView.contentMode = .scaleAspectFill
            
            //          pageItemController.view.insertSubview(bgImageView, at: 0)
            
            bgImageView.alpha = 0.6
            //bgImageView.sizeToFit()
            
            gradientLayer.frame = pageItemController.view.bounds
            
            pageItemController.view.layer.insertSublayer(gradientLayer, at: 0)
            
            pageItemController.view.insertSubview(bgImageView, at: 1)
            
            
            
            
            return pageItemController
        }
        return nil
    }
    
    func setGradientBackground() {
        let colorTop =  UIColor(red: 48.0/255.0, green: 210.0/255.0, blue: 190.0/255.0, alpha: 1).cgColor
        let colorBottom = UIColor(red: 52.0/255.0, green: 147.0/255.0, blue: 196.0/255.0, alpha: 1).cgColor
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [ colorTop, colorBottom]
        //gradientLayer.startPoint = CGPoint(x: 0.5, y: 1.0)
        //gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
        gradientLayer.locations = [ 0.0, 0.83]
        gradientLayer.frame = self.view.bounds
        
        self.view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setGradientBackground()
        createPageViewController()
        setupPageControl()
        
        
        
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func createPageViewController(){
        let pageController = self.storyboard?.instantiateViewController(withIdentifier: "PageController") as! UIPageViewController
        pageController.dataSource = self
        
        if contentText.count > 0{
            let firstController = getItemController(0)!
            let startingViewControllers = [firstController]
            pageController.setViewControllers(startingViewControllers, direction: UIPageViewControllerNavigationDirection.forward, animated: false, completion: nil)
        }
        pageViewController = pageController
        addChildViewController(pageViewController!)
        self.view.addSubview(pageViewController!.view)
        pageViewController?.didMove(toParentViewController: self)
        
    }
    
    func setupPageControl(){
        //let colorDown =  UIColor(red: 52.0/255.0, green: 153.0/255.0, blue: 173.0/255.0, alpha: 1)
        let colorAppaerence =  UIColor(red: 52.0/255.0, green: 147.0/255.0, blue: 196.0/255.0, alpha: 1)
        let colorBottom =  UIColor(red: 48.0/255.0, green: 210.0/255.0, blue: 190.0/255.0, alpha: 1).cgColor
        let colorTop = UIColor(red: 52.0/255.0, green: 147.0/255.0, blue: 196.0/255.0, alpha: 1).cgColor
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [ colorTop, colorBottom]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 1.0)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.0)
        gradientLayer.locations = [ 0.5, 0.65]
        gradientLayer.frame = self.view.bounds
        
        let appearance = UIPageControl.appearance()
        appearance.pageIndicatorTintColor = UIColor.darkGray
        appearance.currentPageIndicatorTintColor = UIColor.white
        appearance.backgroundColor = colorAppaerence
        
        
    }
    
    
}

/*
 // MARK: - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
 // Get the new view controller using segue.destinationViewController.
 // Pass the selected object to the new view controller.
 }
 */


