//
//  SettingsViewController.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/7/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit
import UserNotifications

class SettingsViewController: UIViewController{
   
    

    @IBOutlet weak var titleView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setGradientBackground()
   
        // Do any additional setup after loading the view.
//        let label = UILabel(frame: self.view.frame)
//        label.center = self.view.center
//        label.textAlignment = .center
//        label.text = "Settings"
//        self.view.addSubview(label)
//        print("SettingsViewController")
//        let bgGraph = UIImageView(frame: titleView.frame)
//        bgGraph.image = #imageLiteral(resourceName: "mainbg")
//        bgGraph.contentMode = .scaleToFill //scaleAspectFit scaleAspectFill
//        titleView.addSubview(bgGraph)
        
        // Do any additional setup after loading the view.
        let label = UILabel(frame: titleView.frame)
        label.center = titleView.center
        label.textAlignment = .center
        label.textColor = UIColor.white
        label.text = "Settings"
        titleView.addSubview(label)
        
//        let settingsTableView = UITableView(frame: CGRect(x: 0, y: titleView.bounds.height, width: self.view.frame.width, height: self.view.frame.height-titleView.bounds.height))
//        
//        let cell1 = UITableViewCell(frame: CGRect(x:0, y:0, width: settingsTableView.frame.width, height: settingsTableView.frame.height/5))
//        let cell2 = UITableViewCell(frame: CGRect(x:0, y:0, width: settingsTableView.frame.width, height: settingsTableView.frame.height/5))
//        let cell3 = UITableViewCell(frame: CGRect(x:0, y:0, width: settingsTableView.frame.width, height: settingsTableView.frame.height/5))
//        let cell4 = UITableViewCell(frame: CGRect(x:0, y:0, width: settingsTableView.frame.width, height: settingsTableView.frame.height/5))
//        let cell5 = UITableViewCell(frame: CGRect(x:0, y:0, width: settingsTableView.frame.width, height: settingsTableView.frame.height/5))
//        
//        settingsTableView.insertRo
//        
//        self.view.addSubview(settingsTableView)
    }
    
    
    

    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func setGradientBackground() {
        let colorBottom =  UIColor(red: 48.0/255.0, green: 210.0/255.0, blue: 190.0/255.0, alpha: 1).cgColor
        let colorTop = UIColor(red: 52.0/255.0, green: 147.0/255.0, blue: 196.0/255.0, alpha: 1).cgColor
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [ colorTop, colorBottom]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 1.0)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.0)
        gradientLayer.locations = [ 0.4, 0.65]
        gradientLayer.frame = self.view.bounds
        
        self.titleView.layer.insertSublayer(gradientLayer, at: 0)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
