//
//  CustomButton.swift
//  DaLedgrApp
//
//  Created by TonySellitto on 21/02/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit
import Spring

class CustomButton: SpringButton{

    
    override func awakeFromNib() {
        let colorInButton =  UIColor(red: 224.0/255.0, green: 174.0/255.0, blue: 21.0/255.0, alpha: 1)
        let colorBorderButton = UIColor(red: 224.0/255.0, green: 174.0/255.0, blue: 21.0/255.0, alpha: 1).cgColor
        self.layer.cornerRadius = 5
        self.layer.borderWidth = 2.2
        self.layer.masksToBounds = true
        
        self.backgroundColor = colorInButton
        self.tintColor = colorInButton
        self.layer.borderColor = colorBorderButton
        self.setTitleColor(UIColor.white, for: .normal)
        
    }

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
