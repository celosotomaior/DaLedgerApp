//
//  AssetViewController.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/19/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit

class AssetViewController: UIViewController {

    @IBOutlet weak var cryptocurrencyIcon: UIImageView!
    @IBOutlet weak var cryptocurrencyName: UILabel!
    @IBOutlet weak var cryptocurrencySymbol: UILabel!
    @IBOutlet weak var cryptocurrencyPrice: UILabel!
    @IBOutlet weak var exchangeButton: UIButton!
    
    public var cryptoName : String = ""
    public var cryptoSymbol : String = ""
    public var cryptoPrice : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        cryptocurrencyName.text = cryptoName
        cryptocurrencySymbol.text = cryptoSymbol
        cryptocurrencyPrice.text = cryptoPrice
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
