//
//  CryptocurrencyInfoCollectionView.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 3/12/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit

class CryptocurrencyInfoCollectionView: UICollectionView, UICollectionViewDelegate, UICollectionViewDataSource {
    
    private let reuseIdentifier = "cryptocurrencyinfocell"
    
    var cryptos = [ 1,2,3]
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cryptos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! CryptocurrencyInfoCollectionViewCell
        print("====")
        print(indexPath.row)
        print("====")
        cell.cryptocurrencyInfo.setElements()
//        cell.cryptocurrencyInfo.navigationDelegate = collectionView
        return cell
    }
    
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
