//
//  TipsViewController.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/7/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit
import Cards


class TipsViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    let itemTitles = ["TIP 1°",
                "TIP 2°"]
    let titles = [NSLocalizedString("tip1", comment: "Tip about wallet"),NSLocalizedString("tip2", comment: "Tip about wallet")]
        //["What is the most secure wallet?", "About Bitcoin?"]
    let contentText = [NSLocalizedString("tip3", comment: "answerIs"),NSLocalizedString("tip4", comment: "")]
    
       // ["The most secure wallet is the paper wallet. You can have a lot of copies and keep than safe with you and with the ones that you trust most", ""]
    let images : [UIImage] = [#imageLiteral(resourceName: "wallet"), #imageLiteral(resourceName: "graph"),#imageLiteral(resourceName: "mvBackground")]
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return itemTitles.count
    }
    
    @IBOutlet weak var card: CardHighlight!
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell1",
                                                      for: indexPath) as! ColViewCell
        cell.card.backgroundImage = images[indexPath.item]
        cell.card.title = titles[indexPath.item]
        
        cell.card.itemTitle = itemTitles[indexPath.row]
        cell.card.itemSubtitle = ""
        
        let cardContent = storyboard?.instantiateViewController(withIdentifier: "CardContent") as! CardContentViewController
        
        cell.card.shouldPresent(cardContent, from: self, fullscreen: true)
        
        if indexPath.item == 1{
            //let textColor  = UIColor(displayP3Red: 50.0, green: 177.0, blue: 180.0, alpha: 1.0)
            //cell.card.textColor = textColor
            
            cardContent.contentLabel.text = contentText[indexPath.row]
        }
        else{
            let textColor  = UIColor(displayP3Red: 50.0, green: 177.0, blue: 180.0, alpha: 1.0)
            cell.card.textColor = textColor
            cell.card.textColor = UIColor.white
            
            cardContent.contentLabel.text = contentText[indexPath.row]
        }
            return cell

    }

    @IBOutlet weak var cardsCollection: UICollectionView!
    
    @IBOutlet weak var label: UILabel!
    
    func setGradientBackground() {
        let colorBottom =  UIColor(red: 48.0/255.0, green: 210.0/255.0, blue: 190.0/255.0, alpha: 1).cgColor
        let colorTop = UIColor(red: 52.0/255.0, green: 147.0/255.0, blue: 196.0/255.0, alpha: 1).cgColor
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [ colorTop, colorBottom]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 1.0)
        gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.0)
        gradientLayer.locations = [ 0.4, 0.65]
        gradientLayer.frame = self.view.bounds
        
        self.topView.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    
    //@IBOutlet weak var card: CardHighlight!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setGradientBackground()
        // Do any additional setup after loading the view.
        label.text = "Tips"
        
        label.textColor = UIColor.white
//        let bgGraph = UIImageView(frame: topView.frame)
//        bgGraph.image = #imageLiteral(resourceName: "mainbg")
//        //bgGraph.contentMode = .scaleAspectFill
//        topView.addSubview(bgGraph)
//        topView.addSubview(label)
        
        //card.buttonText = "VIEW"
//        card.category = "today's movie"
        
//        let cardContent = storyboard?.instantiateViewController(withIdentifier: "CardContent")
//        card.shouldPresent(cardContent, from: self)
        
        //let cardContent = storyboard?.instantiateViewController(withIdentifier: "CardContent")
      //  card.shouldPresent(cardContent, from: self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var topView: UIView!
    
    @IBOutlet weak var segmentControl: UISegmentedControl!
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
