//
//  CustomView.swift
//  DaLedgrApp
//
//  Created by TonySellitto on 21/02/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit

class CustomView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
