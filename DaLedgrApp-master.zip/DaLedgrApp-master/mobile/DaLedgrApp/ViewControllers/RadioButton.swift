//
//  RadioButton.swift
//  DaLedgrApp
//
//  Created by TonySellitto on 14/02/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit
import Spring

class RadioButton: SpringButton {

    var alternateButton:Array<RadioButton>?
    
    override func awakeFromNib() {
        self.layer.cornerRadius = 5
        self.layer.borderWidth = 2.2
        self.layer.masksToBounds = true
    }
    
    func unselectAlternateButtons(){
        if alternateButton != nil {
            self.isSelected = true
            
            for aButton:RadioButton in alternateButton! {
                aButton.isSelected = false
            }
        }else{
            toggleButton()
        }
    }
    
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        unselectAlternateButtons()
        super.touchesBegan(touches, with: event)
    }
    
    func toggleButton(){
        self.isSelected = !isSelected
    }
    
    override var isSelected: Bool {
        didSet {
            if isSelected {
                //let turquoise = UIColor(red: 97, green: 203, blue: 208, alpha: 1)
                self.layer.borderColor = #colorLiteral(red: 0, green: 0.7120764256, blue: 0.7410709262, alpha: 1)
                self.setTitleColor(#colorLiteral(red: 0, green: 0.7120764256, blue: 0.7410709262, alpha: 1), for: .normal)
                
                
                
            } else {
                //let grey = UIColor(red: 152, green: 152, blue: 152, alpha: 1)
                self.layer.borderColor = #colorLiteral(red: 0.5960180163, green: 0.596120894, blue: 0.5960043073, alpha: 1)
                self.setTitleColor(#colorLiteral(red: 0.5960180163, green: 0.596120894, blue: 0.5960043073, alpha: 1), for: .normal)
            }
        }
    }

}
