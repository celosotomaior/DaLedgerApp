//
//  ExchangeSettingsTableViewCell.swift
//  DaLedgrApp
//
//  Created by Edson Ticona Zegarra on 2/26/18.
//  Copyright © 2018 Edson Ticona Zegarra. All rights reserved.
//

import UIKit

class ExchangeSettingsTableViewCell: UITableViewCell {

    @IBOutlet weak var exchangeLabel: UILabel!
    @IBOutlet weak var checkBoxImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
