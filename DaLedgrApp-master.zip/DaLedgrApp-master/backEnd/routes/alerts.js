var express = require('express');
var router = express.Router();
var MongoClient = require('mongodb').MongoClient

const f = require('util').format;

const user = encodeURIComponent('cryptoshi77');
const password = encodeURIComponent('j5msi5kx92_');
const authMechanism = 'DEFAULT';
const host = "cryptoshiapp.com"
const dbname = "cryptoshi"
const authSrc = "admin"
const url = f('mongodb://%s:%s@%s:27017/%s?authMechanism=%s&authSource=%s', user, password, host, dbname, authMechanism, authSrc);

/* GET alerts listing. */
router.get('/getAllAlerts/:uuid', function(req, res){
	if (!req.params.uuid) {
		res.json({'status': 1, 'msg': 'data not found'});
	}
  MongoClient.connect(url, function(err, db){
    if (err) throw err;
    mydb = db.db(dbname);

    mydb.collection('alert').find( {"uuid": req.params.uuid} ).toArray(function(err, result){
      if (err) throw err;
      if (result.length > 0) {
        var allAllerts = [];
        for (i = 0; i < result.length; i++) {
          allAllerts.push({'type':result[i].type, 'currency1': result[i].currency1, 'currency2': result[i].currency2, 'value': result[i].value});
        }
        res.json({ 'status': 0, "alerts": allAllerts });
      } else {
        res.json({'status': 1, 'msg': 'data not found'});
      }
    });
  });
});

module.exports = router;