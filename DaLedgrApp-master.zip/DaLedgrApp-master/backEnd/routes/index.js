var express = require('express');
var router = express.Router();
var MongoClient = require('mongodb').MongoClient
var novo = require('mongodb').ObjectID;
// var dbname = 'cryptoshi'
// var url = 'mongodb://localhost:27017/' + dbname
var analysis = require('./technicalAnalysis')

const f = require('util').format;

const user = encodeURIComponent('cryptoshi77');
const password = encodeURIComponent('j5msi5kx92_');
const authMechanism = 'DEFAULT';
const host = "api.cryptoshiapp.com"
// const host = "45.33.117.44"
const dbname = "cryptoshi"
const authSrc = "admin"
const url = f('mongodb://%s:%s@%s:27017/%s?authMechanism=%s&authSource=%s', user, password, host, dbname, authMechanism, authSrc);
// const url = f('mongodb://%s:27017/%s', host, dbname);


router.get('/stats/:pairId/:period', function(req, res){
    MongoClient.connect(url, function(err, db){









        if (err) throw err;
        mydb = db.db(dbname)
        mydb.collection('priceByExchange').find( {"assetPairId": req.params.pairId}).
                                          sort( { "timestamp": -1}).
                                          toArray(function(err, result){
            if (err) throw err;


              var idReq = '5ab12ff9981ec843daf57b23'
              var perio = 'day'

                var dayAnalyse = analysis.makeTechinicalAnalysis(mydb, idReq, perio, result[0].timestamp)

                console.log('day analise::  '+JSON.stringify(dayAnalyse));





                if (result != 'undefined' && result.length != 0){

                var calcOneHour = result[0].timestamp - 3600000.000
                var calcOneDay = result[0].timestamp - 86400000.000
                var calcOneWeek = result[0].timestamp - 604800000.000
                var calcOneMonth = result[0].timestamp - 2592000000.000
                ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                hourPeriod = 3600
                dayPeriod = 86400
                weekPeriod = 604800
                monthPeriod = 2592000

                arrayTimestamp = []
                totalSum = 0

                for (item = 0; item < result.length; item++){

                  if ((item + 1) != result.length){
                    arrayTimestamp.push(result[item].timestamp - result[item + 1].timestamp)
                  } else {
                    break
                  }

                }

                for (i = 0; i < arrayTimestamp.length; i++){
                  totalSum = totalSum + arrayTimestamp[i]

                }

                averageTime = (totalSum/arrayTimestamp.length) / 1000

                  indexForLastsHour = Math.floor(hourPeriod/averageTime)
                  indexForLastsDay = Math.ceil(dayPeriod/averageTime)
                  indexForLastsWeek = Math.ceil(weekPeriod/averageTime)
                  indexForLastsMonth = Math.ceil(monthPeriod/averageTime)


                  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                if (result[indexForLastsHour] != null && result.length > 0) {


                  var hourDeltaAndSuggestion = {'delta': result[0].last - result[indexForLastsHour].last}
                  suggestionsHoursArray = [];

                  //ANALYSIS HOUR
                  // RSI value between 0 and 100
                    hourPricesOpenings = []
                    hourPricesClosings = []

                    for (i=0;i<40;i++){
                      if (result[indexForLastsHour * i] == null || result[indexForLastsHour * i] == 'undefined'){break}
                        hourPricesOpenings.push(result[indexForLastsHour * i].open)
                        hourPricesClosings.push(result[indexForLastsHour * i].last)

                    }

                  var rsiHour = analysis.calculusRSI(hourPricesOpenings, hourPricesClosings)
                    var rsiHourSuggestion;
                  if (rsiHour <= 30){
                    //compra forte
                    rsiHourSuggestion = 5
                  }else if (rsiHour > 30 && rsiHour < 45){
                    // compra
                    rsiHourSuggestion = 4
                  }else if (rsiHour >= 45 && rsiHour <= 55){
                    // neutro
                    rsiHourSuggestion = 3
                  }else if (rsiHour > 55 && rsiHour < 70 ){
                    // venda
                    rsiHourSuggestion = 2
                  }else if (rsiHour >= 70){
                    // venda forte
                    rsiHourSuggestion = 1
                  }

                  suggestionsHoursArray.push(rsiHourSuggestion)

                    // MACDhistogram
                    var macdHistogramHour = analysis.setMACDhistogram(hourPricesClosings)

                    var macdHistogramHourSuggestion;
                    var macdHistogramHourSuggestion;
                    var greatestMacdHour = null
                    var smallestMacdHour = null
                    for (i in macdHistogramHour){
                      if (greatestMacdHour == null ){
                        greatestMacdHour = macdHistogramHour[i]
                      } else if (greatestMacdHour < macdHistogramHour[i]){
                        greatestMacdHour = macdHistogramHour[i]
                      }

                      if (smallestMacdHour == null ){
                        smallestMacdHour = macdHistogramHour[i]
                      } else if (smallestMacdHour > macdHistogramHour[i]){
                        smallestMacdHour = macdHistogramHour[i]
                      }
                    }
                    var rangeHourPositive = 0 + greatestMacdHour
                    var rangeHourNegative = 0 - smallestMacdHour
                    console.log('rangeHourNegative: ',rangeHourNegative);
                    console.log('rangeHourPositive: ',rangeHourPositive);
                  if (macdHistogramHour[0] < rangeHourNegative * 0.5){
                    // venda forte
                    macdHistogramHourSuggestion = 1
                  } else if (macdHistogramHour[0] < rangeHourNegative * 0.1  ) {
                    // venda
                    macdHistogramHourSuggestion = 2
                  } else if (macdHistogramHour[0] >= rangeHourNegative*0.1 && macdHistogramHour[0] <= rangeHourPositive*0.1){
                    // neutro
                    macdHistogramHourSuggestion = 3
                  } else if (macdHistogramHour[0] > rangeHourPositive*0.5){
                    // compra forte
                    macdHistogramHourSuggestion = 5
                  } else if (macdHistogramHour[0] > rangeHourPositive*0.1){
                    // compra
                    macdHistogramHourSuggestion = 4
                  }
                  suggestionsHoursArray.push(macdHistogramHourSuggestion)

                    const reducer = (a,b) => a + b;
                  var sugHour = suggestionsHoursArray.reduce(reducer)/suggestionsHoursArray.length
                    if ((sugHour - Math.floor(sugHour)) < 0.5){
                      sug = Math.floor(suggestionsHoursArray.reduce(reducer)/suggestionsHoursArray.length)
                    } else {
                      sugHour = Math.ceil(suggestionsHoursArray.reduce(reducer)/suggestionsHoursArray.length)
                    }

                  hourDeltaAndSuggestion.suggestion = sugHour

                } else {
                  hourDeltaAndSuggestion = {'delta': 0, 'suggestion': 3}
                }



                if (result[indexForLastsDay] != null || result.length != 0 || result[indexForLastsDay] != 'undefined') {


                  var dayDeltaAndSuggestion = {'delta': result[0].last - result[indexForLastsDay].last}
                  //ANALYSIS DAY
                  // RSI value between 0 and 100
                  dayPricesOpenings = []
                  dayPricesClosings = []
                  console.log('DAY PRICE CLOSING:    ' + JSON.stringify(dayPricesClosings));
                  console.log('DAY PRICE OPENING.:    ' + dayPricesOpenings);

                  for (i=0;i<40;i++){
                    if (result[indexForLastsDay * i] != 'undefined'){
                      dayPricesOpenings.push(result[indexForLastsDay * i].open)
                        dayPricesClosings.push(result[indexForLastsDay * i].last)

                    }
                  }

                  var rsiDay = analysis.calculusRSI(dayPricesOpenings, dayPricesClosings)
                    var rsiDaySuggestion;
                  if (rsiDay <= 30){
                    //compra forte
                    rsiDaySuggestion = 5
                  }else if (rsiDay > 30 && rsiDay < 45){
                    // compra
                    rsiDaySuggestion = 4
                  }else if (rsiDay >= 45 && rsiDay <= 55){
                    // neutro
                    rsiDaySuggestion = 3
                  }else if (rsiDay > 55 && rsiDay < 70 ){
                    // venda
                    rsiDaySuggestion = 2
                  }else if (rsiDay >= 70){
                    // venda forte
                    rsiDaySuggestion = 1
                  }
                  var suggestionsDaysArray = []
                    suggestionsDaysArray.push(rsiDaySuggestion)
                    console.log('RSI DAY sugggg: '+suggestionsDaysArray);
                    // MACDhistogram
                    var macdHistogramDay = analysis.setMACDhistogram(dayPricesClosings)

                    var macdHistogramDaySuggestion;
                    var macdHistogramDaySuggestion;
                    var greatestMacdDay = null
                    var smallestMacdDay = null
                    for (i in macdHistogramDay){
                      if (greatestMacdDay == null ){
                        greatestMacdDay = macdHistogramDay[i]
                      } else if (greatestMacdDay < macdHistogramDay[i]){
                        greatestMacdDay = macdHistogramDay[i]
                      }

                      if (smallestMacdDay == null ){
                        smallestMacdDay = macdHistogramDay[i]
                      } else if (smallestMacdDay > macdHistogramDay[i]){
                        smallestMacdDay = macdHistogramDay[i]
                      }
                    }
                    var rangeDayPositive = 0 + greatestMacdDay
                    var rangeDayNegative = 0 - smallestMacdDay
                    console.log('rangeDayNegative: ',rangeDayNegative);
                    console.log('rangeDayPositive: ',rangeDayPositive);
                  if (macdHistogramDay[0] < rangeDayNegative * 0.5){
                    // venda forte
                    macdHistogramDaySuggestion = 1
                  } else if (macdHistogramDay[0] < rangeDayNegative * 0.1  ) {
                    // venda
                    macdHistogramDaySuggestion = 2
                  } else if (macdHistogramDay[0] >= rangeDayNegative*0.1 && macdHistogramDay[0] <= rangeDayPositive*0.1){
                    // neutro
                    macdHistogramDaySuggestion = 3
                  } else if (macdHistogramDay[0] > rangeDayPositive*0.5){
                    // compra forte
                    macdHistogramDaySuggestion = 5
                  } else if (macdHistogramDay[0] > rangeDayPositive*0.1){
                    // compra
                    macdHistogramDaySuggestion = 4
                  }
                  suggestionsDaysArray.push(macdHistogramDaySuggestion)
                  const reducer = (a,b) => a + b;
                var sugDay = suggestionsDaysArray.reduce(reducer)/suggestionsDaysArray.length
                  if ((sugDay - Math.floor(sugDay)) < 0.5){
                    sug = Math.floor(suggestionsDaysArray.reduce(reducer)/suggestionsDaysArray.length)
                  } else {
                    sugDay = Math.ceil(suggestionsDaysArray.reduce(reducer)/suggestionsDaysArray.length)
                  }

                  dayDeltaAndSuggestion.suggestion = sugDay
                    console.log('SUGGGGDAYYYYYYYYY: '+JSON.stringify(dayDeltaAndSuggestion));

                } else {
                  dayDeltaAndSuggestion = {'delta': 0, 'suggestion': 3}
                }




                if (result[indexForLastsWeek] != null && result.length > 0) {


                  var weekDeltaAndSuggestion = {'delta': result[0].last - result[indexForLastsWeek].last}

                  //ANALYSIS WEEK
                  // RSI value between 0 and 100
                  weekPricesOpenings = []
                  weekPricesClosings = []

                  for (i=0;i<40;i++){
                    if (result[indexForLastsWeek * i]){
                      weekPricesOpenings.push(result[indexForLastsWeek * i].open)
                      weekPricesClosings.push(result[indexForLastsWeek * i].last)
                    }
                  }

                  var rsiWeek = analysis.calculusRSI(weekPricesOpenings, weekPricesClosings)
                  var rsiWeekSuggestion;
                  if (rsiWeek <= 30){
                    //compra forte
                    rsiWeekSuggestion = 5
                  }else if (rsiWeek > 30 && rsiWeek < 45){
                    // compra
                    rsiWeekSuggestion = 4
                  }else if (rsiWeek >= 45 && rsiWeek <= 55){
                    // neutro
                    rsiWeekSuggestion = 3
                  }else if (rsiWeek > 55 && rsiWeek < 70 ){
                    // venda
                    rsiWeekSuggestion = 2
                  }else if (rsiWeek >= 70){
                    // venda forte
                    rsiWeekSuggestion = 1
                  }
                  var suggestionsWeeksArray = []
                  suggestionsWeeksArray.push(rsiWeekSuggestion)

                  // MACDhistogram
                  var macdHistogramWeek = analysis.setMACDhistogram(weekPricesClosings)

                  var macdHistogramWeekSuggestion;
                  var macdHistogramWeekSuggestion;
                  var greatestMacdWeek = null
                  var smallestMacdWeek = null
                  for (i in macdHistogramWeek){
                    if (greatestMacdWeek == null ){
                      greatestMacdWeek = macdHistogramWeek[i]
                    } else if (greatestMacdWeek < macdHistogramWeek[i]){
                      greatestMacdWeek = macdHistogramWeek[i]
                    }

                    if (smallestMacdWeek == null ){
                      smallestMacdWeek = macdHistogramWeek[i]
                    } else if (smallestMacdWeek > macdHistogramWeek[i]){
                      smallestMacdWeek = macdHistogramWeek[i]
                    }
                  }
                  var rangeWeekPositive = 0 + greatestMacdWeek
                  var rangeWeekNegative = 0 - smallestMacdWeek

                if (macdHistogramWeek[0] < rangeWeekNegative * 0.5){
                  // venda forte
                  macdHistogramWeekSuggestion = 1
                } else if (macdHistogramWeek[0] < rangeWeekNegative * 0.1  ) {
                  // venda
                  macdHistogramWeekSuggestion = 2
                } else if (macdHistogramWeek[0] >= rangeWeekNegative*0.1 && macdHistogramWeek[0] <= rangeWeekPositive*0.1){
                  // neutro
                  macdHistogramWeekSuggestion = 3
                } else if (macdHistogramWeek[0] > rangeWeekPositive*0.5){
                  // compra forte
                  macdHistogramWeekSuggestion = 5
                } else if (macdHistogramWeek[0] > rangeWeekPositive*0.1){
                  // compra
                  macdHistogramWeekSuggestion = 4
                }
                  suggestionsWeeksArray.push(macdHistogramWeekSuggestion)
                    const reducer = (a,b) => a + b;
                  var sugWeek = suggestionsWeeksArray.reduce(reducer)/suggestionsWeeksArray.length
                    if ((sugWeek - Math.floor(sugWeek)) < 0.5){
                      sug = Math.floor(suggestionsWeeksArray.reduce(reducer)/suggestionsWeeksArray.length)
                    } else {
                      sugWeek = Math.ceil(suggestionsWeeksArray.reduce(reducer)/suggestionsWeeksArray.length)
                    }

                  weekDeltaAndSuggestion.suggestion = sugWeek


                } else {
                  weekDeltaAndSuggestion = {'delta': 0, 'suggestion': 3}
                }


                if (result[indexForLastsMonth] != null && result.length > 0) {


                  var monthDeltaAndSuggestion ={'delta':  result[0].last - result[indexForLastsMonth].last}

                  //ANALYSIS MONTH
                  // RSI value between 0 and 100
                  monthPricesOpenings = [];
                  monthPricesClosings = [];

                  for (i=0;i<40;i++){
                    if (result[indexForLastsMonth * i]){
                      monthPricesOpenings.push(result[indexForLastsMonth * i].open);
                      monthPricesClosings.push(result[indexForLastsMonth * i].last);
                    }
                  }

                  var rsiMonth = analysis.calculusRSI(monthPricesOpenings, monthPricesClosings);
                  var rsiMonthSuggestion;
                  if (rsiMonth <= 30){
                    //compra forte
                    rsiMonthSuggestion = 5
                  }else if (rsiMonth > 30 && rsiMonth < 45){
                    // compra
                    rsiMonthSuggestion = 4
                  }else if (rsiMonth >= 45 && rsiMonth <= 55){
                    // neutro
                    rsiMonthSuggestion = 3
                  }else if (rsiMonth > 55 && rsiMonth < 70 ){
                    // venda
                    rsiMonthSuggestion = 2
                  }else if (rsiMonth >= 70){
                    // venda forte
                    rsiMonthSuggestion = 1
                  }
                  var suggestionsMonthsArray = [];
                  suggestionsMonthsArray.push(rsiMonthSuggestion);

                  // MACDhistogram
                  var macdHistogramMonth = analysis.setMACDhistogram(monthPricesClosings)

                  var macdHistogramMonthSuggestion;
                  var macdHistogramMonthSuggestion;
                  var greatestMacdMonth = null
                  var smallestMacdMonth = null
                  for (i in macdHistogramMonth){
                    if (greatestMacdMonth == null ){
                      greatestMacdMonth = macdHistogramMonth[i]
                    } else if (greatestMacdMonth < macdHistogramMonth[i]){
                      greatestMacdMonth = macdHistogramMonth[i]
                    }

                    if (smallestMacdMonth == null ){
                      smallestMacdMonth = macdHistogramMonth[i]
                    } else if (smallestMacdMonth > macdHistogramMonth[i]){
                      smallestMacdMonth = macdHistogramMonth[i]
                    }
                  }
                  var rangeMonthPositive = 0 + greatestMacdMonth
                  var rangeMonthNegative = 0 - smallestMacdMonth
                  console.log('rangeMonthNegative: ',rangeMonthNegative);
                  console.log('rangeMonthPositive: ',rangeMonthPositive);
                if (macdHistogramMonth[0] < rangeMonthNegative * 0.5){
                  // venda forte
                  macdHistogramMonthSuggestion = 1
                } else if (macdHistogramMonth[0] < rangeMonthNegative * 0.1  ) {
                  // venda
                  macdHistogramMonthSuggestion = 2
                } else if (macdHistogramMonth[0] >= rangeMonthNegative*0.1 && macdHistogramMonth[0] <= rangeMonthPositive*0.1){
                  // neutro
                  macdHistogramMonthSuggestion = 3
                } else if (macdHistogramMonth[0] > rangeMonthPositive*0.5){
                  // compra forte
                  macdHistogramMonthSuggestion = 5
                } else if (macdHistogramMonth[0] > rangeMonthPositive*0.1){
                  // compra
                  macdHistogramMonthSuggestion = 4
                }
                  suggestionsMonthsArray.push(macdHistogramMonthSuggestion)

                    const reducer = (a,b) => a + b;
                  var sugMonth = suggestionsMonthsArray.reduce(reducer)/suggestionsMonthsArray.length
                    if ((sugMonth - Math.floor(sugMonth)) < 0.5){
                      sug = Math.floor(suggestionsMonthsArray.reduce(reducer)/suggestionsMonthsArray.length)
                    } else {
                      sugMonth = Math.ceil(suggestionsMonthsArray.reduce(reducer)/suggestionsMonthsArray.length)
                    }

                  monthDeltaAndSuggestion.suggestion = sugMonth


                } else {
                  monthDeltaAndSuggestion ={'delta': 0, 'suggestion': 3}
                }
                var response = { "status": 0, "price": result[0].last, "hour": hourDeltaAndSuggestion, "day": dayDeltaAndSuggestion, "week": weekDeltaAndSuggestion, "month": monthDeltaAndSuggestion, 'ask':result[0].ask, 'bid':result[0].bid, 'volume': resultVolume1}
                db.close()
                  res.json(response)

                }else{

                  res.json({'status': 1, msg: 'data not found, check parameters input'})
                }

             // volume exchange request line 43
        }) // priceByExchange request line 37
    }) // mongo client line 34
}) // router stats




// NAME GET ALL CC @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

router.get('/getAllCC', function(req, res){
    MongoClient.connect(url, function(err, db){
        if (err) throw err;
        mydb = db.db(dbname);

        mydb.collection('currency').find( {"crypto": true} ).toArray(function(err, result){
            if (err) throw err;
            if (result.length > 0) {

            var allEx = []

            for (i = 0; i < result.length; i++) {
            allEx.push({'name': result[i].name, 'symbol': result[i].symbol, 'id': result[i]._id})
            }

            res.json({ 'status': 0, "cryptos": allEx })
            } else {
            res.json({'status': 1, 'msg': 'data not found'})
            }
            })
        })
});

// GET ALL EX

router.get('/getAllEx', function(req, res){
  MongoClient.connect(url, function(err, db){
    if (err) throw err;
    mydb = db.db(dbname);

    mydb.collection('exchange').find().toArray(function(err, result){
      if (err) throw err;
      if (result.length > 0) {
        var allEx = [];
        for (i = 0; i < result.length; i++) {
          allEx.push({'name': result[i].name, 'id': result[i]._id});
        }
        res.json({ 'status': 0, "exchanges": allEx });
      } else {
        res.json({'status': 1, 'msg': 'data not found'});
      }
    });
  });
});

// GET ALL CURRENCY

router.get('/getAllCurrencies', function(req, res){
  MongoClient.connect(url, function(err, db){
    if (err) throw err;
    mydb = db.db(dbname);

    mydb.collection('currency').find( {"crypto": false} ).toArray(function(err, result){
      if (err) throw err;
      if (result.length > 0) {
        var allEx = [];
        for (i = 0; i < result.length; i++) {
          allEx.push({'name': result[i].currency, 'symbol': result[i].currencySymbol, 'id': result[i]._id});
        }

        res.json({ 'status': 0, "currencies": allEx });
      } else {
        res.json({'status': 1, 'msg': 'data not found'});
      }
    });
  });
});



//SEND DATA TO FILL THE CHART!!!!!!!!!!!!!!!

//router.get('/getChartData/:exchangeId/:pairId/:period', function(req, res){
router.get('/getChartData/:exchangeId/:cryptocurrencyId/:period', function(req, res){
  MongoClient.connect(url, function(err, db){
    if (err) throw err;
    mydb = db.db(dbname);
    const dataSize = 20;
    mydb.collection('assetExchange').find({ 'exchangeId': req.params.exchangeId,
                                            'cryptocurrencyId': req.params.cryptocurrencyId}).
                                      sort({'timestamp': -1}).
                                      toArray(function(err, result){
      db.close();

      if (err) throw err;


      hourPeriod = 3600
      dayPeriod = 86400
      weekPeriod = 604800
      monthPeriod = 2592000

      arrayTimestamp = []
      totalSum = 0

      for (item = 0; item < result.length; item++){
        if ((item + 1) != result.length){
          arrayTimestamp.push(result[item].timestamp - result[item + 1].timestamp);
        } else {
          break;
        }
      }

      for (i = 0; i < arrayTimestamp.length; i++){
        totalSum = totalSum + arrayTimestamp[i];
      }

      averageTime = (totalSum/arrayTimestamp.length) / 1000;
      indexHour = Math.ceil((hourPeriod/20)/averageTime);
      indexDay = Math.ceil((dayPeriod/20)/averageTime);
      indexWeek = Math.ceil((weekPeriod/20)/averageTime);
      indexMonth = Math.ceil((monthPeriod/20)/averageTime);

      console.log('indexHour '+ indexHour+' indexDay '+indexDay+' indexWeek '+indexWeek+' indexMonth '+indexMonth);
      console.log('averageTime =========================== '+averageTime);

      if (req.params.period == 'hour') {
        //HOURS DATA
        // Create functions for this kind of copy-paste blocks, and
        // please indent properly !!!!!!!!!!!!!!!!!!!!!!
        // ====== ^^^^^^^^^^^^^^^^ =============================
        if (result.length > 0 && result != null && result != undefined){
          var dataResult = [];
          for (var i=0; i<=dataSize; i++){
            if (typeof result[indexHour * i] == 'undefined'){
              break;
            }
            var obj = { "price" : result[indexHour * i].last, "timestamp" : result[indexHour * i].timestamp };
            dataResult.push(obj);
          }
          res.json({ "status":0, "data": dataResult })
        } else {
          res.json({status: 1, msg: 'data not found for hours'})
        }

      } else if (req.params.period == 'day') {
              // DAY DATA
              if (result.length > 0 && result != null && result != undefined){
                var dataResult = []
                  for (var i=0; i<=dataSize; i++){
                    if (typeof result[indexDay * i] == 'undefined'){
                      break
                    }
                    var obj = { "price" : result[indexDay * i].last, "timestamp" : result[indexDay * i].timestamp }
                    dataResult.push(obj)
                  }
                res.json({ "status":0, "data": dataResult })
              } else {
                res.json({status: 1, msg: 'data not found for days'})
              }

            } else if (req.params.period == 'week') {
              //WEEK DATA
              if (result.length > 0 && result != null && result != undefined){
                var dataResult = []
                  for (var i=0; i<=dataSize; i++){
                    if (typeof result[indexWeek * i] == 'undefined'){
                      break
                    }
                    var obj = { "price" : result[indexWeek * i].last, "timestamp" : result[indexWeek * i].timestamp }
                    dataResult.push(obj)
                  }
                res.json({ "status":0, "data": dataResult })
              } else {
                res.json({status: 1, msg: 'data not found for weeks'})
              }

            } else if (req.params.period == 'month') {
              // MONTH DATA
              if (result.length > 0 && result != null && result != undefined){
                var dataResult = []
                  for (var i=0; i<=dataSize; i++){
                    if (typeof result[indexMonth * i] == 'undefined'){
                      break
                    }
                    var obj = { "price" : result[indexMonth * i].last, "timestamp" : result[indexMonth * i].timestamp }
                    dataResult.push(obj)
                  }
                res.json({ "status":0, "data": dataResult })
              } else {
                res.json({status: 1, msg: 'data not found for months'})
              }

            } else {
              res.json({status: 1, msg: 'no data found at all!'})
            }

        })
    })
})

// Returns all the data for a screen: 300 points for the graph, the current price, the tech analysis and the price change
// FIXME: sanitize all the POST/GET params, period only implemented for: hour, day, week and month
// https://gist.github.com/mchow01/49f8979829f1c488d922
router.get('/getAllInfo/:assetPairId/:period', function(req, res){
  const assetPairId = req.params.assetPairId;
  const period = req.params.period;
  MongoClient.connect(url, function(err, db){
    if (err) throw err;
    mydb = db.db(dbname);
    var last = 0;
    var hourVar, dayVar, weekVar, monthVar;
    var techAnalysis;
    var graph = [];
    var error = false;
    var msg = "";
    const now = Date.now();
    const hourPeriod = 3600*1000;
    const dayPeriod = hourPeriod*24;
    const weekPeriod = dayPeriod*7;
    const monthPeriod = dayPeriod*30.44;
    const yearPeriod = dayPeriod*365.24;

    // Just to check that the assetPair exists
    //mydb.collection('assetPairId').findOne({"_id": assetPairId}, function(err, item){
      //if (err) throw err;
      //if (item == null) res.json({status: 1, msg: "wrong assetPairId"});
      //mydb.collection('priceByExchange').find( {"assetPairId": assetPairId, "timestamp": { $gt: now-monthPeriod } }).sort( {"timestamp":-1} ).limit(1).toArray(function(err, result){
      mydb.collection('priceByExchange').find( {"assetPairId": assetPairId, "timestamp": { $gt: now-26*monthPeriod } }).sort( {"timestamp":-1} ).toArray(function(err, result){
        // Standard error checking
        if (err) throw err;
        if ( result == null || result.length == 0 ){
          error = true;
          msg = "no data";
        }
        // First I need the last price
        last = result[0].last;
        // Then, I gather the data for the graph
        hData = [];
        dData = [];
        wData = [];
        mData = [];
        //FIXME: refine forEach functions
        result.filter( price => price.timestamp >= now - hourPeriod ).forEach(x => hData.push({timestamp:x.timestamp, price: x.last})); //60
        result.filter( price => price.timestamp >= now - dayPeriod ).forEach(x=> dData.push({timestamp:x.timestamp, price:x.last})); //every 4-min: 360
        result.filter( price => price.timestamp >= now - weekPeriod ).forEach(x=> wData.push({timestamp:x.timestamp, price:x.last})); //every 30-min: 296
        result.filter( price => price.timestamp >= now - monthPeriod ).forEach(x=> mData.push({timestamp:x.timestamp, price:x.last})); //every 2 hours: 360
        
        if ( period == "hour" ) {
          graph = hData;
          periodTime = hourPeriod;
        } else if ( period == "day" ) {
          graph = dData;
          periodTime = dayPeriod;
        } else if ( period == "week" ) {
          graph = wData;
          periodTime = weekPeriod;
        } else if ( period == "month" ) {
          graph = mData;
          periodTime = monthPeriod;
        } else {
          error = true;
          msg = "period not implemented";
        }
        // Then I get the technical analysis
        techAnalysis = [];
        k=1;
        open = result[0].last
        console.log(open)
        result.forEach( (x,i,r) => {
          if ( k<=26 && x.timestamp <= now-k*periodTime ) {
            k++;
            techAnalysis.push( {open: open, close: r[i-1].last} );
            open = x.last
          }
        });
        //console.log(hData)
        //console.log(dData)
        //console.log(techAnalysis.length)
        //console.log(techAnalysis)
        //techAnalysis = makeTechicalAnalysis(period, techAnalysis);
        techAnalysis = 2; //makeTechicalAnalysis(period, techAnalysis);
        // Finally, I get the variations
        hourVar = hData[0].price - hData[hData.length-1].price;
        dayVar = dData[0].price - dData[dData.length-1].price;
        weekVar = wData[0].price - wData[wData.length-1].price;
        monthVar = mData[0].price - mData[mData.length-1].price;

        db.close();
        if ( error )
          res.json({status: 1, msg: msg});
        else
          res.json({status: 0, last: last, graph: graph, hourvar: hourVar, dayvar: dayVar, weekvar: weekVar, monthvar: monthVar, analysis: techAnalysis});
      });
    //});
  });
});

router.get('/getInitParams', async function(req, res){
  try {
    //const db = MongoClient.connect(url).catch((err) => { console.log("error") });
    const db = await MongoClient.connect(url);
    const mydb = db.db(dbname);
    const currencies = await mydb.collection('currency').find().toArray();
    const exchanges = await mydb.collection('exchange').find().toArray();
    const pairs = await mydb.collection('assetPair').find().toArray();
    db.close()
    res.json( {status: 0, currencies: currencies, exchanges: exchanges, pairs: pairs} );
  } catch (err) {
    res.json( {status: 1, msg: "no db connection" } );
  }
});

module.exports = router;
