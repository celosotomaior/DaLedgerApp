module.exports = {






// SUPPORT AND RESISTANCE PRICES





































// SET PATTERN ON THE CHART

setCandleStickPattern: function(periodHigh, periodLow, openingPrice, closingPrice) {
	var pattern = 'no pattern identified'

	var wick = periodHigh - periodLow
	var wickUpperPosition = periodHigh
	var wickMiddlePosition = wick/2
	var wickBottonPosotion = periodLow



	var body = (openingPrice - closingPrice)
	var bodyPositive = Math.abs(body)


// CALCULATION BODY POSITION AND SIZE
	var bodyMiddlePosition;
	var bodyUpperPosition;
	var bodyBottonPosition;

	if (body < 0) {
		bodyMiddlePosition = (bodyPositive/2) + closingPrice
		bodyUpperPosition = closingPrice
		bodyBottonPosition = openingPrice
	} else {
		bodyMiddlePosition = (bodyPositive/2) + openingPrice
		bodyUpperPosition = openingPrice
		bodyBottonPosition = closingPrice
	}




// HAMMER PATTERN
	if (body <= (wick/3) && body >= ((wick/3)/2)  && bodyMiddlePosition >= (wickMiddlePosition * 1.5)) {
		pattern = 'hammer pattern identified'
	}

//



		return pattern
},











// Como é calculado o RSI?
// O indicador é calculado comparando-se a performance atual de um ativo contra sua performance prévia, ou seus dias de alta versus seus dias de baixa.
//
// Utiliza-se a seguinte formula:
//
// RSI = 100 – 100/(1 + RS*)
//
// * RS = Média de X dias de alta / Média de X dias de baixa.
//
// A quantidade de períodos padrão é 14, sendo que 9 e 28 também são comumente utilizados. Geralmente, mais períodos tendem a gerar dados mais precisos.


// CALCULO RSI 14 PERIODS
// var lastOpenings = [11003, 10939, 10959, 10972.7, 10969, 10969, 11028, 11000, 10993, 10948, 10895, 10878, 10850, 10839, 10906]
// var lastClosings = [10954,11002,10940, 10958, 10958, 10972.3, 10970, 11027, 11000, 10993, 10947, 10896, 10877, 10850, 10839]


// function getAllBodiesTrend(allOpeningPrice, allClosingPrice){
// pricesArray = []
//
// 	for (i = 0; i < period; i++){
// 		pricesArray.push(allOpeningPrice[i] - allClosingPrice[i])
// 	}
//
// 	return pricesArray
// }



calculusRSI: function(allOpeningPrice, allClosingPrice){
	 // 14 periods
	 var period = 14
	 var RSI;

	 bodyArray = []

	 	for (i = 0; i < period; i++){
	 		bodyArray.push(allOpeningPrice[i] - allClosingPrice[i])
	 	}


	 positiveBodies = []
	 negativeBodies = []

	 for (i = 0; i < bodyArray.length; i++){

		 	if (bodyArray[i] < 0){
				negativeBodies.push(bodyArray[i])
			} else if (bodyArray[i] >= 0){
				positiveBodies.push(bodyArray[i])
			}
		}
			sumPositive = 0
			sumNegative = 0

			for (positiveIndex in positiveBodies) {
				parseInt(positiveIndex)
				sumPositive = sumPositive + positiveBodies[positiveIndex]
			}
			for (negativeIndex in negativeBodies) {
				parseInt(negativeIndex)
				sumNegative = sumNegative + negativeBodies[negativeIndex]
			}

			var RS = sumPositive/Math.abs(sumNegative)

			RSI = 100 - 100/(1 + RS)

		 return RSI
 },


//CALCULUS OF THE MOVING AVERAGE AND MOVING AVERAGE EXPONENTIAL

setMovingAverage: function(prices, period){

	var movingAverage = []

 	for (index in prices) {

	 index = parseFloat(index)
	 if (index <= prices.length - period){

		 sumOfPricesByPeriod = 0
		 for (i = 0; i < period; i++){
			 sumOfPricesByPeriod = sumOfPricesByPeriod + prices[index + i]
		 }

		 var movingAveragePoint = sumOfPricesByPeriod/period
		 movingAveragePoint = Math.floor(movingAveragePoint * 100)/100
	 movingAverage.push(movingAveragePoint)
 } else {
	 break
 }

}
	return movingAverage
},


setExponentialMovingAverage: function(price, period){
	var exponentialMovingAverage = [];
	sumPeriod = 0

	for (i=0; i < period; i++){
		sumPeriod = sumPeriod + price[i]
	}

	var initialSMA = sumPeriod/period
	var multiplier = (2/(period +1))
	var vEMA;


	var n = 0;
while (n <= 1) {
		if (exponentialMovingAverage.length == 0){
			vEMA = parseFloat(initialSMA)
			var roundEMA = Math.floor(vEMA * 100)/100

			exponentialMovingAverage.push(roundEMA)
		} else {
			for (i=0;i < price.length - 1;i++){
			vEMA = parseFloat(exponentialMovingAverage[i] + multiplier * (price[i] - exponentialMovingAverage[i]))
			var roundEMA = Math.floor(vEMA * 100)/100

			exponentialMovingAverage.push(roundEMA)
		}

		}

		n++
}


		return exponentialMovingAverage
},

// MACD INDEX
// MACD Line: (12-day EMA - 26-day EMA)
//
// Signal Line: 9-day EMA of MACD Line
//
// MACD Histogram: MACD Line - Signal Line


setMACD: function(prices){

	var EMA12 = module.exports.setExponentialMovingAverage(prices, 12)
	var EMA26 = module.exports.setExponentialMovingAverage(prices, 26)

	var arrayMACD = [];

for (i in EMA12){
	var macd = EMA12[i] - EMA26[i]
	macd = Math.floor(macd * 100)/100
	arrayMACD.push(macd)
}

	return arrayMACD
},

setMACDSignalLine: function(prices){

	var arrayMACD = module.exports.setMACD(prices)

	var period9MACD = module.exports.setExponentialMovingAverage(arrayMACD, 9)
	return period9MACD
},

setMACDhistogram: function(prices){
	var Signal = module.exports.setMACDSignalLine(prices)
	var macdLine = module.exports.setMACD(prices)
	var histogram = []
	for (i in Signal){
		var hist = macdLine[i] - Signal[i]
		var hist = Math.floor(hist * 1000)/1000
		histogram.push(hist)
	}

	return histogram
},
// P = (H + L + C) / 3
setPivotPoint: function(high, low, close){
	var pivotPoint = (high,low,close)/3
	return pivotPoint
},

setResistanceAndSupportLevels: function(closingPrices, openingPrices){
	var positiveClose = []
	var negativeClose = []
	var resistanceAndSupport = {}


	for (i=0;i<closingPrices.length;i++){
		if (openingPrices[i] <= closingPrices[i]){
			positiveClose.push(closingPrices[i])
		} else {
			negativeClose.push(closingPrices[i])
		}
	}

positiveClose.sort(function(a, b){return b - a});
negativeClose.sort(function(a, b){return a - b});

var matchingPositivePoints = {}
var matchingNegativePoints = {}

for (item=0;item<positiveClose.length;item++){
	var count = 0
for (i=0;i<positiveClose.length;i++){
	if (positiveClose[item] < positiveClose[item + i]*1.03 && positiveClose[item] > positiveClose[item + i]*0.97){
		count = count + 1

		matchingPositivePoints['Price ' + positiveClose[item]] = count
		// positiveClose.splice(positiveClose.indexOf(positiveClose[i]),1)
	} else {
		continue
	}

}

}
var greatestP = null
for (i in matchingPositivePoints){
	if (greatestP == null){
		greatestP = matchingPositivePoints[i]
	} else if (greatestP < matchingPositivePoints[i]){
		greatestP = matchingPositivePoints[i]
	}
}


var resistance;
for (key in matchingPositivePoints){
	if (matchingPositivePoints[key] == greatestP ){
		key = key.split(' ')
		resistanceAndSupport.resistance = parseFloat(key[1])
		break
	}
}

for (item=0;item<negativeClose.length;item++){
	var count = 0
for (i=0;i<negativeClose.length;i++){
	if (negativeClose[item] < negativeClose[item + i]*1.03 && negativeClose[item] > negativeClose[item + i]*0.97){
		count = count + 1
		matchingNegativePoints['Price ' + negativeClose[item]] = count
		// negativeClose.splice(negativeClose.indexOf(negativeClose[i]),1)
	} else {
		continue
	}

}

	var smallestN = null
for (i in matchingNegativePoints){
	if (smallestN == null){
		smallestN = matchingNegativePoints[i]
	} else if (smallestN > matchingNegativePoints[i]){
		smallestN = matchingNegativePoints[i]
	}
}


for (key in matchingNegativePoints){
	if (matchingNegativePoints[key] == smallestN ){
		key = key.split(' ')
		resistanceAndSupport.support = parseFloat(key[1])
		break
	}
}

}

return resistanceAndSupport

},

getHighOfperiod: function(closingPrices){
		var highest = null;
			for (h in closingPrices){
				if (highest == null){
					highest = closingPrices[h];
				} else if (highest < closingPrices[h]){
					highest = closingPrices[h];
				}
			}

			return highest;
},

getLowOfPeriod: function(closingPrices){
	var lowest = null;
		for (h in closingPrices){
			if (lowest == null){
				lowest = closingPrices[h];
			} else if (lowest > closingPrices[h]){
				lowest = closingPrices[h];
			}
		}

		return lowest;

},
// getOpeningOfPeriod: function(closingPrices){
// 	return closingPrices[closingPrices.length - 1];
// },

populateClosingPrices: async function(mydb, timestamp, pairId) {
	mydb.collection('assetPair').find( {"assetPairId": pairId, 'timestamp': {$gt: timestamp - 100000, $lt: timestamp + 100000}}).sort({'timestamp': -1}).toArray(function(err, result){
		if (err) throw err;

		midResult = Math.floor(result.length/2)

		return result[midResult];
	})
},
makeTechinicalAnalysis: async function(mydb, pairId, period, updatedTimestamp){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
var closingPrices = []



if (period == 'hour'){
		var periodTimestamp = 3600000
} else if (period == 'day'){
		var periodTimestamp = 86400000
} else if (period == 'week'){
		var periodTimestamp = 604800000
} else if (period == 'month'){
		var periodTimestamp = 2592000000
}



for (i=0;i<100;i++){

	var timestamp = updatedTimestamp - (periodTimestamp * i)
	closingPrices.push(await module.exports.populateClosingPrices(mydb, timestamp, pairId))

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////

	var result = {};
	var openingPrices = [];
	var rsiSuggestion = null;
	var macdHistogramSuggestion = null;

	for (i=1;i<closingPrices.length;i++){
		openingPrices.push(closingPrices[i])
	};

	var rsi = module.exports.calculusRSI(openingPrices, closingPrices);
	var macdHistogram = module.exports.setMACDhistogram(closingPrices);

// RSI ANALYSE

	if (rsi <= 30){
		// COMPRA FORTE
		rsiSuggestion = 5;
	} else if (rsiHour > 30 && rsiHour < 45) {
		// COMPRA
		rsiSuggestion = 4;
	} else if (rsi >= 45 && rsi <= 55) {
		// NEUTRO
		rsiSuggestion = 3;
	} else if (rsi > 55 && rsi < 70 ) {
		// VENDA
		rsiSuggestion = 2;
	} else if (rsi >= 70) {
		// VENDA FORTE
		rsiSuggestion = 1;
	}

	// MACD ANALYSE

	var greatestMacd = null;
	var smallestMacd = null;
	for (i in macdHistogram){
		if (greatestMacd == null ){
			greatestMacd = macdHistogram[i]
		} else if (greatestMacd < macdHistogram[i]){
			greatestMacd = macdHistogram[i];
		}
		if (smallestMacd == null ){
			smallestMacd = macdHistogram[i];
		} else if (smallestMacd > macdHistogram[i]){
			smallestMacd = macdHistogram[i];
		}
	}
	var rangePositive = 0 + greatestMacd;
	var rangeNegative = 0 - smallestMacd;

	if (macdHistogram[0] < rangeNegative * 0.5){
	// venda forte
	macdHistogramSuggestion = 1;
	} else if (macdHistogram[0] < rangeNegative * 0.1  ) {
	// venda
	macdHistogramSuggestion = 2;
	} else if (macdHistogram[0] >= rangeNegative*0.1 && macdHistogram[0] <= rangePositive*0.1){
	// neutro
	macdHistogramSuggestion = 3;
	} else if (macdHistogram[0] > rangePositive*0.5){
	// compra forte
	macdHistogramSuggestion = 5;
	} else if (macdHistogram[0] > rangePositive*0.1){
	// compra
	macdHistogramSuggestion = 4;
	}
	var averageSuggestion = (rsiSuggestion + macdHistogramSuggestion) / 2;

	var supportAndResistance = module.exports.setResistanceAndSupportLevels(closingPrices, openingPrices);

	result.supportAndResistance = supportAndResistance;
	result.rsi = rsi;
	result.macdHistogram = macdHistogram;
	result.suggestion = averageSuggestion;


	return result;

}

}


//           45,46, 43, 44, 42, 41, 40, 39, 41, 40, 38,36

// pricesTest = [77.78,78.23, 79.59, 79.52, 79.45, 79.11, 79.99, 78.95, 77.66, 77.62, 77.01,77.51,80.47,79.57,79.13,80.43,81.69,95,75,37,23,34,54,32,12,56,78,54,32,13];


// console.log('\n MOVING AVERAGE:             '+ setMovingAverage(pricesTest, 5));
// console.log('\n EXPONENTIAL MOVING AVERAGE: '+ setExponentialMovingAverage(pricesTest, 6));
// console.log('\n MACD:                       '+ setMACD(pricesTest));
// console.log('\n MACDline                    ' + setMACDSignalLine());
// console.log('\n MACDhistogram               ' + setMACDhistogram());
// console.log('\n RSI:                        '+calculusRSI(lastOpenings, lastClosings));




var closeprices = [12,34,10,97,56,97,34,21,55,54,32,53,1]
var openprices = [23,34,56,24,45,52,34,65,43,32,52,22,0]
